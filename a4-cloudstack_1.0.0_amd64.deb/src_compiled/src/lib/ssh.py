import logging
from typing import Tuple

import paramiko


class SSH:
    def __init__(self, hostname: str, username: str, password: str, always_create_new_connection: bool = False):
        self.hostname = hostname
        self.username = username
        self.password = password
        self.always_create_new_connection = always_create_new_connection
        self.ssh = None

    def get_new_ssh_connection(self) -> paramiko.SSHClient:
        """
        Method to get new ssh connection
        :return: ssh connection object
        """
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(hostname=self.hostname, username=self.username, password=self.password)
        return ssh

    def get_connection(self) -> paramiko.SSHClient:
        """
        Method to get ssh connection object
        :return: ssh connection object
        """
        if self.always_create_new_connection:
            return self.get_new_ssh_connection()
        else:
            if self.ssh is None:
                self.ssh = self.get_new_ssh_connection()
            return self.ssh

    def exec_command(self, command: str, timeout: int = 10) -> Tuple[int, str, str]:
        """
        To exec command on remote system
        :param command: command string
        :param timeout: timeout in seconds
        :return: status, stdout, stderr
        """
        conn = self.get_connection()
        try:
            stdin, stdout, stderr = conn.exec_command(command, get_pty=True, timeout=timeout)
            status = stdout.channel.recv_exit_status()
            out = stdout.read().decode("utf-8")
            err = stderr.read().decode("utf-8")
            if status != 0:
                msg = "Command failed:\n*** Command:\n%s\n*** Output:\n%s\n" "*** Error:\n%s\n*** Return - %s" % (
                    command,
                    out,
                    err,
                    status,
                )
                logging.warning(msg)
            return status, out, err
        except Exception as e:
            return -1, "", format(e)
        finally:
            if self.always_create_new_connection:
                conn.close()

    def sftp_transfer(self, localfilepath: str, remotefilepath: str):
        """
        Method to transfer file from local machine to remote machine
        :param localfilepath: Local file path
        :param remotefilepath: Remote file path
        """
        conn = self.get_connection()
        try:
            ftp_client = conn.open_sftp()
            ftp_client.put(localfilepath, remotefilepath)
            ftp_client.close()
        except Exception as e:
            logging.info(e)

    def close(self):
        """
        closes the ssh connection if necessary
        """
        if not self.always_create_new_connection and self.ssh is not None:
            self.ssh.close()
            self.ssh = None

    def __del__(self) -> None:
        """
        To close ssh connection during object destruction
        close
        :return: ssh connection closed
        """
        self.close()
