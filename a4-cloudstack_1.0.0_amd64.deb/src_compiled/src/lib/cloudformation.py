
import logging
import time

import boto3
from botocore.exceptions import ClientError

from constants import *


class Cloudformation:
    def __init__(self, config):
        self.client = boto3.client(
            "cloudformation", **config
        )

    def create_stack(self, stack_name: str, **kwargs):
        """
        Method to create stack.
        :param stack_name: Stack Name.
        :param kwargs: TemplateBody/TemplateURL/Parameters/DisableRollback/RollbackConfiguration/
                        MonitoringTimeInMinutes/TimeoutInMinutes/NotificationARNs/Capabilities/ResourceTypes/RoleARN/
                        OnFailure/StackPolicyBody/StackPolicyURL/Tags/ClientRequestToken/EnableTerminationProtection.
        :return: create_stack_response.
        """
        try:
            create_stack_response = self.client.create_stack(StackName=stack_name, **kwargs)
            return create_stack_response
        except ClientError as err:
            logging.info(f"Create stack failed with err: {err.response['Error']['Code']}")
            logging.error(err)

    def create_stack_validate(self, stack_name: str, **kwargs):
        """
        Method to validate create stack response.
        :param stack_name: Stack Name.
        :param kwargs: TemplateBody/TemplateURL/Parameters/DisableRollback/RollbackConfiguration/
                        MonitoringTimeInMinutes/TimeoutInMinutes/NotificationARNs/Capabilities/ResourceTypes/RoleARN/
                        OnFailure/StackPolicyBody/StackPolicyURL/Tags/ClientRequestToken/EnableTerminationProtection.
        """
        create_stack_response = self.create_stack(stack_name, **kwargs)
        assert create_stack_response, f"failed to create stack '{stack_name}'"
        assert create_stack_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected:'{RESPONSE_OK}'but found,"
            f"'{create_stack_response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        stack_list = [stack['StackName'] for stack in self.list_stacks_validate()['Stacks']]
        assert stack_name in stack_list, f"failed to create stack '{stack_name}'."
        stack_create_status = False
        for _ in range(0, 20):
            stack_status = self.list_stacks_validate(StackName=stack_name)['Stacks']
            if stack_status[0]['StackStatus'] == 'CREATE_COMPLETE':
                logging.info(f"Stack '{stack_name}' status finally changed to '{stack_status[0]['StackStatus']}'.")
                stack_create_status = True
                break
            else:
                logging.info(f"Stack '{stack_name}' status changed to '{stack_status[0]['StackStatus']}'.")
                time.sleep(5)
        assert stack_create_status, f"Stack '{stack_name}' status does not changed to 'CREATE_COMPLETE'."
        logging.info(f"Stack '{stack_name}' created successfully.")

    def list_stacks(self, **kwargs):
        """
        Method to get all the stacks.
        :param kwargs: StackName/NextToken.
        :return: describe_stacks_response
        """

        try:
            describe_stacks_response = self.client.describe_stacks(**kwargs)
            return describe_stacks_response
        except ClientError as err:
            logging.info(f"Unable to fetch the stack data, listing with err: {err.response['Error']['Code']}")
            logging.error(err)

    def list_stacks_validate(self, **kwargs):
        """
        Method to validate get all the stacks response.
        :param kwargs: StackName/NextToken.
        :return: describe_stacks_response
        """
        describe_stacks_response = self.list_stacks(**kwargs)
        assert describe_stacks_response, f"failed to get response list"
        assert describe_stacks_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected:'{RESPONSE_OK}'but found,"
            f"'{describe_stacks_response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        return describe_stacks_response

    def delete_stack(self, stack_name: str, **kwargs):
        """
        Method to delete stack.
        :param stack_name: Stack Name.
        :param kwargs: RetainResources/RoleARN/ClientRequestToken
        :return: delete_stack_response.
        """
        try:
            delete_stack_response = self.client.delete_stack(StackName=stack_name, **kwargs)
            return delete_stack_response
        except ClientError as err:
            logging.info(f"Unable to delete stack, listing with err: {err.response['Error']['Code']}")
            logging.error(err)

    def delete_stack_validate(self, stack_name: str, **kwargs):
        """
        Method to validate delete stack response.
        :param stack_name: Stack Name.
        :param kwargs: RetainResources/RoleARN/ClientRequestToken
        """
        delete_stack_response = self.delete_stack(stack_name, **kwargs)
        assert delete_stack_response, f"failed to get response list"
        assert delete_stack_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected:'{RESPONSE_OK}'but found,"
            f"'{delete_stack_response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        stack_delete_status = False
        for _ in range(0, 20):
            stack_list = [stack['StackName'] for stack in self.list_stacks_validate()['Stacks']]
            if stack_name not in stack_list:
                stack_delete_status = True
                break
            else:
                stack_status = self.list_stacks_validate(StackName=stack_name)['Stacks']
                logging.info(f"Status of the stack '{stack_name}' is '{stack_status[0]['StackStatus']}'")
                time.sleep(5)
        assert stack_delete_status, f"failed to delete stack '{stack_name}'."
        logging.info(f"Stack '{stack_name}' deleted successfully.")

    def template_validation(self, **kwargs):
        """
        Method to validate specified template.
        :param kwargs: TemplateBody/TemplateURL
        :return: validate_template_response.
        """
        try:
            validate_template_response = self.client.validate_template(**kwargs)
            return validate_template_response
        except ClientError as err:
            logging.info(f"Unable to validate template, listing with err: {err.response['Error']['Code']}")
            logging.error(err)

    def validate_template_validation(self, **kwargs):
        """
        Method to validate template_validation method response.
        :param kwargs: TemplateBody/TemplateURL.
        """
        validate_template_response = self.template_validation(**kwargs)
        assert validate_template_response, f"failed to validate template"
        assert validate_template_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected:'{RESPONSE_OK}'but found,"
            f"'{validate_template_response['ResponseMetadata']['HTTPStatusCode']}'"
        )
