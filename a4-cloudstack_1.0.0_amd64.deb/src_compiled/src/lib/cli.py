#!/usr/bin/env python3
import datetime
import getpass
import os
import time
import uuid
import json

import jwt
import boto3

from colorama import Fore, Style
from cryptography.fernet import Fernet
from constants import (
    TOKEN_PATH,
    RANDOM_PATH,
    KEY_PATH,
    SESSION_PATH
)

home_dir = os.path.expanduser("~")
token_file_path = os.path.join(home_dir, TOKEN_PATH)
random_key_file_path = os.path.join(home_dir, RANDOM_PATH)
key_file_path = os.path.join(home_dir, KEY_PATH)
config_file_path = os.path.join(home_dir, SESSION_PATH)

DEFAULT_SESSION_TIMEOUT = '10min'


def gen_and_save_random_key() -> str:
    """
    Generates and saves random key in file.
    """
    rand_key = uuid.uuid4()
    with open(random_key_file_path, "w") as rand_file:
        rand_file.write(str(rand_key))
        rand_file.close()
    return str(rand_key)


def get_random_key():
    """
    Fetches random key from file.
    """
    random_key = open(random_key_file_path, "r").read()
    return random_key


def exit_old_aws_session():
    if os.path.exists(token_file_path):
        os.remove(token_file_path)
    if os.path.exists(key_file_path):
        os.remove(key_file_path)
    if os.path.exists(random_key_file_path):
        os.remove(random_key_file_path)
    print("Current session destroyed successfully")


def create_new_aws_session(install: bool = False, token: bool = False, duration_sec: int = 3600) -> bool:
    """Function To create AWS session
        Returns:
            (bool): if user session created successfully
    """
    is_session_created = False
    # Reading configuration file for session timeout and required roles
    assert (os.path.isfile(config_file_path) and os.access(config_file_path, os.R_OK)), \
        f"Project {config_file_path} file does not exists"
    config_json = json.load(open(config_file_path))

    print("Please Provide following details to create a session -\n")
    region_name = input("Please Enter Region Name [default ap-south-1]: ") or "ap-south-1"
    access_key = getpass.getpass("Please Enter Access Key ID: ")
    secret_key = getpass.getpass("Please Enter Secret Access Key: ")
    config_dict = dict(
        aws_access_key_id=access_key,
        aws_secret_access_key=secret_key,
        region_name=region_name
    )

    # Collect input from user based at different events like installation or temp. token creation
    if install or not config_json.get("allowedIAMRoles"):
        config_roles = input("Please Enter Allowed IAM Roles separated by commas: ")
        config_roles_list = list(map(str.strip, config_roles.split(",")))
        config_json["allowedIAMRoles"] = config_roles_list
        jfile = open(config_file_path, "w+")
        jfile.write(json.dumps(config_json))
        jfile.close()
    elif token:
        session_key = getpass.getpass("Please Enter Session Token: ")
        config_dict["aws_session_token"] = session_key

    # Validate input creds with sts
    status = verify_aws_credentials(config_dict)
    if status:
        # Exclude role check verification for token based auth.
        if not token:
            if not config_json.get("allowedIAMRoles", []):
                print(Fore.RED + f"Allowed IAM roles not provided. Please provide under config " \
                                 f"path '{config_file_path}' And run command 'createsession'" + Style.RESET_ALL)
                exit()
            is_user_has_valid_roles(
                config_json.get("allowedIAMRoles", []), access_key, secret_key, region_name
            )
            ses_exp = config_json.get("sessionTimeout", DEFAULT_SESSION_TIMEOUT)
            config_dict['is_token'] = False
        else:
            config_dict['is_token'] = True
            ses_exp = str(duration_sec)+'sec'
        encoded_token = encode_auth_token(config_dict, ses_exp=ses_exp)
        write_token_to_file(encoded_token)
        print(f"(created session with Idle time - {config_json.get('sessionTimeout', DEFAULT_SESSION_TIMEOUT)}. "
              f"you can change the idle timeout by modifying '{config_file_path}' file.)")
        is_session_created = True
    else:
        print(Fore.RED + f"Unable to create a session, Please verify provided credentials or check "
                         f"your network connectivity" + Style.RESET_ALL)
    return is_session_created


def access_aws_account() -> dict:
    """Function To access AWS session
        Returns:
            (dict): user credentials
    """
    # If token file not present create new session.
    if not os.path.isfile(token_file_path) or not os.path.isfile(key_file_path):
        is_session_created = create_new_aws_session()
        assert is_session_created, Fore.RED + f"Use 'createsession' command to create session." + Style.RESET_ALL

    enc_token = open(token_file_path, "r").read()
    key = open(key_file_path, "r").read()
    dec_token = decrypt_token(bytes(key, 'utf-8'), enc_token)
    config = decode_auth_token(dec_token)

    # Extend session while creating boto3 client (Note. Session extension excluded for the temp. token bases session)
    if config.get('exp') and config.get('region_name') and not config.get('is_token') and \
            config.get('aws_access_key_id') and config.get('aws_secret_access_key'):
        if config['exp'] > int(time.time()) and os.path.isfile(config_file_path):
            config_json = json.load(open(config_file_path))
            encoded_token = encode_auth_token(
                config, ses_exp=config_json.get("sessionTimeout", DEFAULT_SESSION_TIMEOUT)
            )
            write_token_to_file(encoded_token, background=True)
            enc_token = open(token_file_path, "r").read()
            key = open(key_file_path, "r").read()
            dec_token = decrypt_token(bytes(key, 'utf-8'), enc_token)
            config = decode_auth_token(dec_token)

    # Exclude unwanted/non sts parameters from config dict
    config.pop('exp')
    config.pop('is_token')
    return config


def write_token_to_file(encoded_token: str, background: bool = False):
    """
    Function to save encoded JWT token in file
    Args:
            encoded_token (str): Active JWT token
            background (bool) : Show session created message to user only if False
    """
    if isinstance(encoded_token, bytes):
        encoded_token = encoded_token.decode("utf-8")
    key = Fernet.generate_key()
    with open(key_file_path, "wb") as key_file:
        key_file.write(key)
        key_file.close()
    encrypted_token = encrypt_token(key, encoded_token)
    file = open(token_file_path, 'w')
    file.write(encrypted_token)
    file.close()
    if not background:
        print(Fore.GREEN + "Session Has been created successfully.....\n"
                           "Commands available - cloudwatch  dynamoDB  ec2  iam  s3  sns  sts rds"
                           " (use --help for more details)" + Style.RESET_ALL)


def encode_auth_token(payload: dict, ses_exp: str = "8hr") -> str:
    """
    Function to generate JWT token for authentication
    Args:
        payload (dict)     : Contains AWS region name, access_key, secret_key,
        session token, exp, and is_token for temp credentials.
        ses_exp (str)    : session expiry time(8hr default)
    Returns:
            (str): generated token
    """
    timeout = convert_session_timeout(ses_exp)
    try:
        sec_key = gen_and_save_random_key()
        payload.update({'exp': datetime.datetime.utcnow() + datetime.timedelta(days=0, seconds=timeout)})
        token = jwt.encode(payload, sec_key, algorithm='HS256')
        return token
    except Exception as e:
        print(e)


def decode_auth_token(token: bytes) -> dict:
    """
    Function to decode JWT token and fetch payload information.
    Args:
        token (bytes): JWT token data
    Returns:
        Payload data for session creation
    """
    try:
        sec_key = get_random_key()
        payload = jwt.decode(token, sec_key, algorithms=['HS256'])
        return payload
    except jwt.ExpiredSignatureError:
        print('your old AWS session has expired, Please login Again.\ntype "createsession" command in terminal to '
              'create a new session.')
        exit()
    except jwt.InvalidTokenError:
        print('Invalid token. Please log in again')
        exit()


def encrypt_token(key: bytes, token: str) -> str:
    """
    Function to encrypt JWT token
    Args:
        key(bytes): Key to encrypt JWT token
        token(str): JWT token
    Returns:
        encrypted token
    """
    encoded_token = token.encode()
    f = Fernet(key)
    enc_token = f.encrypt(encoded_token)
    if isinstance(enc_token, bytes):
        enc_token = enc_token.decode("utf-8")
    return enc_token


def decrypt_token(key: bytes, enc_token: str) -> bytes:
    """
    Function to decrypt JWT token
    Args:
        key(str)    : Key which was used for encrypting JWT token
        enc_token(str): encoded token
    Returns:
        decrypted token
    """
    f = Fernet(key)
    dec_token = f.decrypt(bytes(enc_token, 'utf-8'))
    return dec_token


def convert_session_timeout(session_time: str) -> int:
    """
    Function to convert session time in seconds
    Args:
        session_time(str)    : input session time
    Returns:
        (int) : session time in seconds
    """
    conv_dict = {"hr": 3600, "min": 60, "sec": 1}
    time_units = ["hr", "min", "sec"]
    for count, ele in enumerate(time_units):
        if time_units[count] in session_time:
            ses_exp = session_time.replace(time_units[count], "")
            ses_exp = int(ses_exp) * conv_dict[time_units[count]]
            break
    else:
        session_time = input("Invalid session time provided, Accepted format - 1hr, 30min or 100sec:  ")
        ses_exp = convert_session_timeout(session_time)
    return ses_exp


def verify_aws_credentials(creds: dict) -> bool:
    """
    Function to Verify AWS credentials
    Args:
        creds(dict)    : Contains Access Key, Secret Key, region name (Token if temp. creds.)
    Returns:
        (dict) : User details like AWS account, user ARN
    """
    try:
        sts_obj = boto3.client("sts", **creds)
        caller_details = sts_obj.get_caller_identity()
    except Exception:
        return {}
    return caller_details


def is_user_has_valid_roles(role_list: list, access_key: str, secret_key: str, region_name: str):
    """
    Method to validate input roles with its IAM user role
    :
    Args:
        role_list(list)    : IAM roles.
        access_key(str)    : Access Key
        secret_key(str)    : Secret Key
        region_name(str)   : region name
    """
    try:
        iam_client = boto3.client(
            'iam', region_name=region_name, aws_access_key_id=access_key, aws_secret_access_key=secret_key
        )
        iam_role_list = [role['RoleName'] for role in iam_client.list_roles()['Roles']]
        req_list = []
        for role_name in role_list:
            if role_name not in iam_role_list:
                req_list.append(role_name)
        if req_list:
            print(Fore.RED + f"Roles {', '.join(req_list)} are not assigned to the user."
                             f"\nPlease update correct roles in {config_file_path} file. "
                             f"\n[Or use 'createsession install' command]" + Style.RESET_ALL)
            exit()
    except Exception as e:
        print(Fore.RED + f"Error in Validating Roles - {e}" + Style.RESET_ALL)


def get_current_session_status():
    if not os.path.exists(token_file_path) or not os.path.exists(key_file_path):
        print("No session found, please use 'createsession -h'")
        exit()
    enc_token = open(token_file_path, "r").read()
    key = open(key_file_path, "r").read()
    dec_token = decrypt_token(bytes(key, 'utf-8'), enc_token)
    config = decode_auth_token(dec_token)
    current_time = int(time.time())
    if config.get('exp') and current_time < config['exp']:
        current_time = int(time.time())
        time_left = config['exp']-current_time
        print('Session will get timeout after {:.0f} min {:.0f} sec.'.format(int(time_left/60), int(time_left % 60)))
