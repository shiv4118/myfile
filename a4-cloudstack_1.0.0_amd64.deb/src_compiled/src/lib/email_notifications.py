import smtplib
import time
import os
import json
import re
import copy
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from cli import access_aws_account, verify_aws_credentials
from constants import EMAIL_PATH

EMAIL_REGEX = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'


RED = 'red'
YELLOW = 'yellow'
GREEN = 'green'
home_dir = os.path.expanduser("~")
email_config_file_path = os.path.join(home_dir, EMAIL_PATH)
PROJECT = "A4CloudStack"


def send_smpt_email(to_email, email_msg):
    try:
        if not os.path.isfile(email_config_file_path) or not os.access(email_config_file_path, os.R_OK):
            print(f"Project {email_config_file_path} file does not exists")
            exit()
        email_config = json.load(open(email_config_file_path))
        if email_config.get('is_email_activated', False):
            if email_config.get('is_server', False):
                server = smtplib.SMTP(email_config['smtpHost'])
                # server.set_debuglevel(1)
                server.sendmail(email_config['emailSender'], to_email, email_msg)
                print("Email sent successfully to: ", " ".join(to_email))
                server.quit()
            elif email_config.get('is_session', False):
                # Create SMTP session for sending the mail
                kwargs = {"host": email_config['smtpHost']}
                if email_config.get('smtpPort'):
                    kwargs["port"] = email_config['smtpPort']
                session = smtplib.SMTP(**kwargs)  # use gmail with port
                session.starttls()  # enable security
                # login with mail_id and password
                session.login(
                    email_config['smtpSessionUserName'],
                    email_config["smtpSessionUserPassword"]
                )
                session.sendmail(email_config['emailSender'], to_email, email_msg)
                print("Email sent successfully to: ", " ".join(to_email))
                session.quit()
    except Exception as msg:
        print("Error in sending Email to ", msg)


def render_html_body(list_send_mail, str_subject, receiver_name, aws_account, region_name, list_tbl):
    """
    This method is used to get Html Body content for the customised email.
    :param list_send_mail:
    :param str_subject:
    :param receiver_name:
    :param aws_account:
    :param region_name:
    :param list_tbl:
    :return:
    """
    try:
        if not list_send_mail:
            return None
        hi_msg = ("Hi " + receiver_name + ",").strip() if receiver_name else ''
        raw_req_html = """
        <body>
        <table border="0" cellpadding="0" cellspacing="0" width="100%">
        <tbody>
        <tr>
            <td class="template-ptable">
                <table align="center" border="0" cellpadding="0" cellspacing="0" style="border: 1px solid #EAEAEA;border-collapse: collapse;box-shadow: 0px 2px 9px 0px #E2E1E1;">
                <!--!width="500" height="400"-->
                    <tbody>
                        <!--<tr>
                            <td align="center" style="color: #153643; font-size: 28px; font-weight: bold; font-family: Arial, sans-serif;position: relative;"></td>
                        </tr>-->
                        <tr>
                            <td align="center" bgcolor="#000" style="color: #fff; font-size: 28px; font-weight: bold; font-family: Arial, sans-serif;margin: 7px;">
                                      <span style="font-size: 18px;padding-bottom: 40px;"><span style="color: #f90;">""" + PROJECT + """</span> </span>
                                    </div>
                            </td>
                        </tr>
                        <tr>
                            <td bgcolor="#ffffff" align="center" style="padding: 40px 30px 16px 30px;">
                                <table border="0" cellpadding="0" cellspacing="0" width="100%">
                                    <tbody>
                                        <tr>
                                            <td style="font-family: Arial, sans-serif; font-size: 21px;">
                                            <b style="color: #f90;">""" + hi_msg + """</b>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="line-height: 20px;">
                                                This is a notification email for AWS account """
        raw_req_html += str(aws_account) + " (Region:  " + region_name + "). <br/><br/>"
        for str_tbl in list_tbl:
            raw_req_html += str_tbl
        raw_req_html += TABLE_LEGEND_INFO
        raw_req_html += """
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            <!--!<tr>
                                <td class="footer">
                                    <img border="0" style="display:block;" align="Center" src="cid:image2">
                                </td>
                            </tr>-->
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
        <p>*** This is an automatically generated email from """ + PROJECT + """ ***</p>"""
        raw_req_html += "<p>If you would prefer not to receive these emails please disable Email-notification " \
                        "from " + PROJECT + ".</p>"
        raw_req_html += "</body>"
        msgRoot = MIMEMultipart('related')
        msgRoot['Subject'] = PROJECT + (": " + str_subject if str_subject else '')
        # msgRoot['From'] = 'Admin_Vds_Status'
        msgRoot['From'] = PROJECT
        msgRoot['To'] = ''
        msgRoot.preamble = 'This is a multi-part message in MIME format.'
        msgAlternative = MIMEMultipart('alternative')
        msgRoot.attach(msgAlternative)
        msgText = MIMEText('This is the alternative plain text message.')
        msgAlternative.attach(msgText)
        # msgText = MIMEText(raw_req_html.encode('utf-8').strip(), 'html')
        # print(raw_req_html)
        msgText = MIMEText(raw_req_html.strip(), 'html')
        msgAlternative.attach(msgText)
        if list_send_mail:
            send_smpt_email(list_send_mail, msgRoot.as_string())
            time.sleep(1)
    except Exception as err:
        print(err)


def render_html_table(tbl_heading, tbl_row_headings, tbl_row_data):
    """
    This method used to get rendered HTML content providing Table heading and
    data.
    :param tbl_heading:
    :param tbl_row_headings:
    :param tbl_row_data:
    :return:
    """
    if tbl_heading or tbl_row_headings or tbl_row_data:
        if tbl_heading:
            str_tbl = "<b>" + tbl_heading + ":</b>"
        else:
            str_tbl = ""
        str_tbl += """<table border="1" cellpadding="0" cellspacing="0"
        width="100%"><tbody>"""
        if tbl_row_headings:
            str_tbl += '<tr>'
            for col_heading in tbl_row_headings:
                if type(col_heading) == tuple:
                    str_tbl += '<th align="center" bgcolor="' + col_heading[0] \
                               + '">' + str(col_heading[1]) + '</th>'
                else:
                    str_tbl += "<th align='center'>" + str(col_heading) + "</th>"
            str_tbl += "</tr>"
        for list_data in tbl_row_data:
            str_tbl += '<tr>'
            for cel_ele in list_data:
                if type(cel_ele) == tuple:
                    str_tbl += '<td align="center" bgcolor="' + cel_ele[0] \
                               + '">' + str(cel_ele[1]) + '</td>'
                else:
                    str_tbl += '<td align="center">' + str(cel_ele) + '</td>'
            str_tbl += '</tr>'
        str_tbl += '</tbody></table><br/>'
    else:
        str_tbl = ''
    return str_tbl


TABLE_LEGEND_INFO = render_html_table(
    "Legend",
    [
        "Operation Status",
        "Color"
    ],
    [
        [
            "Success",
            (GREEN, '')
        ],
        [
            "Fail",
            (RED, '')
        ],
    ],
)


def send_email_notifications(tables=(), to_list=(), subject='', user='', account='', region=''):
    """
    This method is used render and to send mail.
    :return:
    """
    try:
        if all([tables, to_list, subject, account, region]):
            tbl_list = []
            for table_heading, table_row_heading, table_rows in tables:
                count_tbl = render_html_table(
                    table_heading,
                    table_row_heading,
                    table_rows
                )
                tbl_list.append(count_tbl)
            render_html_body(to_list, subject, user, account, region, tbl_list)
    except Exception as e:
        print(e)


if __name__ == '__main__':
    email_json = {
        "tables": [
            (
                "Resource Status:",
                ["Service", "Operation", "Status"],
                [
                    ["EC2", "Start", (GREEN, "Success")]
                ]
            ),
            (
                "Resource Details:",
                ["Service Name", "ARN"],
                [
                    ["EC2", "ARN:dfdfdf:"]
                ]
            )
        ],
        "to_list": ["gaurav.bora@afourtech.com"],
        "subject": "EC2 created",
        "user": "Gaurav Bora",
        "account": "1234567890",
        "region": "us-east"
    }
    send_email_notifications(**email_json)


def send_email(service_name, service_method):
    """
    Decorator used to send email notifications.
    """
    def func_wrapper(func):
        def inner_wrapper(args):
            config_data = access_aws_account()
            email_str = ''
            if args.__contains__('email'):
                email_str = args.__getattribute__('email')
                args.__delattr__('email')
            operation = ''
            if args.__contains__(service_method):
                operation = args.__getattribute__(service_method)
            output_data = func(args, config_data=config_data)
            if output_data and email_str and operation:
                to_list = email_str.strip().split(',')
                if not any([re.fullmatch(EMAIL_REGEX, email) for email in to_list]) or not to_list:
                    print("Invalid Email address provided to send notification")
                    exit()
                if type(output_data) == dict:
                    refactor_output = copy.deepcopy(output_data)
                    if refactor_output.get('ResponseMetadata'):
                        result_code = refactor_output.get('ResponseMetadata', {}).get('HTTPStatusCode', 400)
                        refactor_output.pop('ResponseMetadata')
                    else:
                        result_code = 200
                    output_str = json.dumps(refactor_output, indent=4, sort_keys=True, default=str)
                elif type(output_data) == str:
                    output_str = output_data
                    result_code = 200
                if result_code >= 400:
                    resp_result = ("red", "Fail")
                else:
                    resp_result = ("green", "Success")
                sts_data = verify_aws_credentials(config_data)
                user_arn = sts_data.get('Arn', '')
                # # TODO: check of other services ARN
                # user_name = user_arn.split(':user/')[-1]
                # 'Arn': 'arn:aws:iam::390618173518:user/gaurav.bora@afourtech.com',
                operation = operation.capitalize()
                sub_list = []
                for separator in ["-", "_"]:
                    if separator in operation:
                        sub_list.extend(operation.split(separator))
                        break
                if not sub_list:
                    sub_list = [operation]
                str_operation = " ".join(sub_list)
                email_json = {
                    "tables": [
                        (
                            "Resource Status",
                            ["Service", "Operation", "Status"],
                            [
                                [service_name, str_operation, resp_result]
                            ]
                        ),
                        (
                            "Operator",
                            [],
                            [
                                ["User ARN", user_arn],
                            ]
                        ),
                        (
                            "Operation output",
                            [],
                            [
                                [output_str]
                            ]
                        )
                    ],
                    "to_list": to_list,
                    "subject": service_name + " " + str_operation + " operation completed",
                    "user": "",
                    "account": sts_data.get('Account', ''),
                    "region": config_data.get('region_name')
                }
                send_email_notifications(**email_json)
            return output_data
        return inner_wrapper
    return func_wrapper
