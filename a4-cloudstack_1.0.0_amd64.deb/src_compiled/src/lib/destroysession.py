#!/usr/bin/env python3

from cli import exit_old_aws_session


if __name__ == '__main__':
    exit_old_aws_session()
