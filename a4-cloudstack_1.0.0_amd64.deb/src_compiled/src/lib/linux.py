import hashlib
import os
import shutil
import errno
import subprocess
import logging

BLOCKSIZE = 65536
log = logging.getLogger(__name__)

def get_md5(file_path):
    """

    :param file_path: Absolute path of the file
    :return: MD5 sum
    """
    try:
        hasher = hashlib.md5()
        with open(file_path, 'rb') as file:
            buf = file.read(BLOCKSIZE)
            while len(buf) > 0:
                hasher.update(buf)
                buf = file.read(BLOCKSIZE)
        log.info("Hasher hexdigest is ".format(hasher.hexdigest()))
        return hasher.hexdigest()
    except Exception as e:
        log.error("error generating checksum: {}".format(str(e)))
        return None


def mount_drive(machine_ip, shared_folder, machine_username, machine_password):
    """

    :param machine_ip: IP of the machine to be mounted from
    :param shared_folder: Shared folder to be mounted
    :param machine_username: Username of the machine to be mounted
    :param machine_password: Password of the machine to be mounted
    :return: None
    """
    try:
        command = "sudo mount -t cifs //" + machine_ip + "/" + shared_folder + " /mnt -o username=" + \
                  machine_username + ",password=" + machine_password
        log.info("Command to be executed is : {}".format(command))
        out = subprocess.check_output(command, shell=True)
    except Exception as out:
        out = str(out)
    log.info("Output from the from the above command: {}".format(out))


def get_filepath_list(dirpath):
    """

    :param dirpath:
    :return:
    """
    filepathlist = []
    for root, dirs, files in os.walk(str(dirpath)):
        for fle in files:
            filepath = os.path.join(root, fle)
            if os.path.isfile(filepath):
                filepathlist.append(str(filepath))
    return filepathlist


def get_all_files(dirpath):
    """
    :param dirpath: Absolute path of the directory
    :return: List of files in the directory
    """
    files_list = []
    for root, dirs, files in os.walk(str(dirpath)):
        for fle in files:
            files_list.append(str(fle))
    return files_list

# mount smb drive
def mount_smb_drive(smb_ip, smb_shared_folder, smb_username, smb_password):
    """
    Mounts an SMB drive
    :param smb_ip: Ip of the machine where the smb folder is present
    :param smb_shared_folder: Name of the shared folder for SMB
    :param smb_username: Username of the SMB machine
    :param smb_password: Password of the SMB machine
    :return: None
    """
    try:
        command = 'sudo umount /mnt/smb_clientshare'
        os.system(command)
        command = "sudo mount -t cifs //" + smb_ip + "/" + smb_shared_folder + " /mnt/smb_clientshare -o " \
                  "username=" + smb_username + ",password=" + smb_password + ",uid=1000"
        log.info("Command ot be executed: {}".format(command))
        out = subprocess.check_output(command, shell=True)
    except Exception as out:
        out = str(out)
    log.info("Output from the above execution".format(out))

# mount nfs drive : install : sudo apt-get install nfs-common : on nfs_client
def mount_nfs_drive(nfs_ip, nfs_shared_folder):
    """

    :param nfs_ip: IP of the machine where the NFS drive is mounted
    :param nfs_shared_folder: The name of the shared folder for NFS
    :return: None
    """
    try:
        command = 'sudo umount /mnt/nfs_clientshare'
        os.system(command)
        command = "sudo mount -t nfs " + nfs_ip + ":" + nfs_shared_folder + " /mnt/nfs_clientshare"
        out = subprocess.check_output(command, shell=True)
        log.info("mount successfully")
    except Exception as out:
        out = str(out)
    log.info("Output from the above command: {}".format(out))


# Change permissions on nfs mount
def change_perm_nfs_mount(nfs_path):
    """

    :param nfs_path: Absolute path of the NFS path
    :return: None
    """
    try:
        command = 'sudo chmod 777 -R ' + nfs_path + '*'
        log.info(command)
        out = subprocess.check_output(command, shell=True)
        log.info("mount successfully")
    except Exception as out:
        out = str(out)
    log.info("Output from the above command: {}".format(out))


# Copying files into a directory
def copy_files_dir(src, dst):
    """

    :param src: The absolute path of the source files
    :param dst: The absolute path of the destination folder
    :return: None
    """
    try:
        if os.path.exists(dst):
            log.info("Destination Directory exist. Removing and copying directory : " + dst)
            shutil.rmtree(dst)
            shutil.copytree(src, dst)
        else:
            log.info("Copying Directory : " + dst)
            shutil.copytree(src, dst)
    except OSError as exc:
        if exc.errno == errno.ENOTDIR:
            log.info("Copying File : " + src)
            shutil.copyfile(src, dst)
        else:
            log.info("Error :: ")
            raise


# returns list of files present under given directory
def get_list(path):
    """

    :param path: Absolute path of the directory
    :return: List of files
    """
    lst = []
    for root, dirs, files in os.walk(str(path)):
        lst.extend(files)
    return lst


# Search regular and non-regular files and folder
def search_file_folder(path, data_path):
    """

    :param path: Absolute path of the directory to be searched
    :param data_path:
    :return: Boolean if file was found or not
    """
    data_path = path + data_path
    log.info("Data path: {}".format(data_path))
    if os.path.isdir(data_path):
        return True
    elif os.path.isfile(data_path):
        return True
    return False


# Delete file or folder
def delete(file_path):
    """

    :param file_path: Absolute path of the file
    :return: Boolean if the file was deleted or not
    """
    log.info("The path of the file: {}".format(file_path))
    try:
        if os.path.isfile(file_path):
            os.remove(file_path)
            log.info("Deleting file\n")
            return True
        elif len(os.listdir(file_path)) == 0:
            log.info("Deleting empty folder\n")
            os.rmdir(file_path)
            return True
        else:
            shutil.rmtree(file_path)
            log.info("Deleting Directory containing files\n")
            return True

    except OSError as e:
        log.info(("Error: %s - %s. \n" % (e.filename, e.strerror)))
        out = "Error: " + str(e.strerror)
        return out
