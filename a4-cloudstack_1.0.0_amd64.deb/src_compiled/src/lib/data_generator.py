import asyncio
import logging
import os

import asyncssh

from lib.common import Common
from lib.ssh import SSH


class DataGenerator:
    def __init__(self, config):
        self.hostname = config["hostname"]
        self.username = config["username"]
        self.password = config["password"]
        self._session = SSH(self.hostname, self.username, self.password)

    def create_files_dd(self, path: str, num_of_files: int, file_size: str, directory: str = "", user: str = ""):
        """
        Method to create files using dd command on given path
        :param path : path where files need to be created
        :param num_of_files: Number of files to be created
        :param file_size: File size in K/M/G/T
        :param directory: directory where file needs to be created
        :param user: user name of user which will create files
        """
        if directory and user:
            logging.info(
                f"Creating {num_of_files} files of {file_size} size in path {path}/{directory} at "
                f"{self.hostname} client from user {user}"
            )
            cmd = (
                f"mkdir {path}/{directory} ;chmod 777 {path}/{directory} ;for i in `seq 1 {num_of_files}`; "
                f"do sudo -u {user} dd if=/dev/zero of={path}/{directory}/file$i bs=4k iflag=fullblock,count_bytes "
                f"count={file_size} conv=fdatasync; done"
            )
        elif directory:
            logging.info(
                f"Creating {num_of_files} files of {file_size} size in path {path}/{directory} at "
                f"{self.hostname} client"
            )
            cmd = (
                f"mkdir {path}/{directory} ;for i in `seq 1 {num_of_files}`; "
                f"do dd if=/dev/zero of={path}/{directory}/file$i bs=4k iflag=fullblock,count_bytes "
                f"count={file_size} conv=fdatasync; done"
            )
        elif user:
            logging.info(
                f"Creating {num_of_files} files of {file_size} size in path {path} at "
                f"{self.hostname} client from user {user}"
            )
            cmd = (
                f"for i in `seq 1 {num_of_files}`; "
                f"do sudo -u {user} dd if=/dev/zero of={path}/file$i bs=4k iflag=fullblock,count_bytes "
                f"count={file_size} conv=fdatasync; done"
            )
        else:
            logging.info(f"Creating {num_of_files} files of {file_size} size in path {path} at {self.hostname} client")
            cmd = (
                f"for i in `seq 1 {num_of_files}`; "
                f"do dd if=/dev/zero of={path}/file$i bs=4k iflag=fullblock,count_bytes "
                f"count={file_size} conv=fdatasync; done"
            )
        _, stdout, _ = self._session.exec_command(cmd)
        assert f"{file_size[:-1]} {file_size[-1]}" in stdout, f"Error in file creation. Output: {stdout}"

        file_count = self.get_file_count(path, directory)
        assert file_count == num_of_files, f"Error in total file count. Current count {file_count}"
        logging.info(f"Files created successfully")

    def get_file_count(self, path: str, directory: str = "") -> int:
        """
        Method to check files in given mount points
        :param path : Path where file count need to check
        :param directory: Directory where files need to be checked
        :return number of files
        """
        logging.info(f"Connecting to client: {self.hostname}")
        if directory:
            logging.info(f"Checking files in path {path} under directory {directory}")
            cmd = f"ls {path}/{directory} | wc -l"
        else:
            logging.info(f"Checking files in path {path}")
            cmd = f"ls {path} | wc -l"
        _, file_count, _ = self._session.exec_command(cmd)
        return int(file_count)

    def create_vdbench_config_file(
        self, num_of_files: int, file_size: str, depth: str = 1, width: str = 1, time: int = 10
    ):
        """
        Method to create the config file for vdbench (create files and perform random write for given time)
        :param num_of_files: Number of files
        :param file_size: File size in K/M/G/T
        :param depth: directory depth
        :param width: directory width
        :param time: Total time for random write
        :return: config file path
        """
        file_path = os.path.join(Common.project_path(), "testdata/data_generator", "vdbench_config")
        file = open(file_path, "w")

        # Write data in config file
        file.write(f"fsd=fsd1,anchor=$path,depth={depth},width={width},files={num_of_files},size={file_size}\n")
        file.write("fwd=fwd1,fsd=fsd1,rdpct=0,xfersize=1024k,fileselect=random,fileio=random,threads=1\n")
        file.write(f"rd=rd1,fwd=fwd1,fwdrate=max,format=yes,elapsed={time},interval=5")
        file.close()

        # Read data from config file
        file = open(file_path)
        content = file.read()
        file.close()

        # Validate config file
        assert str(num_of_files) in content and file_size in content, f"Error in file content. File content: {content}"
        logging.info(f"Vdbench config file created successfully with content: {content}")
        return file_path

    def transfer_config_file(self, file_path: str, destination_path: str):
        """
        Method to transfer vdbench config file to host
        :param file_path: vdbench config file path
        :param destination_path: Path where file need to be copied
        :return: config file path at remote host
        """
        logging.info(f"Transfer vdbench config file to remote host")
        self._session.sftp_transfer(file_path, f"{destination_path}/vdbench_config")
        cmd = f"ls {destination_path}"
        _, out, _ = self._session.exec_command(cmd)
        assert "vdbench_config" in out, f"Error in file transfer. {out}"
        logging.info(f"File transferred successfully")
        return f"{destination_path}/vdbench_config"

    async def run_vdbench(self, vdbench_path: str, config_file_path: str, path: str):
        """
        Method to create files and perform IO
        :param vdbench_path: vdbench binary path
        :param config_file_path: vdbench config file path at remote host
        :param path: Path where files will be created
        :return: vdbench output
        """
        async with asyncssh.connect(
            self.hostname, username=self.username, password=self.password, known_hosts=None, agent_path=None
        )as conn:
            cmd = f"{vdbench_path} path={path} -f {config_file_path} -o {path}/output"
            vd_out = await conn.run(cmd)
            return vd_out

    def run_validate_vdbench_io(self, vdbench_path: str, config_file_path: str, path: str, vdbench_instances: int = 1):
        """
        Method to create files and perform IO
        :param vdbench_path: vdbench binary path
        :param config_file_path: vdbench config file path at remote host
        :param path: Path where files will be created
        :param vdbench_instances: Number of vdbench instances to be run
        """
        success_msg = "Vdbench execution completed successfully"
        logging.info(f"Running {vdbench_instances} vdbench instances to generate IO")
        loop = asyncio.get_event_loop()
        tasks = [
            asyncio.ensure_future(
                self.run_vdbench(vdbench_path, config_file_path, f"{path}{instance}")
            ) for instance in range(vdbench_instances)
        ]
        vdbench_output = loop.run_until_complete(asyncio.gather(*tasks))
        for output in vdbench_output:
            assert success_msg in output.stdout, f"Error in vdbench run. Output: {output}"
        logging.info("All Vdbench instances executed successfully")
