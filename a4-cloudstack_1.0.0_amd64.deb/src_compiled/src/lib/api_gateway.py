import logging

import boto3
from botocore.exceptions import ClientError

from constants import *


class ApiGateway:
    def __init__(self, config):
        self.client = boto3.client(
            "apigateway", **config
        )
        self.config = config

    def get_apis(self, **kwargs):
        """
        Method to get the information about the APIs
        :param kwargs: position/limit
        :return api_info
        """
        try:
            api_info = self.client.get_rest_apis(**kwargs)
            return api_info
        except ClientError as err:
            logging.info(f"Get API failed with error: {err.response['Error']['Code']}")

    def get_api_id(self, api_name: str):
        """
        Method to get API id for given API
        :param api_name: api name
        :return api_id
        """
        logging.info(f"Checking the api ID of API {api_name}")
        api_info = self.get_apis()
        assert api_info['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Error in getting the api attribute. Output {api_info}"
        )
        for api in api_info['items']:
            if api['name'] == api_name:
                logging.info(f"API ID : {api['id']}")
                return api['id']
        else:
            raise ValueError(f"Api {api_name} not found")

    def get_stages_info(self, api_id: str, **kwargs):
        """
        Method to get the stages information about the API
        :param api_id: API Id
        :param kwargs: deploymentId
        :return stage_info
        """
        try:
            stage_info = self.client.get_stages(restApiId=api_id, **kwargs)
            return stage_info
        except ClientError as err:
            logging.info(f"Get API attribute failed with error: {err.response['Error']['Code']}")

    def validate_get_stages_info(self, api_id: str, **kwargs):
        """
        Method to get & validate the stages information about the API
        :param api_id: API Id
        :param kwargs: deploymentId
        :return stage_info
        """
        logging.info(f"Checking the stages of API with id {api_id}")
        stage_info = self.get_stages_info(api_id, **kwargs)
        assert stage_info['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Error in getting the api attribute. Output {stage_info}"
        )
        logging.info(f"Stages in API: ")
        for stage in stage_info['item']:
            logging.info(stage['stageName'])
        return stage_info

    def get_api_invoke_url(self, api_name: str):
        """
        Method to get api invoke URL
        :param api_name: API name
        :return api_url list
        """
        urls = []
        api_id = self.get_api_id(api_name)
        stage_info = self.validate_get_stages_info(api_id)
        for stage in stage_info['item']:
            urls.append(
                f"https://{api_id}.execute-api.{self.config['region_name']}.amazonaws.com/{stage['stageName']}"
            )
        return urls
