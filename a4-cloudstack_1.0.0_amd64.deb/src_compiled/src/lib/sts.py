#!/usr/bin/env python3
import argparse
import logging
import sys

import boto3
from pprint import pprint
from botocore.exceptions import ClientError
from colorama import Fore, Style

from email_notifications import send_email
from constants import RESPONSE_OK


class STS:
    def __init__(self, config, command_line=False):
        self.sts_client = boto3.client(
            'sts', **config
        )
        self.config = config
        self.command_line = command_line
        if command_line:
            logging.basicConfig(level=logging.INFO, format='%(message)s')
            sys.tracebacklimit = 0

    def get_sts_creds(self, creds):
        """
        Get the temporary credentials
        :param creds: Required dict parameters
        :return: Https Response
        """
        try:
            response = self.sts_client.get_session_token(**creds)
            pprint(response.get('Credentials', "No credentials generated."))
            return response.get('Credentials', "No credentials generated.")
        except ClientError as err:
            print(Fore.RED)
            logging.error(f"Get creds failed with err: {err}")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def get_assume_role_sts_creds(self, creds):
        """
        Get the temporary credentials by assumed role
        :param creds: Required dict parameters
        :return: Https Response
        """
        try:
            response = self.sts_client.assume_role(**creds)
            pprint(response.get('Credentials', "No credentials generated"))
        except ClientError as err:
            print(Fore.RED)
            logging.error(f"Get creds failed with err: {err}")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def get_sts_caller_identity(self):
        """
        Get sts caller id include UserID, Account and Arn (service based IAM, Role etc.)
        :return: Https Response
        """
        try:
            response = self.sts_client.get_caller_identity()
            if 'ResponseMetadata' in response:
                response.pop('ResponseMetadata')
            if self.command_line:
                pprint(response)
            return response
        except ClientError as err:
            print(Fore.RED)
            logging.error(f"Get sts caller identity failed with err: {err}")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()


def main():
    parser = argparse.ArgumentParser()
    sts_method_subparser = parser.add_subparsers(dest='sts_method')

    # Get Cred
    get_creds_parser = sts_method_subparser.add_parser("get-creds", help="Get temporary credentials")
    get_creds_parser.add_argument("--DurationSeconds", type=int,
                                  help="The duration, in seconds, that the credentials should remain valid. [default=3600sec]",
                                  default=argparse.SUPPRESS)
    get_creds_parser.add_argument("--email", type=str,
                                  help="Specify email ID to send email notification (Multiple comma-separated "
                                       "email IDs are acceptable)",
                                  default=argparse.SUPPRESS)

    # Get Assume Role
    assume_role_parser = sts_method_subparser.add_parser(
        "assume-role",
        help="Get temporary security credentials that you can use to access Amazon Web Services "
             "resources that you might not normally have access to"
    )
    assume_role_parser.add_argument("--RoleArn", type=str,
                                    help="Key of the object" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                    required=True)
    assume_role_parser.add_argument("--RoleSessionName", type=str,
                                    help="Key of the object" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                    required=True)
    assume_role_parser.add_argument("--DurationSeconds", type=int,
                                    help="The duration, in seconds, that the credentials should remain valid.",
                                    default=argparse.SUPPRESS)

    # Get get_sts_caller_identity
    _caller_identity_parser = sts_method_subparser.add_parser(
        "caller-identity",
        help="Returns details about the IAM user or role whose credentials are used to call the operation."
    )

    args = parser.parse_args()
    if not args.sts_method:
        parser.print_help()
        return
    parse_args_to_execute(args)


@send_email("STS", "sts_method")
def parse_args_to_execute(args, config_data=None):
    if args.sts_method and config_data:
        sts_obj = STS(config_data, command_line=True)
        args_dict = vars(args)
        if args.sts_method == "get-creds":
            del args_dict['sts_method']
            return sts_obj.get_sts_creds(args_dict)
        elif args.sts_method == "assume-role":
            del args_dict['sts_method']
            sts_obj.get_assume_role_sts_creds(args_dict)
        elif args.sts_method == "caller-identity":
            sts_obj.get_sts_caller_identity()


if __name__ == '__main__':
    main()
