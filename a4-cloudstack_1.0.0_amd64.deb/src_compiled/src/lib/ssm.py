import logging
import time
from typing import List, Dict

import boto3
from botocore.exceptions import ClientError

from constants import *


class SSM:
    def __init__(self, config):
        self.client = boto3.client(
            "ssm", **config
        )

    def list_managed_instances(self):
        """
        Method to list all the managed instances.
        :return: instances
        """
        try:
            instances = self.client.describe_instance_information()
            return instances
        except ClientError as err:
            if err.response['Error']['Code'] == "InvalidInstanceId":
                logging.info("Invalid InstanceId, Please provide correct instance ID")
            else:
                logging.info(f"Managed instance listing failed wir err: {err.response['Error']['Code']}")

    def list_validate_managed_instances(self, instance_id: str = ""):
        """
        Method to validate if the managed instance/instances are listed
        :param instance_id: Instance id
        :return None/Managed Instance List
        """
        managed_instances_id = []
        instances = self.list_managed_instances()
        assert instances, f"Error in listing managed instances: {instances}"
        for instance in instances['InstanceInformationList']:
            managed_instances_id.append(instance["InstanceId"])
        if instance_id:
            logging.info(f"Checking if instance with id {instance_id} is SSM managed instance")
            assert instance_id in managed_instances_id, (
                f"Instance is not SSM managed instance. Managed instance {managed_instances_id}"
            )
            logging.info(f"Instance with id {instance_id} is SSM managed instance")
        else:
            logging.info("Listing all the managed instance.")
            for instance in managed_instances_id:
                logging.info(instance)
            return managed_instances_id

    def run_shell_command(self, cmd: str, instance_ids: List, **kwargs):
        """
        Method to run a shell command on given managed instance
        :param cmd: Command to be executed.
        :param instance_ids: List of instance Ids
        :param kwargs:
        :return: command output
        """
        cmd_out = {}
        response = self.client.send_command(
            InstanceIds=instance_ids, DocumentName="AWS-RunShellScript", Parameters={'commands': [cmd]}, **kwargs
        )
        command_id = response['Command']['CommandId']
        time.sleep(10)
        for instance in instance_ids:
            output = self.client.get_command_invocation(CommandId=command_id, InstanceId=instance)
            if output['Status'] == "Success":
                cmd_out[instance] = output['StandardOutputContent']
        return cmd_out

    def validate_run_shell_command(self, cmd: str, instance_ids: List, **kwargs):
        """
        Method to validate and run shell command
        :param cmd: Command to be executed.
        :param instance_ids: List of instance Ids
        :param kwargs:
        """
        run_cmd = self.run_shell_command(cmd, instance_ids, **kwargs)
        assert run_cmd, f"Error in running the command"
        for item in run_cmd:
            logging.info(f"Command output on {item} instance is: {run_cmd[item]}")

    def scan_patch_instance(self, operation: str, **kwargs):
        """
        Method to scan/patch an instance against a default baseline.
        :param operation: Scan/Install a patch
        :param kwargs:
        :return: scan output
        """
        scan_patch = {}
        output = {}
        if operation == "Install":
            attempt = 720
        else:
            attempt = 120
        response = self.client.send_command(
            DocumentName="AWS-RunPatchBaseline", Parameters={'Operation': [operation]}, **kwargs
        )
        command_id = response['Command']['CommandId']
        time.sleep(10)
        for _ in range(attempt):
            output = self.client.list_command_invocations(CommandId=command_id)
            if (output["CommandInvocations"][0]["Status"] != "InProgress") and (
                    output["CommandInvocations"][0]["Status"] != "Pending"):
                break
            time.sleep(5)
        else:
            logging.info(f"{operation} not completed after {attempt*5} seconds")

        for instance in output['CommandInvocations']:
            scan_patch[instance['InstanceId']] = instance["Status"]
        return scan_patch

    def scan_patch_validate_instance(self, operation: str, **kwargs):
        """
        Method to scan/patch an instance against a default baseline.
        :param operation: Scan/Install a patch
        :param kwargs:
        """
        scan_patch = self.scan_patch_instance(operation, **kwargs)
        for instance in scan_patch:
            assert scan_patch[instance] == "Success", f"Scan failed with error: {scan_patch[instance]}"
            if operation == "Scan":
                logging.info(f"Scan executed successfully on instance '{instance}'")
            else:
                logging.info(f"Patch deployed successfully on instance '{instance}'")

    def get_missing_patches(self, instance_id: str, **kwargs):
        """
        Method to list the missing patches in given instances
        :param instance_id: instance id of managed instance
        :param kwargs:
        :return: Missing patch count, Missing patch count
        """
        instance_status = self.client.describe_instance_patch_states(InstanceIds=[instance_id], **kwargs)
        missing_patches = instance_status["InstancePatchStates"][0]["MissingCount"]

        missing_patch_list = self.client.describe_instance_patches(
            InstanceId=instance_id, Filters=[{'Key': "State", 'Values': ["MISSING"]}]
        )
        return missing_patches, missing_patch_list["Patches"]

    def get_validate_missing_patches(self, instance_id: str, **kwargs):
        """
        Method to list the missing patches in given instances
        :param instance_id: instance id of managed instance
        :param kwargs:
        """
        missing_patch, missing_patch_list = self.get_missing_patches(instance_id, **kwargs)
        assert missing_patch >= 0, f"Error in getting missing patch count."
        if missing_patch > 0:
            logging.info(f"There are {missing_patch} patches missing in the instance")
            logging.info("Missing patch list:")
            for patch in missing_patch_list:
                logging.info(patch["Title"])
        else:
            logging.info("There are no missing patches in the instance")

    def create_patch_baseline(
        self, operatingsystem: str, name: str, approvalrules: Dict = "", approvedpatches: List = "", **kwargs
    ):
        """
        Method to create a patch baseline
        :param operatingsystem: Windows/Amazon Linux/Amazon Linux 2/CentOS/Ubuntu/Red Hat Enterprise Linux/SUSE
        :param name: Patch baseline name
        :param approvalrules: set of rules used to include patches in the baseline
        :param approvedpatches: List of ApprovedPatches for patch baseline
        :return: baseline ID
        """
        if approvalrules and not approvedpatches:
            baseline = self.client.create_patch_baseline(
                OperatingSystem=operatingsystem.upper(), Name=name, ApprovalRules=approvalrules, **kwargs
            )
        elif approvedpatches and not approvalrules:
            baseline = self.client.create_patch_baseline(
                OperatingSystem=operatingsystem.upper(), Name=name, ApprovedPatches=approvedpatches, **kwargs
            )
        elif approvedpatches and approvalrules:
            baseline = self.client.create_patch_baseline(
                OperatingSystem=operatingsystem.upper(), Name=name, ApprovalRules=approvalrules,
                ApprovedPatches=approvedpatches, **kwargs
            )
        else:
            raise Exception(f"Please provide either ApprovalRules or ApprovedPatches")
        return baseline["BaselineId"]

    def create_validate_patch_baseline(
        self, operatingsystem: str, name: str, approvalrules: Dict = "", approvedpatches: List = "", **kwargs
    ):
        """
        Method to create and validate a patch baseline
        :param operatingsystem: Windows/Amazon Linux/Amazon Linux 2/CentOS/Ubuntu/Red Hat Enterprise Linux/SUSE
        :param name: Patch baseline name
        :param approvalrules: set of rules used to include patches in the baseline
        :param approvedpatches: List of ApprovedPatches for patch baseline
        :return: Patch baseline id
        """
        logging.info(f"Creating custom patch baseline for {operatingsystem} operating system")
        patch_baseline = self.create_patch_baseline(operatingsystem, name, approvalrules, approvedpatches, **kwargs)
        assert patch_baseline, f"Error in create patch baseline. Output: {patch_baseline}"
        logging.info(f"Custom patch base line created with baseline id: {patch_baseline}")
        return patch_baseline

    def get_patch_baselines(self, **kwargs):
        """
        Method to get all the patch baseline
        :param kwargs:
        :return: baseline info list
        """
        baselines = self.client.describe_patch_baselines(**kwargs)
        return baselines["BaselineIdentities"]

    def get_validate_patch_baselines(self, baseline_id: str = "", **kwargs):
        """
        Method to validate if the patch baseline/baselines are listed
        :param baseline_id: baseline id
        :param kwargs:
        :return: None/Baseline Ids
        """
        baseline_ids = []
        baselines = self.get_patch_baselines(**kwargs)
        assert baselines, f"Error in listing patch baselines: {baselines}"
        for baseline in baselines:
            baseline_ids.append(baseline['BaselineId'])
        if baseline_id:
            logging.info(f"Checking if baseline with id {baseline_id} is listed")
            assert baseline_id in baseline_ids, (
                f"baseline id is not listed in baseline list {baseline_ids}"
            )
            logging.info(f"Baseline with id {baseline_id} is present in patch baseline list")
        else:
            return baseline_ids

    def register_patch_group_baseline(self, baselineid: str, patch_group_name: str):
        """
        Method to register a patch baseline for a patch group.
        :param baselineid: Patch baseline ID
        :param patch_group_name: Patch group name
        :return: patch group
        """
        try:
            group = self.client.register_patch_baseline_for_patch_group(
                BaselineId=baselineid, PatchGroup=patch_group_name
            )
            return group
        except ClientError as err:
            if err.response['Error']['Code'] == 'AlreadyExistsException':
                logging.info(
                    f"Patch group registration failed as patch group is registered with another baseline for same OS"
                )
            else:
                logging.info(f"Patch group registration failed with error {err.response['Error']['Code']}")

    def register_validate_patch_group_baseline(self, baselineid: str, patch_group_name: str):
        """
        Method to register a patch baseline for a patch group.
        :param baselineid: Patch baseline ID
        :param patch_group_name: Patch group name
        :return: patch group
        """
        logging.info(
            f"Register {patch_group_name} patch group to patch baseline with id {baselineid}")
        patch_register = self.register_patch_group_baseline(baselineid, patch_group_name)
        assert patch_register, f"Error in patch group registration."
        assert patch_register['BaselineId'] == baselineid and patch_register['PatchGroup'] == patch_group_name, (
            f"Error in patch group registration. {patch_register}"
        )
        logging.info("Patch group registered successfully")

    def list_patch_group(self, **kwargs):
        """
        Method to list all patch groups that have been registered with patch baselines.
        :param kwargs: MaxResults/Filters/NextToken
        :return: patch groups mapping
        """
        patch_groups = self.client.describe_patch_groups(**kwargs)
        return patch_groups['Mappings']

    def list_validate_patch_group(self, patch_group_name: str = "", negative_case: bool = False, **kwargs):
        """
        Method to validate if the patch baseline/baselines are listed
        :param patch_group_name: patch group name
        :param negative_case: True/False
        :param kwargs:
        :return: patch_groups
        """
        patch_groups = []
        patch_info = self.list_patch_group(**kwargs)
        assert patch_info, f"Error in patch group list. Output: {patch_info}"
        for grp in patch_info:
            patch_groups.append(grp['PatchGroup'])
        if patch_group_name:
            logging.info(f"Checking if patch group '{patch_group_name}' is listed")
            if negative_case:
                assert patch_group_name not in patch_groups, (
                    f"Patch group listed in patch list. Output: {patch_info}"
                )
                logging.info(f"{patch_group_name} patch group not present in list of patch groups")
            else:
                assert patch_group_name in patch_groups, (
                    f"Patch group not in patch list. Output: {patch_info}"
                )
                logging.info(f"{patch_group_name} patch group present in list of patch groups")
        else:
            return patch_groups

    def deregister_patch_group_baseline(self, baselineid: str, patch_group_name: str):
        """
        Method to deregister a patch baseline for a patch group.
        :param baselineid: Patch baseline ID
        :param patch_group_name: Patch group name
        :return: patch group
        """
        try:
            group = self.client.deregister_patch_baseline_for_patch_group(
                BaselineId=baselineid, PatchGroup=patch_group_name
            )
            return group
        except ClientError as err:
            if err.response['Error']['Code'] == 'InvalidResourceId':
                logging.info(
                    f"Patch group deregistration failed as patch group is not registered with given baseline"
                )
            else:
                logging.info(f"Patch group deregistration failed with error: {err.response['Error']['Code']}")

    def deregister_validate_patch_group_baseline(self, baselineid: str, patch_group_name: str):
        """
        Method to deregister a patch baseline for a patch group.
        :param baselineid: Patch baseline ID
        :param patch_group_name: Patch group name
        """
        logging.info(f"Deregister patch group '{patch_group_name}' from  patch baseline '{baselineid}'")
        p_deregister = self.deregister_patch_group_baseline(baselineid, patch_group_name)
        assert p_deregister['BaselineId'] == baselineid, (
            f"Error in patch group deregistration. Output: {p_deregister}"
        )
        logging.info(f"Patch group deregistered from patch baseline")

    def delete_patch_baseline(self, baselineid: str):
        """
        Method to delete a custom patch baseline
        :param baselineid: Patch baseline ID
        :return: The ID of the deleted patch baseline
        """
        try:
            delete_baseline = self.client.delete_patch_baseline(BaselineId=baselineid)
            return delete_baseline
        except ClientError as err:
            if err.response['Error']['Code'] == "ResourceInUseException":
                logging.info(
                    "Delete baseline failed as baseline is being used by a patch group OR its default baseline"
                )
            else:
                logging.info(f"Patch baseline delete failed with error: {err.response['Error']['Code']}")

    def delete_validate_patch_baseline(self, baselineid: str, negative_case: bool = False):
        """
        Method to delete and validate a custom patch baseline
        :param baselineid: Patch baseline ID
        :param negative_case: True/False for negative scenario
        """
        logging.info(f"Deleting patch baseline {baselineid}")
        delete_baseline = self.delete_patch_baseline(baselineid)
        if negative_case:
            assert not delete_baseline, f"Baseline deleted which is not expected. Output: {delete_baseline}"
            logging.info("Patch baseline not deleted as expected")
        else:
            assert delete_baseline['BaselineId'] == baselineid, (
                f"Error in baseline delete. {delete_baseline}"
            )
            logging.info("Patch baseline deleted successfully.")

    def register_default_patch_baseline(self, baselineid: str):
        """
        Method to register a patch baseline to default patch baseline
        :param baselineid: Patch baseline ID
        :return: The ID of the patch baseline
        """
        try:
            default_baseline = self.client.register_default_patch_baseline(BaselineId=baselineid)
            return default_baseline
        except ClientError as err:
            if err.response['Error']['Code'] == "InvalidResourceId":
                logging.info("invalid baseline Id")
            else:
                logging.info(f"Patch baseline delete failed with error: {err.response['Error']['Code']}")

    def register_validate_default_patch_baseline(self, baselineid: str):
        """
        Method to register a patch baseline to default patch baseline
        :param baselineid: Patch baseline ID
        """
        logging.info(f"Register baseline {baselineid} to default patch baseline.")
        baseline = self.register_default_patch_baseline(baselineid)
        assert baseline, f"Error in default baseline registration"
        assert baseline["BaselineId"] == baselineid, f"Error in default baseline registration. Output: {baseline}"
        logging.info("Baseline registered to default baseline")

    def update_patch_baseline(self, baseline_id: str, **kwargs):
        """
        Method to update a given patch baseline
        :param baseline_id: Patch baseline ID
        :param kwargs: Name/GlobalFilters/ApprovalRules/ApprovedPatches/ApprovedPatchesComplianceLevel/
        ApprovedPatchesEnableNonSecurity/RejectedPatches/RejectedPatchesAction/Description/Sources/Replace
        :return: update_response
        """
        try:
            update_response = self.client.update_patch_baseline(BaselineId=baseline_id, **kwargs)
            return update_response
        except ClientError as err:
            logging.info(f"Patch baseline update failed with error: {err.response['Error']['Code']}")

    def update_validate_patch_baseline(self, baseline_id: str, negative_case: bool = False, **kwargs):
        """
        Method to update and validate a given patch baseline
        :param baseline_id: Patch baseline ID
        :param negative_case: True/False for negative scenario
        :param kwargs: Name/GlobalFilters/ApprovalRules/ApprovedPatches/ApprovedPatchesComplianceLevel/
        ApprovedPatchesEnableNonSecurity/RejectedPatches/RejectedPatchesAction/Description/Sources/Replace
        """
        if not kwargs:
            raise ValueError("Please provide parameter which needs to be updated")
        logging.info(f"Updating '{kwargs}' values for patch baseline with id {baseline_id}")
        update_response = self.update_patch_baseline(baseline_id, **kwargs)
        if negative_case:
            assert not update_response, f"Baseline updated which is not expected. Output: {update_response}"
            logging.info(f"Patch baseline not updated as expected.")
        else:
            assert all(item in update_response.items() for item in kwargs.items()), (
                f"Error in baseline update. Output: {update_response}"
            )
            logging.info("Patch baseline updated successfully.")

    def create_validate_maintenance_window(
            self, name: str, schedule: str, duration: int, cutoff: int, allow_unassociated_targets: bool, **kwargs
    ):
        """
        Validation method to validate maintenance window
        :param name: Name of the maintenance window
        :param schedule: Schedule of the window
        :param duration: Duration of the window
        :param cutoff: The number of hours before the end of the maintenance window that Systems Manager stops
        scheduling new tasks for execution.
        :param allow_unassociated_targets: allow_unassociated_targets
        :param kwargs: Description/StartDate/EndDate/ScheduleTimezone/ScheduleOffset/ClientToken/Tags
        :return: Created maintenance window ID
        """
        create_maintenance_window = self.create_maintenance_window(
            name, schedule, duration, cutoff, allow_unassociated_targets, **kwargs
        )
        assert create_maintenance_window, f"Failed to get the response of the create maintenance window {name}"
        assert create_maintenance_window['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Failed to verify response code. Expected: '{RESPONSE_OK}' but found "
            f"'{create_maintenance_window['ResponseMetadata']['HTTPStatusCode']}'"
        )
        self.get_validate_maintenance_window(create_maintenance_window['WindowId'], name)
        logging.info(f"Successfully created maintenance window of name '{name}'")
        return create_maintenance_window['WindowId']

    def create_maintenance_window(
            self, name: str, schedule: str, duration: int, cutoff: int, allow_unassociated_targets: bool, **kwargs
    ):
        """
        Method to create maintenance window
        :param name: Name of the maintenance window
        :param schedule: Schedule of the window
        :param duration: Duration of the window
        :param cutoff: The number of hours before the end of the maintenance window that Systems Manager stops
        scheduling new tasks for execution.
        :param allow_unassociated_targets: allow_unassociated_targets
        :param kwargs: Description/StartDate/EndDate/ScheduleTimezone/ScheduleOffset/ClientToken/Tags
        :return: Response of the create maintenance window
        """
        try:
            return self.client.create_maintenance_window(
                Name=name, Schedule=schedule, Duration=duration, Cutoff=cutoff,
                AllowUnassociatedTargets=allow_unassociated_targets, **kwargs
            )
        except ClientError as err:
            logging.error(err)
            logging.error(f"Failed to create maintenance window of name '{name}'")

    def get_validate_maintenance_window(self, window_id: str, name: str):
        """
        Validation method to get maintenance window
        :param window_id: Id of the window
        :param name: Name of the window
        """
        maintenance_window = self.get_maintenance_window(window_id)
        assert maintenance_window, f"Failed to get response of get maintenance window. '{maintenance_window}'"
        assert maintenance_window['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Failed to verify response code. Expected: '{RESPONSE_OK}' but found "
            f"'{maintenance_window['ResponseMetadata']['HTTPStatusCode']}'"
        )
        assert maintenance_window['Name'] == name, (
            f"Failed to assert maintenance window name. Expected '{name}' but found '{maintenance_window['Name']}'"
        )
        logging.info(f"Successfully retrieved the maintenance window '{maintenance_window}'")

    def get_maintenance_window(self, window_id: str):
        """
        Method to get maintenance window
        :param window_id: Id of the window
        :return: Response of the get maintenance window
        """
        try:
            return self.client.get_maintenance_window(WindowId=window_id)
        except ClientError as err:
            logging.error(err)
            logging.error(f"Failed to get the maintenance window of id '{window_id}'")

    def update_validate_maintenance_window(self, window_id: str, **kwargs):
        """
        Method to update maintenance window
        :param window_id: Window Id
        :param kwargs: Name/Description/StartDate/EndDate/Schedule/ScheduleTimezone/ScheduleOffset/Duration/Cutoff/
        AllowUnassociatedTargets/Enabled/Replace
        """
        update_window = self.update_maintenance_window(window_id, **kwargs)
        assert update_window, f"Failed to get the response of the maintenance window. Output: {update_window}"
        assert update_window['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Failed to verify response code. Expected: '{RESPONSE_OK}' but found "
            f"'{update_window['ResponseMetadata']['HTTPStatusCode']}'"
        )
        logging.info(f"Successfully updated the maintenance window '{window_id}'")

    def update_maintenance_window(self, window_id: str, **kwargs):
        """
        Method to update the window of the maintenance window
        :param window_id: Window id
        :param kwargs: Name/Description/StartDate/EndDate/Schedule/ScheduleTimezone/ScheduleOffset/Duration/Cutoff/
        AllowUnassociatedTargets/Enabled/Replace
        :return: Response of the maintenance window
        """
        try:
            return self.client.update_maintenance_window(WindowId=window_id, **kwargs)
        except ClientError as err:
            logging.error(f"Failed to update the maintenance window with error {err}")

    def validate_describe_maintenance_window_executions(self, window_id: str, **kwargs):
        """
        Validation method to describe the response of the maintenance window execution
        :param window_id: Id of the window
        :param kwargs: Filters/MaxResults/NextToken
        """
        describe_window = self.describe_maintenance_window_executions(window_id, **kwargs)
        assert describe_window, f"Failed to describe maintenance window executions"
        assert describe_window['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Failed to verify response code. Expected: '{RESPONSE_OK}' but found "
            f"'{describe_window['ResponseMetadata']['HTTPStatusCode']}'"
        )
        msg1 = "Window does not have any execution"
        msg2 = f"Windows execution is {describe_window['WindowExecutions']}"
        logging.info(msg1 if len(describe_window['WindowExecutions']) is 0 else msg2)
        logging.info(f"Successfully described the maintenance window executions of window '{window_id}'")

    def describe_maintenance_window_executions(self, window_id: str, **kwargs):
        """
        Method to describe maintenance window execution
        :param window_id: Id of the window
        :param kwargs: Filters/MaxResults/NextToken
        :return: Response of the describe maintenance window executions
        """
        try:
            return self.client.describe_maintenance_window_executions(WindowId=window_id, **kwargs)
        except ClientError as err:
            logging.error(f"Failed to update the maintenance window with err {err}")

    def delete_validate_maintenance_window(self, window_id: str):
        """
        Validation method to delete maintenance window
        :param window_id: Id of the window
        """
        delete_window = self.delete_maintenance_window(window_id)
        assert delete_window, f"Failed to get response of delete window. Output: '{delete_window}'"
        assert delete_window['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Failed to verify response code. Expected: '{RESPONSE_OK}' but found "
            f"'{delete_window['ResponseMetadata']['HTTPStatusCode']}'"
        )
        assert delete_window['WindowId'] == window_id, (
            f"Failed to assert maintenance window id. Expected '{window_id}' but found '{delete_window['WindowId']}'"
        )
        logging.info(f"Successfully deleted the maintenance window of id '{window_id}'")

    def delete_maintenance_window(self, window_id: str):
        """
        Method to delete the maintenance window
        :param window_id: ID of the window
        :return: Response of the delete maintenance window
        """
        try:
            return self.client.delete_maintenance_window(WindowId=window_id)
        except ClientError as err:
            logging.error(f"Failed to delete maintenance window of id '{window_id}' with err {err}")
