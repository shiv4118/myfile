#!/usr/bin/env python3
import argparse
import json
import logging
import sys
import os
import datetime
import logging.handlers

import boto3
from botocore.exceptions import ClientError
from colorama import Fore, Style

from email_notifications import send_email
from constants import *


class CloudWatch:
    def __init__(self, config, command_line=False):
        self.cloudwatch_client = boto3.client(
            "cloudwatch", **config
        )
        self.config = config
        self.command_line = command_line
        if command_line:
            home_dir = os.path.expanduser("~")
            # logging.basicConfig(level=logging.INFO, format='%(message)s')
            # sys.tracebacklimit = 0
            cur_date = datetime.datetime.now().strftime("%d_%b_%Y")
            log_dir_path = os.path.join(home_dir, ".a4cloudstack_logs")
            final_log_path = log_dir_path + "/log_" + cur_date
            if not os.path.exists(final_log_path):
                os.makedirs(final_log_path, mode=0o777, exist_ok=True)
            logging.getLogger().setLevel(logging.NOTSET)
            console = logging.StreamHandler(sys.stdout)
            console.setLevel(logging.INFO)
            formater = logging.Formatter('%(message)s')
            console.setFormatter(formater)
            logging.getLogger().addHandler(console)

            # Add file rotating handler, with level DEBUG
            rotatingHandler = logging.handlers.RotatingFileHandler(filename=final_log_path + "/" + 'cloudwatch.log',
                                                                   maxBytes=100000, backupCount=5)
            rotatingHandler.setLevel(logging.INFO)
            formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
            rotatingHandler.setFormatter(formatter)
            logging.getLogger().addHandler(rotatingHandler)
            sys.tracebacklimit = 0

    def create_alarm(self, alarm_name: str, evaluation_period: int, comparison_operator: str, **kwargs):
        """
        Method to create alarm and attach to instance.
        :param alarm_name:  New alarm name.
        :param evaluation_period: number of periods over which data is compared to specified threshold.
        :param comparison_operator: arithmetic operation to use when comparing the specified statistic and threshold.
        :param kwargs: AlarmDescription/ActionsEnabled/OKActions/AlarmActions/InsufficientDataActions/MetricName/
        Namespace/Statistic/ExtendedStatistic/Dimensions/Period/Unit/DatapointsToAlarm/Threshold/TreatMissingData/
        EvaluateLowSampleCountPercentile/Metrics/ThresholdMetricId/Tags.
        :return: alarm_response
        """
        try:
            alarm_response = self.cloudwatch_client.put_metric_alarm(
                AlarmName=alarm_name, EvaluationPeriods=evaluation_period, ComparisonOperator=comparison_operator,
                **kwargs
            )
            return alarm_response
        except ClientError as err:
            print(Fore.RED)
            logging.info(f"Create Alarm failed with err: {err.response['Error']['Code']}")
            logging.error(err)
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def create_validate_alarm(
            self, alarm_name: str, evaluation_period: int, comparison_operator: str, instance_id: str, **kwargs):
        """
        Method to validate create_alarm response.
        :param alarm_name: New alarm name.
        :param evaluation_period: Number of periods over which data is compared to specified threshold.
        :param comparison_operator: Arithmetic operation to use when comparing the specified statistic and threshold.
        :param instance_id: Ec2 instance id.
        :param kwargs: AlarmDescription/ActionsEnabled/OKActions/AlarmActions/InsufficientDataActions/MetricName/
        Namespace/Statistic/ExtendedStatistic/Dimensions/Period/Unit/DatapointsToAlarm/Threshold/TreatMissingData/
        EvaluateLowSampleCountPercentile/Metrics/ThresholdMetricId/Tags.
        """
        create_alarm_response = self.create_alarm(alarm_name, evaluation_period, comparison_operator, **kwargs)
        assert create_alarm_response, f"Failed to Create alarm '{alarm_name}'."
        assert create_alarm_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected:'{RESPONSE_OK}'but found,"
            f"'{create_alarm_response['ResponseMetadata']['HTTPStatusCode']}'")
        alarm_list = [alarm['AlarmName'] for alarm in self.describe_alarm_validate()['MetricAlarms']]
        assert alarm_name in alarm_list, f"Failed to Create alarm '{alarm_name}'."
        logging.info(Fore.GREEN + f"Alarm: '{alarm_name} created and attached to instance: '{instance_id}' "
                                  f"successfully.'" + Style.RESET_ALL)
        return create_alarm_response

    def describe_alarm(self, **kwargs):
        """
        Method to get alarm list.
        :param kwargs:AlarmNames/AlarmNamePrefix/AlarmTypes/ChildrenOfAlarmName/ParentsOfAlarmName/StateValue/
                    ActionPrefix/MaxRecords/NextToken.
        return: describe_alarm_response
        """
        try:
            describe_alarm_response = self.cloudwatch_client.describe_alarms(**kwargs)
            return describe_alarm_response
        except ClientError as err:
            print(Fore.RED)
            logging.info(f"Describe Alarm failed with err: {err.response['Error']['Code']}")
            logging.error(err)
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def list_all_alarms(self):
        """
        Method to get all alarm information.
        return: describe_alarm_response
        """
        try:
            describe_alarm_response = self.cloudwatch_client.describe_alarms()
            if describe_alarm_response:
                logging.info(f"\nComposite Alarms -")
                if len(describe_alarm_response['CompositeAlarms']) > 1:
                    for alarm in describe_alarm_response['CompositeAlarms']:
                        logging.info(alarm)
                else:
                    logging.info("No composite alarm present")

                logging.info(f"\nMetrics Alarms -")
                if len(describe_alarm_response['MetricAlarms']) > 1:
                    for alarm in describe_alarm_response['MetricAlarms']:
                        logging.info(alarm)
                else:
                    logging.info("No Metric alarm present")
            return describe_alarm_response

        except ClientError as err:
            print(Fore.RED)
            logging.info(f"List all Alarm failed with err: {err.response['Error']['Code']}")
            logging.error(err)
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def describe_alarm_validate(self, cons_log=True, **kwargs):
        """
        Method to validate get alarm list.
        :param kwargs:AlarmNames/AlarmNamePrefix/AlarmTypes/ChildrenOfAlarmName/ParentsOfAlarmName/StateValue/
                        ActionPrefix/MaxRecords/NextToken.
        return: describe_alarm_response
        """
        describe_alarm_response = self.describe_alarm(**kwargs)
        assert describe_alarm_response, f"Error in getting alarm info. Output: {describe_alarm_response}"
        if cons_log:
            if describe_alarm_response['MetricAlarms']:
                logging.info(Fore.GREEN + f"Alarms information fetched successfully." + Style.RESET_ALL)
                logging.info(describe_alarm_response)
            else:
                logging.info(Fore.RED + f"No alarm present" + Style.RESET_ALL)
        return describe_alarm_response

    def create_validate_dashboard(self, dashboard_name: str, dashboard_body: str):
        """
        Validation method to validate create dashboard response
        :param dashboard_name: Name of the dashboard
        :param dashboard_body: Dashboard body
        """
        create_dashboard = self.create_dashboard(dashboard_name, dashboard_body)
        assert create_dashboard, f"Failed to get the response of the create dashboard. Output: {create_dashboard}"
        assert create_dashboard['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected:'{RESPONSE_OK}'but found,"
            f"'{create_dashboard['ResponseMetadata']['HTTPStatusCode']}'")
        # Check after creating dashboard, Dashboard is present on the AWS
        dashboard_present = self.validate_dashboard_present(dashboard_name, cons_log=False)
        assert dashboard_present, f"Dashboard '{dashboard_name}' present on the AWS"
        logging.info(Fore.GREEN + f"Successfully created dashboard '{dashboard_name}'" + Style.RESET_ALL)
        return create_dashboard

    def create_dashboard(self, dashboard_name: str, dashboard_body: str):
        """
        Library method to create the cloudwatch dashboard.
        :param dashboard_name: Name of the dashboard
        :param dashboard_body: Dashboard body
        :return: Response of the create dashboard
        """
        try:
            create_dashboard = self.cloudwatch_client.put_dashboard(
                DashboardName=dashboard_name, DashboardBody=dashboard_body
            )
            return create_dashboard
        except ClientError as err:
            print(Fore.RED)
            if err.response['Error']['Code'] == "DashboardInvalidInputError":
                logging.error(f"Create dashboard failed with the error '{err.response['Error']['Code']}'")
            elif err.response['Error']['Code'] == "InternalServiceFault":
                logging.error(f"Create dashboard failed with the error '{err.response['Error']['Code']}'")
            else:
                logging.error(err)
            logging.error(
                f"Create dashboard '{dashboard_name}' failed listing with err: {err.response['Error']['Code']}"
            )
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def validate_dashboard_present(self, name, cons_log=True, **kwargs):
        """
        Validation method to list the dashboard
        :param name: Name of the dashboard
        :param kwargs: DashboardNamePrefix, NextToken
        :return: Message with dashboard id
        """
        dashboards_list = self.list_dashboards(**kwargs)
        assert dashboards_list
        length = len(dashboards_list['DashboardEntries'])
        dashboards_name_list = [dashboards_list['DashboardEntries'][index]['DashboardName'] for index in range(length)]
        if name in dashboards_name_list:
            if self.command_line and cons_log:
                logging.info(Fore.GREEN + f"Dashboard - {name} is present" + Style.RESET_ALL)
                return f"Dashboard - {name} is present"
            else:
                return True
        else:
            if self.command_line and cons_log:
                logging.info(Fore.RED + f"Dashboard - {name} is absent" + Style.RESET_ALL)
                return f"Dashboard - {name} is not present"
            else:
                return False

    def list_dashboards(self, cons_log=False, **kwargs):
        """
        Library method to list the dashboards
        :param cons_log: print logs to console
        :param kwargs: DashboardNamePrefix, NextToken
        :return: List of dashboards
        """
        try:
            dashboards_list = self.cloudwatch_client.list_dashboards(**kwargs)
            if cons_log:
                for dashboard in dashboards_list['DashboardEntries']:
                    logging.info(dashboard['DashboardName'])
            return dashboards_list
        except ClientError as err:
            print(Fore.RED)
            if err.response['Error']['Code'] == "InvalidParameterValueException":
                logging.error(f"List dashboards failed with the error '{err.response['Error']['Code']}'")
            elif err.response['Error']['Code'] == "InternalServiceFault":
                logging.error(f"List dashboard failed with the error '{err.response['Error']['Code']}'")
            else:
                logging.error(err)
            logging.error(
                f"List dashboard failed listing with err: {err.response['Error']['Code']}"
            )
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def validate_delete_dashboard(self, dashboard_names: list):
        """
        Validation method to delete dashboard
        :param dashboard_names: Name of the dashboard
        """
        delete_dashboard = self.delete_dashboard(dashboard_names)
        assert delete_dashboard, f"Failed to get the response of the delete dashboard. Output: {delete_dashboard}"
        assert delete_dashboard['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected:'{RESPONSE_OK}'but found "
            f"'{delete_dashboard['ResponseMetadata']['HTTPStatusCode']}'"
        )
        # Check after deleting dashboard, dashboard is not present on AWS
        for index in range(len(delete_dashboard)):
            dashboard_present = self.validate_dashboard_present(dashboard_names[index], cons_log=False)
            assert dashboard_present is False
            logging.info(Fore.GREEN + f"Successfully deleted dashboard '{dashboard_names[index]}'" + Style.RESET_ALL)
        return delete_dashboard

    def delete_dashboard(self, dashboard_name: list):
        """
        Library method to delete the cloudwatch dashboard
        :param dashboard_name: Name of the dashboard
        :return: Returns the response of the delete dashboard
        """
        try:
            delete_dashboard = self.cloudwatch_client.delete_dashboards(DashboardNames=dashboard_name)
            return delete_dashboard
        except ClientError as err:
            print(Fore.RED)
            if err.response['Error']['Code'] == "InvalidParameterValueException":
                logging.error(f"Delete dashboard failed with the error '{err.response['Error']['Code']}'")
            elif err.response['Error']['Code'] == "DashboardNotFoundError":
                logging.error(f"Dashboard '{dashboard_name[0]}' is not found on AWS")
            elif err.response['Error']['Code'] == "InternalServiceFault":
                logging.error(f"Delete dashboard failed with the error '{err.response['Error']['Code']}'")
            else:
                logging.error(err)
            logging.error(
                f"Delete dashboard '{dashboard_name}' failed listing with err: {err.response['Error']['Code']}"
            )
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def delete_alarm(self, alarm_names: list):
        """
        Method to delete alarms.
        :param alarm_names: Alarm name.
        :return: delete_alarm_response.
        """
        alarm_list = [alarm['AlarmName'] for alarm in self.describe_alarm()['MetricAlarms']]
        if all(alarm in alarm_list for alarm in alarm_names):
            try:
                delete_alarm_response = self.cloudwatch_client.delete_alarms(AlarmNames=alarm_names)
                return delete_alarm_response
            except ClientError as err:
                print(Fore.RED)
                logging.info(f"Delete alarm failed with err: {err.response['Error']['Code']}")
                logging.error(err)
                print(Style.RESET_ALL)
                if self.command_line:
                    exit()
        else:
            raise Exception("No such Entity found.")

    def delete_alarm_validate(self, alarm_name: list):
        """
        Method to validate delete_alarm
        :param alarm_name: Alarm name.
        """
        delete_alarm_response = self.delete_alarm(alarm_name)
        assert delete_alarm_response, f"Failed to delete alarm '{alarm_name}'"
        assert delete_alarm_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected:'{RESPONSE_OK}' but found."
            f"'{delete_alarm_response['ResponseMetadata']['HTTPStatusCode']}'")
        alarm_list = [alarm['AlarmName'] for alarm in self.describe_alarm_validate(cons_log=False)['MetricAlarms']]
        for alarm_name in alarm_name:
            assert alarm_name not in alarm_list, f"Failed to delete alarm '{alarm_name}'."
        logging.info(Fore.GREEN + f"Alarm: '{alarm_name} deleted successfully.'" + Style.RESET_ALL)
        return delete_alarm_response


def main():
    parser = argparse.ArgumentParser()
    cloudwatch_method_subparser = parser.add_subparsers(dest='cloudwatch_method')

    # Create Alarm Commands
    create_alarm_parser = cloudwatch_method_subparser.add_parser("create-alarm",
                                                                 help="Creates an alarm and associates it "
                                                                      "with the specified metric, metric math "
                                                                      "expression, or anomaly detection model.")
    create_alarm_parser.add_argument("--alarm_name", type=str,
                                     help="The name for the alarm. This name must be unique within the Region" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                     required=True)
    create_alarm_parser.add_argument("--evaluation_period", type=int,
                                     help="number of periods over which data is compared to specified threshold" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                     default=argparse.SUPPRESS)
    create_alarm_parser.add_argument("--comparison_operator", type=str,
                                     help="arithmetic operation to use when comparing the specified statistic and "
                                          "threshold." + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                     default=argparse.SUPPRESS)
    create_alarm_parser.add_argument("--instance_id", type=str,
                                     help="Instance ID" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                     default=argparse.SUPPRESS)
    create_alarm_parser.add_argument("--MetricName", "--metric_name", type=str,
                                     help="The name for the metric associated with the alarm" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                     default=argparse.SUPPRESS)
    create_alarm_parser.add_argument("--Namespace", "--namespace", type=str,
                                     help="The namespace for the metric associated specified in MetricName" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                     default=argparse.SUPPRESS)
    create_alarm_parser.add_argument("--Statistic", "--statistic", type=str,
                                     help="The statistic for the metric specified in MetricName" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                     default=argparse.SUPPRESS)
    create_alarm_parser.add_argument("--Period", "--period", type=int,
                                     help="The granularity, in seconds, of the returned data points" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                     default=argparse.SUPPRESS)

    create_alarm_parser.add_argument("--AlarmDescription", "--description", type=str,
                                     help="The description for the alarm.", default=argparse.SUPPRESS)
    create_alarm_parser.add_argument("--ActionsEnabled", "--actions_enabled", type=bool,
                                     help="Indicates whether actions should be executed during any changes to the "
                                          "alarm state. The default is TRUE .", default=argparse.SUPPRESS)
    create_alarm_parser.add_argument("--OKActions", "--ok_actions", type=list,
                                     help="The actions to execute when this alarm transitions to an OK state from any"
                                          " other state", default=argparse.SUPPRESS)
    create_alarm_parser.add_argument("--AlarmActions", "--alarm_actions", type=list,
                                     help="The actions to execute when this alarm transitions to the ALARM state "
                                          "from any other state", default=argparse.SUPPRESS)
    create_alarm_parser.add_argument("--InsufficientDataActions", "--insufficient_data_actions", type=list,
                                     help="The actions to execute when this alarm transitions to the INSUFFICIENT_DATA "
                                          "state from any other state", default=argparse.SUPPRESS)
    create_alarm_parser.add_argument("--ExtendedStatistic", "--extended_statistic", type=str,
                                     help="The statistic for the metric specified in MetricName",
                                     default=argparse.SUPPRESS)
    create_alarm_parser.add_argument("--Dimensions", "--dimensions", type=list,
                                     help="A dimension is a name/value pair that is part of the identity of a metric. "
                                          "You can assign up to 10 dimensions to a metric",
                                     default=argparse.SUPPRESS)
    create_alarm_parser.add_argument("--Unit", "--unit", type=str,
                                     help="The unit of measure for the statistic", default=argparse.SUPPRESS)
    create_alarm_parser.add_argument("--DatapointsToAlarm", "--data_points_to_alarm", type=int,
                                     help="The number of data points that must be breaching to trigger the alarm",
                                     default=argparse.SUPPRESS)
    create_alarm_parser.add_argument("--Threshold", "--threshold", type=float,
                                     help="The value against which the specified statistic is compared",
                                     default=argparse.SUPPRESS)
    create_alarm_parser.add_argument("--TreatMissingData", "--treat_missing_data", type=str,
                                     help="Sets how this alarm is to handle missing data points",
                                     default=argparse.SUPPRESS)
    create_alarm_parser.add_argument("--EvaluateLowSampleCountPercentile", "--evaluate_lowsample_count_percentile",
                                     type=str, help="Used only for alarms based on percentiles",
                                     default=argparse.SUPPRESS)
    create_alarm_parser.add_argument("--Metrics", "--metrics",
                                     type=list, help="An array of MetricDataQuery structures",
                                     default=argparse.SUPPRESS)
    create_alarm_parser.add_argument("--ThresholdMetricId", "--threshold_metric_id", type=int,
                                     help="In an alarm based on an anomaly detection model, this is the ID of the "
                                          "ANOMALY_DETECTION_BAND function used as the threshold for the alarm",
                                     default=argparse.SUPPRESS)
    create_alarm_parser.add_argument("--Tags", "--tags", type=list,
                                     help="A list of key-value pairs to associate with the alarm. You can associate "
                                          "as many as 50 tags with an alarm", default=argparse.SUPPRESS)
    create_alarm_parser.add_argument(
        "--email", type=str,
        help="Specify email ID to send email notification (Multiple comma-separated email IDs are acceptable)",
        default=argparse.SUPPRESS)

    # List all Alarm Commands
    list_alarm_parser = cloudwatch_method_subparser.add_parser("list-all-alarms",
                                                               help="Retrieves all configured alarms")
    list_alarm_parser.add_argument(
        "--email", type=str,
        help="Specify email ID to send email notification (Multiple comma-separated email IDs are acceptable)",
        default=argparse.SUPPRESS)

    # Describe Alarm Commands
    desc_alarm_parser = cloudwatch_method_subparser.add_parser("describe-alarm", help="Get alarm Information")
    desc_alarm_parser.add_argument("--AlarmNames", "--alarm_names", type=str, nargs='*',
                                   help="The names of the alarms to retrieve information "
                                        "about", default=argparse.SUPPRESS)
    desc_alarm_parser.add_argument("--AlarmNamePrefix", "--alarm_name_prefix", type=str, help="An alarm name prefix",
                                   default=argparse.SUPPRESS)
    desc_alarm_parser.add_argument("--AlarmTypes", "--alarm_types", type=list, help="Use this parameter to specify "
                                                                                    "whether you want the operation to return metric alarms or composite alarms. "
                                                                                    "If you omit this parameter, only metric alarms are returned",
                                   default=argparse.SUPPRESS)
    desc_alarm_parser.add_argument("--ChildrenOfAlarmName", "--children_of_alarm_name", type=str,
                                   help="If you use this parameter and specify the name of a composite alarm, "
                                        "the operation returns information about the children alarms of the alarm "
                                        "you specify",
                                   default=argparse.SUPPRESS)
    desc_alarm_parser.add_argument("--ParentsOfAlarmName", "--parents_of_alarm_name", type=str,
                                   help="If you use this parameter and specify the name of a metric or composite alarm,"
                                        " the operation returns information about the parent alarms of the alarm "
                                        "you specify",
                                   default=argparse.SUPPRESS)
    desc_alarm_parser.add_argument("--StateValue", "--state_value", type=str, help="Specify this parameter to receive "
                                                                                   "information only about alarms that are currently in the state that you specify",
                                   default=argparse.SUPPRESS)
    desc_alarm_parser.add_argument("--ActionPrefix", "--action_prefix", type=str, help="Use this parameter to filter "
                                                                                       "the results of the operation to only those alarms that use a certain alarm action",
                                   default=argparse.SUPPRESS)
    desc_alarm_parser.add_argument("--MaxRecords", "--max_records", type=int, help="he maximum number of alarm "
                                                                                   "descriptions to retrieve",
                                   default=argparse.SUPPRESS)
    desc_alarm_parser.add_argument("--NextToken", "--next_token", type=str,
                                   help="The token returned by a previous call "
                                        "to indicate that there is more data "
                                        "available",
                                   default=argparse.SUPPRESS)
    desc_alarm_parser.add_argument(
        "--email", type=str,
        help="Specify email ID to send email notification (Multiple comma-separated email IDs are acceptable)",
        default=argparse.SUPPRESS)

    # Create Dashboard Commands
    create_dashboard_parser = cloudwatch_method_subparser.add_parser("create-dashboard",
                                                                     help="Create the cloudwatch dashboard")
    create_dashboard_parser.add_argument("--dashboard_name", type=str,
                                         help="Name of the dashboard" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                         required=True)
    create_dashboard_parser.add_argument("--dashboard_body", type=argparse.FileType("r"),
                                         help="Dashboard body [path to json file]" + Fore.RED + " [REQUIRED]"
                                              + Style.RESET_ALL,
                                         default=argparse.SUPPRESS)
    create_dashboard_parser.add_argument(
        "--email", type=str,
        help="Specify email ID to send email notification (Multiple comma-separated email IDs are acceptable)",
        default=argparse.SUPPRESS)

    # List Dashboard Commands
    list_dashboard_parser = cloudwatch_method_subparser.add_parser("list-dashboard", help="list the dashboards")
    list_dashboard_parser.add_argument("--DashboardNamePrefix", "--dashboard_name_prefix", type=str,
                                       help="f you specify this parameter, only the dashboards with names starting "
                                            "with the specified string are listed", default=argparse.SUPPRESS)
    list_dashboard_parser.add_argument("--NextToken", "--next_token", type=str,
                                       help="The token returned by a previous call to "
                                            "indicate that there is more data available",
                                       default=argparse.SUPPRESS)
    list_dashboard_parser.add_argument(
        "--email", type=str,
        help="Specify email ID to send email notification (Multiple comma-separated email IDs are acceptable)",
        default=argparse.SUPPRESS)

    # Validate Dashboard Commands
    val_dashboard_parser = cloudwatch_method_subparser.add_parser("check-dashboard",
                                                                  help="Validate if dashboard is present or not")
    val_dashboard_parser.add_argument("--name", type=str, help="Name of the dashboard" + Fore.RED + " [REQUIRED]"
                                                               + Style.RESET_ALL, required=True)
    val_dashboard_parser.add_argument("--DashboardNamePrefix", "--dashboard_name_prefix", type=str,
                                      help="f you specify this parameter, only the dashboards with names starting "
                                           "with the specified string are listed", default=argparse.SUPPRESS)
    val_dashboard_parser.add_argument("--NextToken", "--next_token", type=str,
                                      help="The token returned by a previous call to "
                                           "indicate that there is more data available",
                                      default=argparse.SUPPRESS)
    val_dashboard_parser.add_argument(
        "--email", type=str,
        help="Specify email ID to send email notification (Multiple comma-separated email IDs are acceptable)",
        default=argparse.SUPPRESS)

    # Delete dashboard Commands
    del_dashboard_parser = cloudwatch_method_subparser.add_parser("delete-dashboard",
                                                                  help="Deletes the cloudwatch dashboard")
    del_dashboard_parser.add_argument("--dashboard_names", type=str, nargs='*',
                                      help="Name of the dashboards" + Fore.RED + " [REQUIRED]"
                                           + Style.RESET_ALL, required=True)
    del_dashboard_parser.add_argument(
        "--email", type=str,
        help="Specify email ID to send email notification (Multiple comma-separated email IDs are acceptable)",
        default=argparse.SUPPRESS)

    # Delete alarm Commands
    del_alarm_parser = cloudwatch_method_subparser.add_parser("delete-alarm", help="Deletes configured alarms")
    del_alarm_parser.add_argument("--alarm_name", type=str, nargs='*',
                                  help="Name of the alarms" + Fore.RED + " [REQUIRED]"
                                       + Style.RESET_ALL, required=True)
    del_alarm_parser.add_argument(
        "--email", type=str,
        help="Specify email ID to send email notification (Multiple comma-separated email IDs are acceptable)",
        default=argparse.SUPPRESS)

    args = parser.parse_args()
    if not args.cloudwatch_method:
        parser.print_help()
        return
    parse_args_to_execute(args)


@send_email("Cloudwatch", "cloudwatch_method")
def parse_args_to_execute(args, config_data=None):
    if args.cloudwatch_method and config_data:
        cw_obj = CloudWatch(config_data, command_line=True)
        args_dict = vars(args)
        if args.cloudwatch_method == "create-alarm":
            del args_dict['cloudwatch_method']
            return cw_obj.create_validate_alarm(**args_dict)
        elif args.cloudwatch_method == "list-all-alarms":
            del args_dict['cloudwatch_method']
            return cw_obj.list_all_alarms()
        elif args.cloudwatch_method == "describe-alarm":
            del args_dict['cloudwatch_method']
            return cw_obj.describe_alarm_validate(**args_dict)
        elif args.cloudwatch_method == "create-dashboard":
            del args_dict['cloudwatch_method']
            dashboard_body = json.load(args_dict['dashboard_body'])
            return cw_obj.create_validate_dashboard(args_dict['dashboard_name'], json.dumps(dashboard_body))
        elif args.cloudwatch_method == "check-dashboard":
            del args_dict['cloudwatch_method']
            return cw_obj.validate_dashboard_present(**args_dict)
        elif args.cloudwatch_method == "list-dashboard":
            del args_dict['cloudwatch_method']
            return cw_obj.list_dashboards(cons_log=True, **args_dict)
        elif args.cloudwatch_method == "delete-dashboard":
            del args_dict['cloudwatch_method']
            return cw_obj.validate_delete_dashboard(**args_dict)
        elif args.cloudwatch_method == "delete-alarm":
            del args_dict['cloudwatch_method']
            return cw_obj.delete_alarm_validate(**args_dict)


if __name__ == '__main__':
    main()
