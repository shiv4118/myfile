#!/usr/bin/env python3
import argparse
import json
import logging
import sys
import time
import os
import datetime
import logging.handlers

import boto3
from botocore.exceptions import ClientError
from colorama import Fore, Style

from email_notifications import send_email
from constants import *


class DynamoDB:

    def __init__(self, config, command_line=False):
        self.client = boto3.client(
            "dynamodb", **config
        )
        self.resource = boto3.resource(
            "dynamodb", **config
        )
        self.config = config
        self.command_line = command_line
        if command_line:
            home_dir = os.path.expanduser("~")
            # logging.basicConfig(level=logging.INFO, format='%(message)s')
            # sys.tracebacklimit = 0
            cur_date = datetime.datetime.now().strftime("%d_%b_%Y")
            log_dir_path = os.path.join(home_dir, ".a4cloudstack_logs")
            final_log_path = log_dir_path + "/log_" + cur_date
            if not os.path.exists(final_log_path):
                os.makedirs(final_log_path, mode=0o777, exist_ok=True)
            logging.getLogger().setLevel(logging.NOTSET)
            console = logging.StreamHandler(sys.stdout)
            console.setLevel(logging.INFO)
            formater = logging.Formatter('%(message)s')
            console.setFormatter(formater)
            logging.getLogger().addHandler(console)

            # Add file rotating handler, with level DEBUG
            rotatingHandler = logging.handlers.RotatingFileHandler(filename=final_log_path + "/" + 'dynamodb.log',
                                                                   maxBytes=100000, backupCount=5)
            rotatingHandler.setLevel(logging.INFO)
            formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
            rotatingHandler.setFormatter(formatter)
            logging.getLogger().addHandler(rotatingHandler)
            sys.tracebacklimit = 0

    def validate_get_item(self, table_name: str, key: dict):
        """
        Validation method to get item from dynamoDB table.
        :param table_name: Name of the table
        :param key: Item from the table
        :return: get item response
        """
        get_item = self.get_item(table_name, key)
        assert get_item, f"Failed to get item from the table '{table_name}'. Output: '{get_item}'"
        assert get_item['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Failed to verify response code. Expected: '{RESPONSE_OK}' but found "
            f"'{get_item['ResponseMetadata']['HTTPStatusCode']}'"
        )
        info_msg1 = f"Item '{key}' is not present in the table '{table_name}'"
        info_msg2 = f"Successfully retrieved item '{key}' from the table '{table_name}'"
        logging.info(Fore.RED + info_msg1 + Style.RESET_ALL) if "Item" not in get_item.keys() else \
            logging.info(str(get_item['Item']) + "\n" + Fore.GREEN + info_msg2 + Style.RESET_ALL)
        return get_item

    def get_item(self, table_name: str, key: dict):
        """
        Library method to get item from dynamoDB table.
        :param table_name: Name of the table
        :param key: Item from the table
        :return: get item response
        """
        try:
            table = self.resource.Table(table_name)
            response = table.get_item(Key=key)
            return response
        except ClientError as err:
            print(Fore.RED)
            if err.response['Error']['Code'] == "ProvisionedThroughputExceededException":
                logging.error(
                    f"Failed to get item '{key}' from the table '{table_name}' with err "
                    f"'{err.response['Error']['Code']}'"
                )
            elif err.response['Error']['Code'] == "ResourceNotFoundException":
                logging.error(
                    f"Failed to get item '{key}' from the table '{table_name}' with err "
                    f"'{err.response['Error']['Code']}'"
                )
            elif err.response['Error']['Code'] == "RequestLimitExceeded":
                logging.error(
                    f"Failed to get item '{key}' from the table '{table_name}' with err "
                    f"'{err.response['Error']['Code']}'"
                )
            elif err.response['Error']['Code'] == "InternalServerError":
                logging.error(
                    f"Failed to get item '{key}' from the table '{table_name}' with err "
                    f"'{err.response['Error']['Code']}'"
                )
            else:
                logging.error(err)
                logging.error(f"Failed to get item '{key}' from the table '{table_name}'")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def validate_create_dynamodb_table(
            self, table_name: str, attributes: dict, key_schema: list, **kwargs
    ):
        """
        Validation method to validate the response of the create a table
        :param table_name: Name of the table
        :param attributes: Name of the attributes
        :param key_schema: Key schema of the attributes
        :param kwargs: LocalSecondaryIndexes/GlobalSecondaryIndexes/BillingMode/ProvisionedThroughput/
        StreamSpecification/SSESpecification/Tags
        """
        table_create_status = "CREATING"
        table_active_status = 'ACTIVE'
        create_table = self.create_dynamodb_table(table_name, attributes, key_schema, **kwargs)
        assert create_table, f"Failed to get the response of the create table. Output: {create_table}"
        assert create_table['TableDescription']['TableStatus'] == table_create_status, (
            f"Failed to create the table '{table_name}'. Expected status is '{table_create_status}' but found "
            f"'{create_table['TableDescription']['TableStatus']}'"
        )
        assert create_table['TableDescription']['TableName'] == table_name, (
            f"Failed to create the table '{table_name}'. Expected table is '{table_name}' but found "
            f"'{create_table['TableDescription']['TableName']}'"
        )
        assert create_table['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Failed to verify response code. Expected: '{RESPONSE_OK}' but found "
            f"'{create_table['ResponseMetadata']['HTTPStatusCode']}'"
        )
        logging.info(Fore.GREEN + f"Dynamodb table '{table_name}' created successfully." + Style.RESET_ALL)
        for _ in range(12):
            describe_table = self.validate_describe_dynamodb_table(table_name, console_log=False)
            if describe_table['Table']['TableStatus'] == table_active_status:
                logging.info(
                    Fore.GREEN + f"Table '{table_name}' is in '{table_active_status}' state." + Style.RESET_ALL)
                break
            logging.info(
                Fore.YELLOW + f"Currently table '{table_name}' status is not '{table_active_status}'" + Style.RESET_ALL)
            time.sleep(5)
        else:
            raise Exception(
                Fore.RED + f"Failed, Table '{table_name}' state is not achieved to '{table_active_status}' "
                           f"state even after 60 s" + Style.RESET_ALL
            )
        return create_table

    def create_dynamodb_table(self, table_name: str, attributes: dict, key_schema: list, **kwargs):
        """
        Library method to create a table
        :param table_name: Name of the table
        :param attributes: Name of the attributes
        :param key_schema: Key schema of the attributes
        :param kwargs: LocalSecondaryIndexes/GlobalSecondaryIndexes/BillingMode/ProvisionedThroughput/
        StreamSpecification/SSES/pecification/Tags
        :return: response of the create table
        """
        try:
            create_table = self.client.create_table(
                TableName=table_name, AttributeDefinitions=attributes, KeySchema=key_schema, **kwargs
            )
            return create_table
        except ClientError as err:
            print(Fore.RED)
            if err.response['Error']['Code'] == "ResourceInUseException":
                logging.error(
                    f"Failed to create the table '{table_name}' with err '{err.response['Error']['Code']}'"
                )
            elif err.response['Error']['Code'] == "LimitExceededException":
                logging.error(
                    f"Failed to create the table '{table_name}' with err '{err.response['Error']['Code']}'"
                )
            elif err.response['Error']['Code'] == "InternalServerError":
                logging.error(
                    f"Failed to create the table '{table_name}' with err '{err.response['Error']['Code']}'"
                )
            else:
                logging.error(err)
                logging.error(logging.error(f"Failed to create the table '{table_name}' with err '{err}'"))
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def validate_describe_dynamodb_table(self, table_name: str, console_log: bool = True):
        """
        Validation method to describe the table
        :param table_name: Name of the table
        :param console_log: Show or restrict logs to console
        :return: Response of the dynamodb table
        """
        describe_table = self.describe_dynamodb_table(table_name)
        assert describe_table, f"Failed to get response of the describe_table. Output: {describe_table}"
        assert describe_table['Table']['TableName'] == table_name
        assert describe_table['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Failed to verify response code. Expected: '{RESPONSE_OK}' but found "
            f"'{describe_table['ResponseMetadata']['HTTPStatusCode']}'"
        )
        if describe_table and self.command_line and console_log:
            for key, val in describe_table['Table'].items():
                if key == "AttributeDefinitions" or key == "KeySchema":
                    for k, v in val[0].items():
                        logging.info(str(k) + " -> " + str(v))
                elif key == "ProvisionedThroughput":
                    for k, v in val.items():
                        logging.info(str(k) + " -> " + str(v))
                else:
                    logging.info(str(key) + " -> " + str(val))
        if console_log:
            logging.info(Fore.GREEN + f"Dynamodb table '{table_name}' described successfully" + Style.RESET_ALL)
        return describe_table

    def describe_dynamodb_table(self, table_name: str):
        """
        Library method to describe the dynamodb table
        :param table_name: Table name
        :return: Response of the dynamodb table
        """
        try:
            create_table = self.client.describe_table(TableName=table_name)
            return create_table
        except ClientError as err:
            print(Fore.RED)
            if err.response['Error']['Code'] == "ResourceNotFoundException":
                logging.error(
                    f"Failed to describe the table '{table_name}' with err '{err.response['Error']['Code']}'"
                )
            elif err.response['Error']['Code'] == "InternalServerError":
                logging.error(
                    f"Failed to describe the table '{table_name}' with err '{err.response['Error']['Code']}'"
                )
            else:
                logging.error(err)
                logging.error(f"Failed to describe a table '{table_name}'")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def validate_delete_dynamodb_table(self, table_name: str):
        """
        Validation method to delete the dynamodb table
        :param table_name: Name of the table
        """
        delete_table = self.delete_dynamodb_table(table_name)
        assert delete_table, f"Failed to delete the table. Output: {delete_table}"
        assert delete_table['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Failed to verify response code. Expected: '{RESPONSE_OK}' but found "
            f"'{delete_table['ResponseMetadata']['HTTPStatusCode']}'"
        )
        for _ in range(12):
            dynamodb_tables = self.validate_list_dynamodb_tables(console_log=False)
            if table_name not in dynamodb_tables['TableNames']:
                logging.info(Fore.GREEN + f"Dynamodb table '{table_name}' deleted successfully" + Style.RESET_ALL)
                break
            logging.info(Fore.YELLOW + f"Table '{table_name}' is not deleted yet" + Style.RESET_ALL)
            time.sleep(5)
        else:
            raise Exception(Fore.RED + f"Failed to delete the table '{table_name}' in 60s" + Style.RESET_ALL)
        return delete_table

    def delete_dynamodb_table(self, table_name: str):
        """
        Library method to delete the dynamodb table
        :param table_name: Name of the table
        :return: response of the delete dynamodb table
        """
        try:
            create_table = self.client.delete_table(TableName=table_name)
            return create_table
        except ClientError as err:
            print(Fore.RED)
            if err.response['Error']['Code'] == "ResourceInUseException":
                logging.error(
                    f"Failed to delete the table '{table_name}' with err '{err.response['Error']['Code']}'"
                )
            elif err.response['Error']['Code'] == "ResourceNotFoundException":
                logging.error(
                    f"Failed to delete the table '{table_name}' with err '{err.response['Error']['Code']}'"
                )
            elif err.response['Error']['Code'] == "LimitExceededException":
                logging.error(
                    f"Failed to delete the table '{table_name}' with err '{err.response['Error']['Code']}'"
                )
            elif err.response['Error']['Code'] == "InternalServerError":
                logging.error(
                    f"Failed to delete the table '{table_name}' with err '{err.response['Error']['Code']}'"
                )
            else:
                logging.error(err)
                logging.error(f"Failed to delete a table '{table_name}' with err '{err}'")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def validate_list_dynamodb_tables(self, console_log: bool = True, **kwargs):
        """
        Validation method to check the response of the dynamodb tables
        :param console_log: Show or restrict logs to console
        :param kwargs: ExclusiveStartTableName/Limit
        :return: list of all dynamodb tables
        """
        tables_list = self.list_dynamodb_tables(**kwargs)
        assert tables_list['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Failed to verify response code. Expected: '{RESPONSE_OK}' but found "
            f"'{tables_list['ResponseMetadata']['HTTPStatusCode']}'"
        )
        if self.command_line and console_log:
            print("List of all available tables -> ")
            for table in tables_list['TableNames']:
                print(table)
        return tables_list

    def list_dynamodb_tables(self, **kwargs):
        """
        Library method to list all the dynamodb tables.
        :param kwargs: ExclusiveStartTableName/Limit
        :return: list of all dynamodb tables
        """
        try:
            tables_list = self.client.list_tables(**kwargs)
            return tables_list
        except ClientError as err:
            print(Fore.RED)
            if err.response['Error']['Code'] == "InternalServerError":
                logging.error(
                    f"Failed to list the tables with err '{err.response['Error']['Code']}'"
                )
            else:
                logging.error(err)
                logging.error(f"Failed to list the tables with err '{err}'")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def validate_put_item(self, table_name: str, item: dict, **kwargs):
        """
        Validation method to put the item in the table
        :param table_name: Name of the table
        :param item: Item which need to be put in the table
        :param kwargs: Expected/ReturnValues/ReturnConsumedCapacity/ReturnItemCollectionMetrics/ConditionalOperator/
        ConditionExpression/ExpressionAttributeNames/ExpressionAttributeValues
        """
        put_item = self.put_item_in_table(table_name, item, **kwargs)
        assert put_item, f"Failed to put the item {item} in the table '{table_name}'"
        assert put_item['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Failed to verify response code. Expected: '{RESPONSE_OK}' but found "
            f"'{put_item['ResponseMetadata']['HTTPStatusCode']}'"
        )
        logging.info(Fore.GREEN + f"Successfully put the item {item} in the table '{table_name}'" + Style.RESET_ALL)
        return f"Successfully put the item {item} in the table '{table_name}'"

    def put_item_in_table(self, table_name: str, item: dict, **kwargs):
        """
        Library method to put item in the table
        :param table_name: Name of the table
        :param item: Item which need to be put in the table
        :param kwargs: Expected/ReturnValues/ReturnConsumedCapacity/ReturnItemCollectionMetrics/ConditionalOperator/
        ConditionExpression/ExpressionAttributeNames/ExpressionAttributeValues
        :return: Response of the put item
        """
        try:
            put_item = self.client.put_item(TableName=table_name, Item=item, **kwargs)
            return put_item
        except ClientError as err:
            print(Fore.RED)
            if err.response['Error']['Code'] == "ConditionalCheckFailedException":
                logging.error(
                    f"Failed to put item {item} in the table {table_name} with error {err.response['Error']['Code']}"
                )
            elif err.response['Error']['Code'] == "ProvisionedThroughputExceededException":
                logging.error(
                    f"Failed to put item {item} in the table {table_name} with error {err.response['Error']['Code']}"
                )
            elif err.response['Error']['Code'] == "ResourceNotFoundException":
                logging.error(
                    f"Failed to put item {item} in the table {table_name} with error {err.response['Error']['Code']}"
                )
            elif err.response['Error']['Code'] == "ItemCollectionSizeLimitExceededException":
                logging.error(
                    f"Failed to put item {item} in the table {table_name} with error {err.response['Error']['Code']}"
                )
            elif err.response['Error']['Code'] == "TransactionConflictException":
                logging.error(
                    f"Failed to put item {item} in the table {table_name} with error {err.response['Error']['Code']}"
                )
            elif err.response['Error']['Code'] == "RequestLimitExceeded":
                logging.error(
                    f"Failed to put item {item} in the table {table_name} with error {err.response['Error']['Code']}"
                )
            elif err.response['Error']['Code'] == "InternalServerError":
                logging.error(
                    f"Failed to put item {item} in the table {table_name} with error {err.response['Error']['Code']}"
                )
            else:
                logging.error(f"Failed to put item '{item}' in the table '{table_name}' with error '{err}'")
            logging.error(err)
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def validate_delete_item_from_dynamodb_table(self, table_name: str, item: dict, **kwargs):
        """
        Validation method to delete the item from the table
        :param table_name: Name of the table
        :param item: Item which need to be deleted from the table
        :param kwargs: Expected/ReturnValues/ReturnConsumedCapacity/ReturnItemCollectionMetrics/ConditionalOperator/
        ConditionExpression/ExpressionAttributeNames/ExpressionAttributeValues
        """
        delete_item = self.delete_item_from_dynamodb_table(table_name, item, **kwargs)
        assert delete_item, f"Failed to get the response of the delete item. Output: {delete_item}"
        assert delete_item['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Failed to verify response code. Expected: '{RESPONSE_OK}' but found "
            f"'{delete_item['ResponseMetadata']['HTTPStatusCode']}'"
        )
        logging.info(Fore.GREEN + f"Successfully deleted item {item} from the table '{table_name}'" + Style.RESET_ALL)
        return f"Successfully deleted item {item} from the table '{table_name}'"

    def delete_item_from_dynamodb_table(self, table_name: str, item: dict, **kwargs):
        """
        Library method to validate the dynamodb table
        :param table_name: Name of the table
        :param item: Item which need to be put in the table
        :param kwargs: Expected/ReturnValues/ReturnConsumedCapacity/ReturnItemCollectionMetrics/ConditionalOperator/
        ConditionExpression/ExpressionAttributeNames/ExpressionAttributeValues
        :return: Response of the delete item
        """
        try:
            delete_item = self.client.delete_item(TableName=table_name, Key=item, **kwargs)
            return delete_item
        except ClientError as err:
            print(Fore.RED)
            if err.response['Error']['Code'] == "ConditionalCheckFailedException":
                logging.error(
                    f"Failed to delete item {item} in the table {table_name} with error {err.response['Error']['Code']}"
                )
            elif err.response['Error']['Code'] == "ProvisionedThroughputExceededException":
                logging.error(
                    f"Failed to delete item {item} in the table {table_name} with error {err.response['Error']['Code']}"
                )
            elif err.response['Error']['Code'] == "ResourceNotFoundException":
                logging.error(
                    f"Failed to delete item {item} in the table {table_name} with error {err.response['Error']['Code']}"
                )
            elif err.response['Error']['Code'] == "ItemCollectionSizeLimitExceededException":
                logging.error(
                    f"Failed to delete item {item} in the table {table_name} with error {err.response['Error']['Code']}"
                )
            elif err.response['Error']['Code'] == "TransactionConflictException":
                logging.error(
                    f"Failed to delete item {item} in the table {table_name} with error {err.response['Error']['Code']}"
                )
            elif err.response['Error']['Code'] == "RequestLimitExceeded":
                logging.error(
                    f"Failed to delete item {item} in the table {table_name} with error {err.response['Error']['Code']}"
                )
            elif err.response['Error']['Code'] == "InternalServerError":
                logging.error(
                    f"Failed to delete item {item} in the table {table_name} with error {err.response['Error']['Code']}"
                )
            else:
                logging.error(f"Failed to delete the item {item} from the table '{table_name}' with error '{err}'")
            logging.error(err)
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def validate_update_item(self, table_name: str, update_item: dict, **kwargs):
        """
        Validation method to update an item from the table
        :param table_name: Name of the table
        :param update_item: Update item schema
        :param kwargs: AttributeUpdates/Expected/ReturnValues/ReturnConsumedCapacity/ReturnItemCollectionMetrics/
        ConditionalOperator/ConditionExpression/ExpressionAttributeNames/ExpressionAttributeValues
        """
        update_item = self.update_item(table_name, update_item, **kwargs)
        assert update_item, f"Failed to get the response of the update item. Output: {update_item}"
        assert update_item['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Failed to verify response code. Expected: '{RESPONSE_OK}' but found "
            f"'{update_item['ResponseMetadata']['HTTPStatusCode']}'"
        )
        logging.info(
            Fore.GREEN + f"Successfully updated the item of the table '{table_name}'" + Style.RESET_ALL)
        return f"Successfully updated the item of the table '{table_name}'"

    def update_item(self, table_name: str, update_item: dict, **kwargs):
        """
        Library method to update the item of the table
        :param table_name: Name of the table
        :param update_item: Item which needs to be updated
        :param kwargs: AttributeUpdates/Expected/ReturnValues/ReturnConsumedCapacity/ReturnItemCollectionMetrics/
        ConditionalOperator/ConditionExpression/ExpressionAttributeNames/ExpressionAttributeValues
        :return: Response of the update item
        """
        try:
            update_item = self.client.update_item(TableName=table_name, Key=update_item, **kwargs)
            return update_item
        except ClientError as err:
            print(Fore.RED)
            if err.response['Error']['Code'] == "ConditionalCheckFailedException":
                logging.error(
                    f"Failed to update item {update_item} in the table {table_name} with error "
                    f"{err.response['Error']['Code']}"
                )
            elif err.response['Error']['Code'] == "ProvisionedThroughputExceededException":
                logging.error(
                    f"Failed to update item {update_item} in the table {table_name} with error "
                    f"{err.response['Error']['Code']}"
                )
            elif err.response['Error']['Code'] == "ResourceNotFoundException":
                logging.error(
                    f"Failed to update item {update_item} in the table {table_name} with error "
                    f"{err.response['Error']['Code']}"
                )
            elif err.response['Error']['Code'] == "ItemCollectionSizeLimitExceededException":
                logging.error(
                    f"Failed to update item {update_item} in the table {table_name} with error "
                    f"{err.response['Error']['Code']}"
                )
            elif err.response['Error']['Code'] == "TransactionConflictException":
                logging.error(
                    f"Failed to update item {update_item} in the table {table_name} with error "
                    f"{err.response['Error']['Code']}"
                )
            elif err.response['Error']['Code'] == "RequestLimitExceeded":
                logging.error(
                    f"Failed to update item {update_item} in the table {table_name} with error "
                    f"{err.response['Error']['Code']}"
                )
            elif err.response['Error']['Code'] == "InternalServerError":
                logging.error(
                    f"Failed to update item {update_item} in the table {table_name} with error "
                    f"{err.response['Error']['Code']}"
                )
            else:
                logging.error(
                    f"Failed to update the item {update_item} from the table '{table_name}' with error '{err}'"
                )
            logging.error(err)
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def validate_batch_get_item(self, request_items: dict, **kwargs):
        """
        Validation method to validate the response of the get batch item
        :param request_items: List of items which needs to be retrieved
        :param kwargs: ReturnConsumedCapacity
        :return: Response of the batch get item
        """
        batch_get_item = self.batch_get_item_from_table(request_items, **kwargs)
        assert batch_get_item, f"Failed to get response of the batch get item Output: {batch_get_item}"
        assert batch_get_item['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Failed to verify response code. Expected: '{RESPONSE_OK}' but found "
            f"'{batch_get_item['ResponseMetadata']['HTTPStatusCode']}'"
        )
        logging.info(Fore.GREEN + "Successfully retrieved the batch of items from the table" + Style.RESET_ALL)
        return batch_get_item

    def batch_get_item_from_table(self, request_items: dict, **kwargs):
        """
        Method to batch get items from the table
        :param request_items: List of items which needs to be retrieved
        :param kwargs: ReturnConsumedCapacity
        :return: Response of the batch get item
        """
        try:
            return self.client.batch_get_item(RequestItems=request_items, **kwargs)
        except ClientError as err:
            print(Fore.RED)
            logging.error(f"Failed to batch get item from the table with error '{err}'")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def validate_scan_table(self, table_name: str, scan_filter: dict, **kwargs):
        """
        Validation method to scan the table
        :param table_name: Name of the table
        :param scan_filter: Attributes which needs to be scanned
        :param kwargs: IndexName/AttributesToGet/Limit/Select/ScanFilter/ConditionalOperator/ExclusiveStartKey/
        ReturnConsumedCapacity/TotalSegments/Segment/ProjectionExpression/FilterExpression/ExpressionAttributeNames/
        ExpressionAttributeValues
        :return: Response of the scan table
        """
        scan_table = self.scan_table(table_name, scan_filter, **kwargs)
        assert scan_table, f"Failed to get the response of the scan table. Output: {scan_table}"
        assert scan_table['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Failed to verify response code. Expected: '{RESPONSE_OK}' but found "
            f"'{scan_table['ResponseMetadata']['HTTPStatusCode']}'"
        )
        logging.info(Fore.GREEN + f"Successfully scanned the table '{table_name}'" + Style.RESET_ALL)
        return scan_table

    def scan_table(self, table_name: str, scan_filter: dict, **kwargs):
        """
        Method to scan the table
        :param table_name: Table name
        :param scan_filter: Attributes which needs to be scanned
        :param kwargs: IndexName/AttributesToGet/Limit/Select/ScanFilter/ConditionalOperator/ExclusiveStartKey/
        ReturnConsumedCapacity/TotalSegments/Segment/ProjectionExpression/FilterExpression/ExpressionAttributeNames/
        ExpressionAttributeValues
        :return: Response of the scan table
        """
        try:
            return self.client.scan(TableName=table_name, ScanFilter=scan_filter, **kwargs)
        except ClientError as err:
            print(Fore.RED)
            logging.error(f"Failed to scan the table '{table_name}' with err {err}")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def validate_query_table(
            self, table_name: str, key_condition_expression: str, expression_attribute_values: dict, **kwargs
    ):
        """
        Validation method to query the table
        :param table_name: Name of the table
        :param key_condition_expression: Key conditions
        :param expression_attribute_values: Expression Attributes values
        :param kwargs: IndexName/Select/AttributesToGet/Limit/ConsistentRead/KeyConditions/QueryFilter/
        ConditionalOperator/ScanIndexForward/ExclusiveStartKey/ReturnConsumedCapacity/ProjectionExpression/
        FilterExpression/KeyConditionExpression/ExpressionAttributeNames/ExpressionAttributeValues
        :return: Response of the query table
        """
        query_table = self.query_table(table_name, key_condition_expression, expression_attribute_values, **kwargs)
        assert query_table, f"Failed to get the response of the scan table. Output: {query_table}"
        assert query_table['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Failed to verify response code. Expected: '{RESPONSE_OK}' but found "
            f"'{query_table['ResponseMetadata']['HTTPStatusCode']}'"
        )
        logging.info(
            Fore.GREEN + f"Successfully retrieved data by applying query of  the table '{table_name}'" + Style.RESET_ALL)
        return query_table

    def query_table(self, table_name: str, key_condition_expression: str, expression_attribute_values: dict, **kwargs):
        """
        Method to query the table
        :param table_name: Table name
        :param key_condition_expression: Key conditions
        :param expression_attribute_values: Expression Attributes values
        :param kwargs: IndexName/Select/AttributesToGet/Limit/ConsistentRead/KeyConditions/QueryFilter/
        ConditionalOperator/ScanIndexForward/ExclusiveStartKey/ReturnConsumedCapacity/ProjectionExpression/
        FilterExpression/KeyConditionExpression/ExpressionAttributeNames/ExpressionAttributeValues
        :return: Response of the query table
        """
        try:
            return self.client.query(
                TableName=table_name, KeyConditionExpression=key_condition_expression,
                ExpressionAttributeValues=expression_attribute_values, **kwargs
            )
        except ClientError as err:
            logging.error(Fore.RED + f"Failed to scan the table '{table_name}' with err {err}" + Style.RESET_ALL)
            if self.command_line:
                exit()


def main():
    parser = argparse.ArgumentParser()
    dydb_method_subparser = parser.add_subparsers(dest='dydb_method')

    # Create Dynamo DB table
    create_dydb_method_subparser = dydb_method_subparser.add_parser("create-dynamodb-table",
                                                                    help="Create new dynamodb table")
    create_dydb_method_subparser.add_argument("--table_name", type=str,
                                              help="Name of the table" + Fore.RED + " [REQUIRED]" +
                                                   Style.RESET_ALL, required=True)
    create_dydb_method_subparser.add_argument("--attributes", type=str,
                                              help="Name of the attributes" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                              default=argparse.SUPPRESS, required=True)
    create_dydb_method_subparser.add_argument("--key_schema", type=str,
                                              help="Key schema of the attributes" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                              default=argparse.SUPPRESS, required=True)
    create_dydb_method_subparser.add_argument("--ProvisionedThroughput", "--provisioned_throughput",
                                              type=str,
                                              help="Represents the provisioned throughput settings for a specified "
                                                   "table or index" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                              required=True)
    create_dydb_method_subparser.add_argument("--LocalSecondaryIndexes", "--local_secondary_indexes", type=list,
                                              help="One or more local secondary indexes (the maximum is 5) to be "
                                                   "created on the table", default=argparse.SUPPRESS)
    create_dydb_method_subparser.add_argument("--GlobalSecondaryIndexes", "--global_secondary_indexes", type=list,
                                              help="One or more global secondary indexes (the maximum is 20) to be "
                                                   "created on the table ", default=argparse.SUPPRESS)
    create_dydb_method_subparser.add_argument("--BillingMode", "--billing_mode", type=str,
                                              help="Controls how you are charged for read and write throughput and "
                                                   "how you manage capacity", default=argparse.SUPPRESS)
    create_dydb_method_subparser.add_argument("--StreamSpecification", "--stream_specification",
                                              type=argparse.FileType("r"),
                                              help="The settings for DynamoDB Streams on the table",
                                              default=argparse.SUPPRESS)
    create_dydb_method_subparser.add_argument("--SSESpecification", "--sse_specification", type=argparse.FileType("r"),
                                              help="Represents the settings used to enable server-side encryption",
                                              default=argparse.SUPPRESS)
    create_dydb_method_subparser.add_argument("--Tags", "--tags", type=list,
                                              help="A list of key-value pairs to label the table",
                                              default=argparse.SUPPRESS)
    create_dydb_method_subparser.add_argument(
        "--email", type=str,
        help="Specify email ID to send email notification (Multiple comma-separated email IDs are acceptable)",
        default=argparse.SUPPRESS)

    # Describe dynamodb table
    describe_dynamodb_parser = dydb_method_subparser.add_parser("describe-table", help="Describe dynamoDB table")
    describe_dynamodb_parser.add_argument("--table_name", type=str, help="Name of the table" + Fore.RED + " [REQUIRED]"
                                                                         + Style.RESET_ALL, required=True)
    describe_dynamodb_parser.add_argument(
        "--email", type=str,
        help="Specify email ID to send email notification (Multiple comma-separated email IDs are acceptable)",
        default=argparse.SUPPRESS)

    # List dynamodb table
    list_dynamodb_parser = dydb_method_subparser.add_parser("list-tables", help="List all the dynamodb tables")
    list_dynamodb_parser.add_argument(
        "--email", type=str,
        help="Specify email ID to send email notification (Multiple comma-separated email IDs are acceptable)",
        default=argparse.SUPPRESS)

    # put item in dynamodb table
    put_item_parser = dydb_method_subparser.add_parser("put-item", help="Put Item from dynamoDB table")
    put_item_parser.add_argument("--table_name", type=str, help="Name of the table" + Fore.RED + " [REQUIRED]"
                                                                + Style.RESET_ALL, required=True)
    put_item_parser.add_argument("--item", type=str,
                                 help="Item which need to be in the table" + Fore.RED
                                      + " [REQUIRED]" + Style.RESET_ALL, required=True)
    put_item_parser.add_argument(
        "--email", type=str,
        help="Specify email ID to send email notification (Multiple comma-separated email IDs are acceptable)",
        default=argparse.SUPPRESS)

    # Get Item from dynamodb table
    get_item_parser = dydb_method_subparser.add_parser("get-item", help="get item from dynamoDB table")
    get_item_parser.add_argument("--table_name", type=str,
                                 help="Name of the table" + Fore.RED + " [REQUIRED]" +
                                      Style.RESET_ALL, required=True)
    get_item_parser.add_argument("--key", type=str,
                                 help="Item from the table" + Fore.RED + " [REQUIRED]" +
                                      Style.RESET_ALL, required=True)
    get_item_parser.add_argument(
        "--email", type=str,
        help="Specify email ID to send email notification (Multiple comma-separated email IDs are acceptable)",
        default=argparse.SUPPRESS)

    # update item from dynamoDB table
    update_item_parser = dydb_method_subparser.add_parser("update-item", help="Update an item from dynamoDB table")
    update_item_parser.add_argument("--table_name", type=str, help="Name of the table" + Fore.RED + " [REQUIRED]"
                                                                   + Style.RESET_ALL, required=True)
    update_item_parser.add_argument("--update_item", type=str,
                                    help="Update item schema" + Fore.RED
                                         + " [REQUIRED]" + Style.RESET_ALL, required=True)
    update_item_parser.add_argument("--ExpressionAttributeNames", "--expression_attribute_names", type=str,
                                    help="Expression Attributes names")
    update_item_parser.add_argument("--ExpressionAttributeValues", "--expression_attribute_values", type=str,
                                    help="Update item schema")
    update_item_parser.add_argument("--UpdateExpression", "--update_expression", type=str,
                                    help="Update Expression")
    update_item_parser.add_argument(
        "--email", type=str,
        help="Specify email ID to send email notification (Multiple comma-separated email IDs are acceptable)",
        default=argparse.SUPPRESS)

    # Delete item from dynamoDB table
    del_item_parser = dydb_method_subparser.add_parser("delete-item", help="Delete item from dynamoDB table")
    del_item_parser.add_argument("--table_name", type=str, help="Name of the table" + Fore.RED + " [REQUIRED]"
                                                                + Style.RESET_ALL, required=True)
    del_item_parser.add_argument("--item", type=str,
                                 help="Item schema which need to be deleted from the table" + Fore.RED
                                      + " [REQUIRED]" + Style.RESET_ALL, required=True)
    del_item_parser.add_argument(
        "--email", type=str,
        help="Specify email ID to send email notification (Multiple comma-separated email IDs are acceptable)",
        default=argparse.SUPPRESS)

    # Delete dynamodb table
    delete_dynamodb_parser = dydb_method_subparser.add_parser("delete-table", help="Delete dynamoDB table")
    delete_dynamodb_parser.add_argument("--table_name", type=str, help="Name of the table" + Fore.RED + " [REQUIRED]"
                                                                       + Style.RESET_ALL, required=True)
    delete_dynamodb_parser.add_argument(
        "--email", type=str,
        help="Specify email ID to send email notification (Multiple comma-separated email IDs are acceptable)",
        default=argparse.SUPPRESS)

    args = parser.parse_args()
    if not args.dydb_method:
        parser.print_help()
        return
    parse_args_to_execute(args)


@send_email("DynamoDB", "dydb_method")
def parse_args_to_execute(args, config_data=None):
    if args.dydb_method and config_data:
        dynamodb_obj = DynamoDB(config_data, command_line=True)
        args_dict = vars(args)
        if args.dydb_method == "create-dynamodb-table":
            del args_dict['dydb_method']
            args_dict['attributes'] = [json.loads(args_dict['attributes'])]
            args_dict['key_schema'] = [json.loads(args_dict['key_schema'])]
            args_dict['ProvisionedThroughput'] = json.loads(args_dict['ProvisionedThroughput'])
            return dynamodb_obj.validate_create_dynamodb_table(**args_dict)
        elif args.dydb_method == "describe-table":
            del args_dict['dydb_method']
            return dynamodb_obj.validate_describe_dynamodb_table(**args_dict)
        elif args.dydb_method == "list-tables":
            del args_dict['dydb_method']
            return dynamodb_obj.validate_list_dynamodb_tables(**args_dict)
        elif args.dydb_method == "get-item":
            del args_dict['dydb_method']
            args_dict['key'] = json.loads(args_dict['key'])
            return dynamodb_obj.validate_get_item(**args_dict)
        elif args.dydb_method == "put-item":
            del args_dict['dydb_method']
            args_dict['item'] = json.loads(args_dict['item'])
            return dynamodb_obj.validate_put_item(**args_dict)
        elif args.dydb_method == "update-item":
            del args_dict['dydb_method']
            args_dict['update_item'] = json.loads(args_dict['update_item'])
            args_dict['ExpressionAttributeNames'] = json.loads(args_dict['ExpressionAttributeNames'])
            args_dict['ExpressionAttributeValues'] = json.loads(args_dict['ExpressionAttributeValues'])
            return dynamodb_obj.validate_update_item(**args_dict)
        elif args.dydb_method == "delete-item":
            del args_dict['dydb_method']
            args_dict['item'] = json.loads(args_dict['item'])
            return dynamodb_obj.validate_delete_item_from_dynamodb_table(**args_dict)
        elif args.dydb_method == "delete-table":
            del args_dict['dydb_method']
            return dynamodb_obj.validate_delete_dynamodb_table(**args_dict)


if __name__ == '__main__':
    main()
