#!/usr/bin/env python3
import argparse
import json
import logging
import sys
import time
import os
import datetime
import logging.handlers

from typing import List, Dict

import boto3
from botocore.exceptions import ClientError
from colorama import Fore, Style
from prettytable import PrettyTable

from email_notifications import send_email
from constants import *


class EC2:
    def __init__(self, config, command_line=False):
        self.client = boto3.client(
            "ec2", **config
        )

        self.resource = boto3.resource(
            "ec2", **config
        )

        self.config = config
        self.command_line = command_line
        if command_line:
            home_dir = os.path.expanduser("~")
            # logging.basicConfig(level=logging.INFO, format='%(message)s')
            # sys.tracebacklimit = 0
            cur_date = datetime.datetime.now().strftime("%d_%b_%Y")
            log_dir_path = os.path.join(home_dir, ".a4cloudstack_logs")
            final_log_path = log_dir_path + "/log_" + cur_date
            if not os.path.exists(final_log_path):
                os.makedirs(final_log_path, mode=0o777, exist_ok=True)
            logging.getLogger().setLevel(logging.NOTSET)
            console = logging.StreamHandler(sys.stdout)
            console.setLevel(logging.INFO)
            formater = logging.Formatter('%(message)s')
            console.setFormatter(formater)
            logging.getLogger().addHandler(console)

            # Add file rotating handler, with level DEBUG
            rotatingHandler = logging.handlers.RotatingFileHandler(filename=final_log_path + "/" + 'ec2.log',
                                                                   maxBytes=100000, backupCount=5)
            rotatingHandler.setLevel(logging.INFO)
            formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
            rotatingHandler.setFormatter(formatter)
            logging.getLogger().addHandler(rotatingHandler)
            sys.tracebacklimit = 0

    def create_validate_instance_from_image(self, image_id: str, maxcount: int = 1, mincount: int = 1, **kwargs):
        """
        Method to create and validate EC2 instance from an given image.
           :param image_id: ID of the image from which instance will be
           :param maxcount: Maximum number of instances
           :param mincount: Minimum number of instances
           :param kwargs: BlockDeviceMappings/InstanceType/Ipv6AddressCount/Ipv6Addresses/KernelId/KeyName/Monitoring/
            Placement/RamdiskId/SecurityGroupIds/SecurityGroups/SubnetId/UserData/AdditionalInfo/IamInstanceProfile
            :return: Instance ID
        """
        logging.info(f"Creating an instance from image id: {image_id}")
        instance = self.create_instance_from_image(image_id, MaxCount=maxcount, MinCount=mincount, **kwargs)
        assert instance, f"Failed to create instance"
        assert instance['Instances'][0]['InstanceId'], f"Failed to create instance. Output {instance}"

        for _ in range(24):
            instance_info = self.get_validate_instance(InstanceIds=[instance['Instances'][0]['InstanceId']])
            if instance_info['Reservations'][0]['Instances'][0]['State']['Name'] == 'running':
                logging.info(f"Instance created with instance ID: {instance['Instances'][0]['InstanceId']}")
                break
            time.sleep(5)
        else:
            raise Exception("Instance not came in running state after 120 sec.")
        print(Fore.GREEN + f"Instance ID - {instance['Instances'][0]['InstanceId']}" + Style.RESET_ALL)
        return instance['Instances'][0]['InstanceId']

    def create_instance_from_image(self, image_id: str, **kwargs):
        """ Method for creating an instance from an given image.
           :param image_id: ID of the image from which instance will be
           :param kwargs: BlockDeviceMappings/InstanceType/Ipv6AddressCount/Ipv6Addresses/KernelId/KeyName/Monitoring/
            Placement/RamdiskId/SecurityGroupIds/SecurityGroups/SubnetId/UserData/AdditionalInfo/IamInstanceProfile
            :return: instance_create
           """
        try:
            instance_create = self.client.run_instances(ImageId=image_id, **kwargs)
            return instance_create
        except Exception as err:
            print(Fore.RED)
            logging.error(err)
            logging.error(
                f"Failed to Create image with image id '{image_id}' with error: {err}"
            )
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def fetch_instance_info(self, instance_id: str):
        """ Method for get info of instances.
        :return: Instance_info
        """
        try:
            instance_info = self.client.describe_instances(InstanceIds=[instance_id])
            logging.info(json.dumps(instance_info, indent=7, sort_keys=True, default=str))
            return instance_info
        except Exception as err:
            logging.error(f"Unable to fetch instance information. Error - {err}")

    def list_all_instances(self):
        """ Method for get info of instances.
        :return: Instance_info
        """
        try:
            instances_info = self.resource.instances.all()
            mytable = PrettyTable(["Id", "Platform", "Type", "Public IPv4", "AMI", "State"])
            for instance in instances_info:
                mytable.add_row([instance.id, instance.platform, instance.instance_type, instance.public_ip_address,
                                 instance.image.id, instance.state])
            mytable.hrules = 1
            print("\n".join(mytable.get_string().splitlines()))

        except Exception as err:
            print(Fore.RED)
            logging.error(f"Unable to list instances. Error - {err}")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def get_instance(self, **kwargs):
        """ Method for get info of instances.
        :param kwargs: Filters/DryRun/MaxResults/NextToken
        :return: Instance_info
        """
        try:
            instance_info = self.client.describe_instances(**kwargs)
            return instance_info
        except Exception as err:
            print(Fore.RED)
            logging.error(err)
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def get_validate_instance(self, **kwargs):
        """ Method for get & validate info of instances.
        :param kwargs: Filters/DryRun/MaxResults/NextToken
        :return: Instance_info
        """
        instances_info = self.get_instance(**kwargs)
        assert instances_info, f"Error in getting instances info. Output: {instances_info}"
        return instances_info

    def validate_status_check(self, instance_id: str):
        """
        Method for validating 2/2 state check
        :param instance_id: ID of the instance to be checked.
        """
        logging.info(f"Checking if instance with instance id '{instance_id}' is in 2/2 state")
        for _ in range(60):
            instance = self.status_check(instance_id)
            assert instance, f"Instance status not found."
            if (str(instance['InstanceStatus']['Status']) and str(instance['SystemStatus']['Status'])) == 'ok':
                break
            logging.info(
                f"Currently system_status is {instance['SystemStatus']['Status']} and instance_status is "
                f"{instance['InstanceStatus']['Status']}"
            )
            time.sleep(5)
        else:
            raise Exception("2/2 state check not achieved after 300 second.")
        logging.info(Fore.GREEN + f"Instance with instance id '{instance_id}' is in 2/2 state" + Style.RESET_ALL)

    def status_check(self, instance_id: str):
        """
        This method is for get instance status of a given instance using boto.
        :param instance_id: ID of the instance to be checked.
        :return: True/False
        """
        instance = self.client.describe_instance_status(InstanceIds=[instance_id])
        if not instance['InstanceStatuses']:
            logging.error(
                Fore.YELLOW + f"Instant with Instance ID - {instance_id} is currently not UP."
                              f"\nPossible state- initializing/stopped/terminated" + Style.RESET_ALL)
            if self.command_line:
                exit()
        else:
            return instance['InstanceStatuses'][0]

    def remove_instance(self, instance_id: str):
        """ This method is for removing/deleting a node/instance.
        :param instance_id: Instance ID to be removed.
        :return: instance_remove.
        """
        instance_remove = None
        node = self.get_instance(InstanceIds=[instance_id])
        if node['Reservations'][0]['Instances'][0]['State']['Name'] == 'terminated':
            logging.info(Fore.YELLOW + f"Instance {node['Reservations'][0]['Instances'][0]['InstanceId']} "
                                       f"is already terminated" + Style.RESET_ALL)
            if self.command_line:
                exit()
        else:
            try:
                instance_remove = self.client.terminate_instances(InstanceIds=[instance_id])
            except Exception as err:
                print(Fore.RED)
                logging.error(err)
                logging.error(
                    f"Failed to Remove Instance '{instance_id}' with error: {err}"
                )
                print(Style.RESET_ALL)
                if self.command_line:
                    exit()
        return instance_remove

    def remove_validate_instance(self, instance_id: str, negative_case: bool = False):
        """ This method is for removing/deleting a node/instance.
        :param instance_id: Instance ID to be removed.
        :param negative_case: False/True
        """
        logging.info(f"Terminating instance with instance id: {instance_id}")
        delete_instance = self.remove_instance(instance_id)
        if negative_case:
            assert not delete_instance, f"Error in removing terminated instance: {delete_instance}"
            logging.info("Instance already in terminated state.")
        else:
            assert delete_instance, f"Error in remove instance: {delete_instance}"
            assert delete_instance['TerminatingInstances'][0]['CurrentState']['Name'] == "shutting-down", (
                f"Error in Instance delete: {delete_instance}"
            )
            logging.info(Fore.GREEN + "Instance terminated successfully." + Style.RESET_ALL)
        return delete_instance

    def create_tag(self, instance_ids: List, tags: List[Dict]):
        """ This method is for creating tag in instances.
        :param instance_ids: List of Instance ID where tag needs to be added.
        :param tags: List of Key value pair tag which need to add in instance
        :return: addtag
        """
        addtag = self.client.create_tags(Resources=instance_ids, Tags=tags)
        return addtag

    def create_validate_tag(self, instance_ids: List, tags: List[Dict]):
        """ This method is for creating and validating tag in instances.
        :param instance_ids: List of Instance ID where tag needs to be added.
        :param tags: List of Key value pair tag which need to add in instance
        """
        logging.info(f"Adding {tags} to the instance with ID {instance_ids}")
        add_tag = self.create_tag(instance_ids, tags)
        assert add_tag['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Error in instance tagging. Output: {add_tag}"
        )
        logging.info(Fore.GREEN + f"Tags added successfully to instance" + Style.RESET_ALL)
        return add_tag

    def stop_instance(self, instance_id: str, **kwargs):
        """ This method is for power off a node/instance.
        :param instance_id: Instance ID of instance to be power off.
        :param kwargs: Hibernate/DryRun/Force
        :return: instance_stop.
        """
        instance_stop = None
        node = self.get_instance(InstanceIds=[instance_id])
        if node['Reservations'][0]['Instances'][0]['State']['Name'] == 'stopped':
            logging.info(
                Fore.YELLOW + f"Instance {node['Reservations'][0]['Instances'][0]['InstanceId']} is already stopped" + Style.RESET_ALL)
            if self.command_line:
                exit()
        else:
            try:
                instance_stop = self.client.stop_instances(InstanceIds=[instance_id], **kwargs)
                return instance_stop
            except Exception as err:
                print(Fore.RED)
                logging.error(err)
                logging.error(
                    f"Failed to Stop Instance '{instance_id}' with error: {err}"
                )
                print(Style.RESET_ALL)
                if self.command_line:
                    exit()

    def stop_validate_instance(self, instance_id: str, negative_case: bool = False, **kwargs):
        """ This method is for validating and power off a node/instance.
        :param instance_id: Instance ID of instance to be power off.
        :param kwargs: Hibernate/DryRun/Force
        :param negative_case: False/True
        """
        logging.info(f"Power off the instance with instance id: {instance_id}")
        stop_instance = self.stop_instance(instance_id, **kwargs)
        if negative_case:
            assert not stop_instance, f"Power off done on stopped instance: {stop_instance}"
            logging.info("Instance already in stopped state.")
        else:
            assert stop_instance, f"Error in power off instance: {stop_instance}"
            assert stop_instance['StoppingInstances'][0]['CurrentState']['Name'] == "stopping", (
                f"Error in Instance delete: {stop_instance}"
            )
            for _ in range(12):
                node = self.get_validate_instance(InstanceIds=[instance_id])
                if node['Reservations'][0]['Instances'][0]['State']['Name'] == 'stopped':
                    logging.info(Fore.GREEN + "Instance powered-off successfully." + Style.RESET_ALL)
                    break
                logging.info(f"Instance current state is {node['Reservations'][0]['Instances'][0]['State']['Name']}")
                time.sleep(5)
            else:
                raise TimeoutError(
                    Fore.RED + "Instance not powered-off in 60 sec after power-off the instance" + Style.RESET_ALL)
        return stop_instance

    def start_instance(self, instance_id: str, **kwargs):
        """ This method is for power on a node/instance.
        :param instance_id: Instance ID of instance to be Power on.
        :param kwargs: AdditionalInfo/DryRun
        :return: instance_start.
        """
        instance_start = None
        node = self.get_instance(InstanceIds=[instance_id])
        if node['Reservations'][0]['Instances'][0]['State']['Name'] == 'running':
            logging.info(Fore.YELLOW + f"Instance {node['Reservations'][0]['Instances'][0]['InstanceId']} is already "
                                       f"running" + Style.RESET_ALL)
            if self.command_line:
                exit()
        else:
            try:
                instance_start = self.client.start_instances(InstanceIds=[instance_id], **kwargs)
                return instance_start
            except Exception as err:
                print(Fore.RED)
                logging.error(err)
                logging.error(
                    f"Failed to start Instance '{instance_id}' with error: {err}"
                )
                print(Style.RESET_ALL)
                if self.command_line:
                    exit()

    def start_validate_instance(self, instance_id: str, negative_case: bool = False, **kwargs):
        """ This method is for validating and power on a node/instance.
        :param instance_id: Instance ID of instance to be power on.
        :param kwargs: AdditionalInfo/DryRun
        :param negative_case: False/True
        """
        logging.info(f"Power on the instance with instance id: {instance_id}")
        start_instance = self.start_instance(instance_id, **kwargs)
        if negative_case:
            assert not start_instance, f"Power on done on running instance: {start_instance}"
            logging.info("Instance already in running state.")
        else:
            assert start_instance, f"Error in power on instance: {start_instance}"
            assert start_instance['StartingInstances'][0]['CurrentState']['Name'] == "pending", (
                f"Error in Instance delete: {start_instance}"
            )
            for _ in range(12):
                node = self.get_validate_instance(InstanceIds=[instance_id])
                if node['Reservations'][0]['Instances'][0]['State']['Name'] == 'running':
                    logging.info(Fore.GREEN + "Instance powered-on successfully." + Style.RESET_ALL)
                    break
                logging.info(f"Instance current state is {node['Reservations'][0]['Instances'][0]['State']['Name']}")
                time.sleep(5)
            else:
                raise TimeoutError(
                    Fore.CYAN + "Instance not came in running state in 60 sec after power-on the instance" + Style.RESET_ALL)
        return start_instance

    def reboot_instance(self, instance_id: str, **kwargs):
        """ This method is for reboot a node/instance.
        :param instance_id: Instance ID of instance to be rebooted.
        :param kwargs: DryRun
        :return: instance_reboot.
        """
        try:
            instance_reboot = self.client.reboot_instances(InstanceIds=[instance_id], **kwargs)
            return instance_reboot
        except Exception as err:
            print(Fore.RED)
            logging.error(err)
            logging.error(
                f"Failed to Reboot Instance '{instance_id}' with error: {err}"
            )
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def reboot_validate_instance(self, instance_id: str, **kwargs):
        """ This method is for validating and power on a node/instance.
        :param instance_id: Instance ID of instance to be rebooted.
        :param kwargs: AdditionalInfo/DryRun
        """
        logging.info(f"Reboot the instance with instance id: {instance_id}")
        reboot_instance = self.reboot_instance(instance_id, **kwargs)
        assert reboot_instance['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Error in rebooting instance. Output: {reboot_instance}"
        )
        for _ in range(12):
            node = self.get_instance(InstanceIds=[instance_id])
            if node['Reservations'][0]['Instances'][0]['State']['Name'] == 'running':
                break
            logging.info(f"Instance current state is {node['Reservations'][0]['Instances'][0]['State']['Name']}")
            time.sleep(5)
        else:
            raise TimeoutError(Fore.RED + "Instance not came in running state in 60 sec after reboot the instance" +
                               Style.RESET_ALL)
        self.validate_status_check(instance_id)
        logging.info(Fore.GREEN + "Instance rebooted successfully." + Style.RESET_ALL)
        if self.command_line:
            return f"Instance {instance_id} rebooted successfully."

    def create_ebs_volume(self, availability_zone: str, size: int = 0, snapshot_id: str = "", **kwargs):
        """
        Method to create an EBS volume in given availability zone
        :param availability_zone: availability zone
        :param size: EBS volume size in GiBs
        :param snapshot_id: snapshot id from which to create the volume
        :param kwargs: Encrypted/Iops/KmsKeyId/OutpostArn/VolumeType/DryRun/TagSpecifications/MultiAttachEnabled
        :return: create_volume
        """
        if snapshot_id:
            create_volume = self.client.create_volume(
                AvailabilityZone=availability_zone, SnapshotId=snapshot_id, **kwargs
            )
        elif size:
            create_volume = self.client.create_volume(AvailabilityZone=availability_zone, Size=size, **kwargs)
        else:
            raise ValueError(Fore.YELLOW + "Either provide volume size or snapshot id" + Style.RESET_ALL)
        return create_volume

    def validate_create_ebs_volume(self, availability_zone: str, size: int = 0, snapshot_id: str = "", **kwargs):
        """
        Method to create and validate an EBS volume in given availability zone
        :param availability_zone: availability zone
        :param size: EBS volume size in GiBs
        :param snapshot_id: snapshot id from which to create the volume
        :param kwargs: Encrypted/Iops/KmsKeyId/OutpostArn/VolumeType/DryRun/TagSpecifications/MultiAttachEnabled
        :return: volume Id
        """
        logging.info(f"Creating EBS volume in {availability_zone} zone")
        create_volume = self.create_ebs_volume(availability_zone, size, snapshot_id, **kwargs)
        assert create_volume['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Error in creating EBS volume. Output: {create_volume}"
        )
        assert create_volume["AvailabilityZone"] == availability_zone and create_volume["State"] == "creating", (
            f"Error in creating EBS volume. Output: {create_volume}"
        )

        for _ in range(12):
            ebs_vol = self.validate_get_ebs_volume(VolumeIds=[create_volume['VolumeId']], console_logs=False)
            if ebs_vol["Volumes"][0]["State"] == "available":
                break
            logging.info(f"Current state of ebs volume is {ebs_vol['Volumes'][0]['State']}")
            time.sleep(5)
        else:
            raise TimeoutError(
                Fore.RED + "EBS volume not in available state after 60 sec of volume creation" + Style.RESET_ALL)

        logging.info(
            Fore.GREEN + f"EBS volume created successfully. Volume ID: {create_volume['VolumeId']}" + Style.RESET_ALL)
        return create_volume['VolumeId']

    def get_ebs_volumes(self, **kwargs):
        """
        Method to get ebs volumes
        :param kwargs: Filters/VolumeIds/DryRun/MaxResults/MaxResults
        :return vol_info
        """
        vol_info = self.client.describe_volumes(**kwargs)
        return vol_info

    def validate_get_ebs_volume(self, console_logs=True, **kwargs):
        """
        Method to get and validate ebs volume info
        :param kwargs: Filters/VolumeIds/DryRun/MaxResults/MaxResults
        :param console_logs: show logs on console
        :return vol_info
        """
        vol_info = self.get_ebs_volumes(**kwargs)
        assert vol_info['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Error in creating EBS volume. Output: {vol_info}"
        )
        if self.command_line and console_logs:
            for vol in vol_info['Volumes']:
                logging.info(f"\n\nVolume '{vol['VolumeId']}' Details -")
                for key, val in vol.items():
                    if key == "Attachments" and val != []:
                        for k, v in val[0].items():
                            logging.info(f"{k} -> \t {v}")
                    else:
                        logging.info(f"{key} -> \t {val}")
        return vol_info

    def attach_ebs_volume(self, device: str, instance_id: str, volume_id: str, **kwargs):
        """
        Method to attache an EBS volume to a running or stopped instance and exposes it to the instance with
        the specified device name.
        :param device: Device name i.e. /dev/sdh or xvdh
        :param instance_id: Instance Id where volume need to attach
        :param volume_id: EBS volume Id
        :param kwargs: DryRun
        return: vol_attach
        """
        vol_attach = self.client.attach_volume(
            Device=device, InstanceId=instance_id, VolumeId=volume_id, **kwargs
        )
        return vol_attach

    def attach_validate_ebs_volume(self, device: str, instance_id: str, volume_id: str, **kwargs):
        """
        Method to attache and validate an EBS volume to a running or stopped instance and exposes it to the
        instance with the specified device name.
        :param device: Device name i.e. /dev/sdh or xvdh
        :param instance_id: Instance Id where volume need to attach
        :param volume_id: EBS volume Id
        :param kwargs: DryRun
        """
        volumes = {}

        logging.info(f"Check if {volume_id} EBS volume is in available state")
        ebs_vol = self.validate_get_ebs_volume(VolumeIds=[volume_id], console_logs=False)
        assert ebs_vol["Volumes"][0]["State"] == "available", f"Volume not in available state. {ebs_vol}"
        logging.info(Fore.GREEN + "Volume is in available state" + Style.RESET_ALL)

        logging.info(f"Attaching {volume_id} EBS volume to instance {instance_id}")
        vol_attach = self.attach_ebs_volume(device, instance_id, volume_id, **kwargs)
        assert vol_attach['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Error in attaching EBS volume. Output: {vol_attach}"
        )
        assert vol_attach["State"] == "attaching", f"Error in attaching EBS volume. Output: {vol_attach}"

        time.sleep(5)
        instance_info = self.get_validate_instance(InstanceIds=[instance_id])
        for volume in instance_info['Reservations'][0]['Instances'][0]["BlockDeviceMappings"]:
            volumes[volume["Ebs"]["VolumeId"]] = volume["Ebs"]["Status"]
        assert volumes[volume_id] == 'attached', f"Error in attaching EBS volume. Output: {instance_info}"
        logging.info(Fore.GREEN + "EBS volume attached successfully" + Style.RESET_ALL)
        return vol_attach

    def detach_ebs_volume(self, instance_id: str, volume_id: str, **kwargs):
        """
        Method to detach an EBS volume to a running or stopped instance
        :param instance_id: Instance Id where volume need to detach
        :param volume_id: EBS volume Id
        :param kwargs: Device/Force/DryRun
        return: vol_detach
        """
        vol_detach = self.client.detach_volume(InstanceId=instance_id, VolumeId=volume_id, **kwargs)
        return vol_detach

    def detach_validate_ebs_volume(self, instance_id: str, volume_id: str, **kwargs):
        """
        Method to detach and validate an EBS volume to a running or stopped instance
        :param instance_id: Instance Id where volume need to detach
        :param volume_id: EBS volume Id
        :param kwargs: Device/Force/DryRun
        """
        volumes = {}
        logging.info(f"Detaching {volume_id} EBS volume from instance {instance_id}")
        vol_detach = self.detach_ebs_volume(instance_id, volume_id, **kwargs)
        assert vol_detach['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Error in attaching EBS volume. Output: {vol_detach}"
        )
        assert vol_detach["State"] == "detaching", f"Error in detaching EBS volume. Output: {vol_detach}"

        time.sleep(5)
        for _ in range(12):
            instance_info = self.get_validate_instance(InstanceIds=[instance_id])
            for volume in instance_info['Reservations'][0]['Instances'][0]["BlockDeviceMappings"]:
                volumes[volume["Ebs"]["VolumeId"]] = volume["Ebs"]["Status"]
            if volume_id not in volumes:
                logging.info(Fore.GREEN + "EBS volume detached successfully" + Style.RESET_ALL)
                break
            volumes = {}
            time.sleep(5)
        else:
            raise Exception(Fore.RED + "Volume not detached after 60 sec." + Style.RESET_ALL)
        return vol_detach

    def delete_ebs_volume(self, volume_id: str, **kwargs):
        """
        Method to delete an EBS volume
        :param volume_id: volume id
        :param kwargs: DryRun
        :return: delete_volume
        """
        delete_volume = self.client.delete_volume(VolumeId=volume_id, **kwargs)
        return delete_volume

    def delete_validate_ebs_volume(self, volume_id: str, **kwargs):
        """
        Method to delete and validate an EBS volume
        :param volume_id: volume id
        :param kwargs: DryRun
        """
        logging.info(f"Deleting EBS volume with id {volume_id} ")
        delete_volume = self.delete_ebs_volume(volume_id, **kwargs)
        assert delete_volume['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Error in creating EBS volume. Output: {delete_volume}"
        )
        logging.info(Fore.GREEN + "EBS volume deleted successfully" + Style.RESET_ALL)
        if self.command_line:
            return f"EBS Volume - {volume_id} deleted successfully."

    def create_ami(self, instance_id: str, name: str, **kwargs):
        """
        Method to create amazon machine image from given instance
        :param instance_id: Instance Id
        :param name: AMI name
        :param kwargs: BlockDeviceMappings/Description/DryRun/NoReboot
        :return: create_ami
        """
        create_ami = self.client.create_image(InstanceId=instance_id, Name=name, **kwargs)
        return create_ami

    def create_validate_ami(self, instance_id: str, name: str, **kwargs):
        """
       Method to create and validate amazon machine image from given instance
       :param instance_id: Instance Id
       :param name: AMI name
       :param kwargs: BlockDeviceMappings/Description/DryRun/NoReboot
       :return: AMI ID
       """
        logging.info(f"Creating machine image from instance {instance_id}")
        create_ami = self.create_ami(instance_id, name, **kwargs)
        assert create_ami['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Error in creating machine image. Output: {create_ami}"
        )
        assert create_ami["ImageId"], f"Error in creating machine image. Output: {create_ami}"

        time.sleep(5)
        for _ in range(24):
            image_info = self.validate_get_image(ImageIds=[create_ami["ImageId"]], console_logs=False)
            if image_info['Images'][0]['State'] == 'available':
                logging.info(
                    Fore.GREEN + f"AMI created successfully. AMI Id: {create_ami['ImageId']}." + Style.RESET_ALL)
                break
            logging.info(f"Current state of AMI is {image_info['Images'][0]['State']}")
            time.sleep(10)
        else:
            raise Exception(Fore.RED + "AMI is not in available state after 120 sec of AMI creation." + Style.RESET_ALL)
        return create_ami["ImageId"]

    def get_image(self, **kwargs):
        """
        Method to get details for AMI
        :param kwargs: ExecutableUsers/Filters/ImageIds/Owners/DryRun
        :return: image_info
        """
        image_info = self.client.describe_images(**kwargs)
        return image_info

    def validate_get_image(self, negative_case=False, console_logs=True, **kwargs):
        """
        Method to get and validate AMI details
        :param negative_case: True/False
        :param kwargs: ExecutableUsers/Filters/ImageIds/Owners/DryRun
        :return: image_info
        """
        image_info = self.get_image(**kwargs)
        assert image_info['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Error in getting machine image. Output: {image_info}"
        )
        if self.command_line and console_logs and negative_case is not True:
            for key, val in image_info['Images'][0].items():
                if key == "BlockDeviceMappings" and val != []:
                    for k, v in val[0].items():
                        if k == "Ebs" and v is not None:
                            for a, b in v.items():
                                logging.info(f"{a} -> {b}")
                        else:
                            logging.info(f"{k} -> {v}")
                else:
                    logging.info(f"{key} -> {val}")
        return image_info

    def deregister_ami(self, image_id: str, **kwargs):
        """
        Method to deregister/delete an amazon machine image
        :param image_id: AMI ID
        :param kwargs: DryRun
        :return: delete_ami
        """
        delete_ami = self.client.deregister_image(ImageId=image_id, **kwargs)
        return delete_ami

    def deregister_validate_ami(self, image_id: str, delete_snapshot: bool = True, **kwargs):
        """
        Method to deregister/delete an amazon machine image
        :param image_id: AMI ID
        :param delete_snapshot: True/False if snapshot created by image need to delete
        :param kwargs: DryRun
        """
        snapshot_ids = []
        image_info = self.validate_get_image(ImageIds=[image_id], console_logs=False)
        for device in image_info['Images'][0]['BlockDeviceMappings']:
            if "Ebs" in device:
                snapshot_ids.append(device['Ebs']['SnapshotId'])

        logging.info(f"Deregister AMI with id : {image_id}")
        delete_ami = self.deregister_ami(image_id, **kwargs)
        assert delete_ami['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Error in image deregistration. Output {delete_ami}"
        )

        image_info = self.validate_get_image(negative_case=True, ImageIds=[image_id])
        assert not image_info['Images'], f"Error in image deregistration. Output {image_info}"
        logging.info(Fore.GREEN + "AMI deregisterd successfully." + Style.RESET_ALL)

        if delete_snapshot:
            self.delete_validate_snapshot(snapshot_ids)
        if self.command_line:
            return f"AMI with ID - {image_id} deregisterd successfully."

    def create_snapshot(self, instance_id: str, **kwargs):
        """
        Method to create crash-consistent snapshots of multiple EBS volumes including boot volume attached to the
        instance
        :param instance_id: Instance ID
        :param kwargs: Description/TagSpecifications/DryRun/CopyTagsFromSource
        :return snapshot
        """
        instance_specs = {'InstanceId': instance_id, 'ExcludeBootVolume': False}
        snapshot = self.client.create_snapshots(InstanceSpecification=instance_specs, **kwargs)
        return snapshot

    def create_validate_snapshot(self, instance_id: str, **kwargs):
        """
        Method to create and validate crash-consistent snapshots of multiple EBS volumes including boot
        volume attached to the instance
        :param instance_id: Instance ID
        :param kwargs: Description/TagSpecifications/DryRun/CopyTagsFromSource
        :return snapshot Id
        """
        snapshot_ids = []
        count = 0
        logging.info(f"Creating snapshot of instance with id {instance_id}")
        snapshot = self.create_snapshot(instance_id, **kwargs)
        assert snapshot['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Error in snapshot creation. Output {snapshot}"
        )
        for item in snapshot["Snapshots"]:
            snapshot_ids.append(item["SnapshotId"])

        for _ in range(36):
            snapshots_info = self.get_validate_snapshot(console_log=False, SnapshotIds=snapshot_ids)
            for snap in snapshots_info['Snapshots']:
                if snap['State'] == 'completed':
                    count = count + 1
                    logging.info(Fore.GREEN + f"Snapshot {snap['SnapshotId']} created successfully." + Style.RESET_ALL)
                else:
                    logging.info(f"Current state of Snapshot {snap['SnapshotId']} is {snap['State']}")
            if count == len(snapshots_info['Snapshots']):
                break
            time.sleep(5)
        else:
            raise Exception(Fore.RED + f"Snapshots not created in 180 sec." + Style.RESET_ALL)
        return snapshot_ids

    def get_snapshot(self, **kwargs):
        """
        Method to get information of snapshot
        :param kwargs: Filters/SnapshotIds/MaxResults/NextToken/OwnerIds/RestorableByUserIds/DryRun
        :return snapshot
        """
        try:
            snapshot_info = self.client.describe_snapshots(**kwargs)
            return snapshot_info
        except ClientError as err:
            print(Fore.RED)
            if err.response['Error']['Code'] == 'InvalidSnapshot.NotFound':
                logging.info("Snapshot not found")
            else:
                logging.info(err.response['Error']['Code'])
                logging.info(err)
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def get_validate_snapshot(self, negative_case: bool = False, console_log=True, **kwargs):
        """
        Method to get & validate information of snapshot
        :param negative_case: True/False
        :param kwargs: Filters/SnapshotIds/MaxResults/NextToken/OwnerIds/RestorableByUserIds/DryRun
        :return snapshot
        """
        snapshot_info = self.get_snapshot(**kwargs)
        if self.command_line and console_log:
            if snapshot_info['Snapshots'] is not None:
                for param, val in snapshot_info['Snapshots'][0].items():
                    val = "None" if val == "" else val
                    logging.info(param + "-> \t" + str(val))
            else:
                logging.info("No Such snapshot is present.")

        if not negative_case:
            assert snapshot_info['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
                f"Error in snapshot info. Output {snapshot_info}"
            )
            return snapshot_info

    def delete_snapshot(self, snapshot_id: str, **kwargs):
        """
        Method to delete a snapshot
        :param snapshot_id: Snapshot ID
        :param kwargs: DryRun
        :return: delete_snapshot
        """
        try:
            delete_snapshot = self.client.delete_snapshot(SnapshotId=snapshot_id, **kwargs)
            return delete_snapshot
        except ClientError as err:
            print(Fore.RED)
            logging.info(err)
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def delete_validate_snapshot(self, snapshot_ids: List, **kwargs):
        """
        Method to delete snapshots
        :param snapshot_ids: List of Snapshot ID
        :param kwargs: DryRun
        """
        logging.info(f"Deleting snapshots : {snapshot_ids}")
        for snapshot in snapshot_ids:
            delete_snapshot = self.delete_snapshot(snapshot, **kwargs)
            assert delete_snapshot['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
                f"Error in snapshot delete. Output {delete_snapshot}"
            )
        if not self.command_line:
            snapshots_info = self.get_validate_snapshot(SnapshotIds=snapshot_ids, negative_case=True)
            assert not snapshots_info, f"Error in snapshot delete. Output: {snapshots_info}"
        logging.info(Fore.GREEN + "Snapshots deleted successfully." + Style.RESET_ALL)
        return f"Snapshot with ID - {snapshot_ids} deleted successfully."

    def assign_private_ipaddress(
            self, network_interface_id: str, privateips: List = None, private_ip_count: int = 0, **kwargs
    ):
        """
        Method to assign new private IP address to the network
        :param network_interface_id: Network interface id attached to the instance
        :param privateips: List of private IP address
        :param private_ip_count: Count of IP addresses
        :param kwargs: AllowReassignment
        :return: assign_ip
        """
        if privateips:
            assign_ip = self.client.assign_private_ip_addresses(
                NetworkInterfaceId=network_interface_id, PrivateIpAddresses=privateips, **kwargs
            )
        elif private_ip_count:
            assign_ip = self.client.assign_private_ip_addresses(
                NetworkInterfaceId=network_interface_id, SecondaryPrivateIpAddressCount=private_ip_count, **kwargs
            )
        else:
            raise Exception("Either provide Private IP list or Private IP count.")
        return assign_ip

    def assign_validate_private_ipaddress(
            self, network_interface_id: str, instance_id: str, privateips: List = None, private_ip_count: int = 0,
            **kwargs
    ):
        """
        Method to assign and validate new private IP address to the network
        :param network_interface_id: Network interface id attached to the instance
        :param instance_id: InstanceId associated with network interface
        :param privateips: List of private IP address
        :param private_ip_count: Count of IP addresses
        :param kwargs: AllowReassignment/PrivateIpAddresses/SecondaryPrivateIpAddressCount
        """
        new_ips = []
        logging.info(f"Assigning new IP address to network interface {network_interface_id}")
        assign_ip = self.assign_private_ipaddress(network_interface_id, privateips, private_ip_count, **kwargs)
        assert assign_ip['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Error in assigning IP address. Output {assign_ip}"
        )
        interface_info = self.get_validate_network_interface(NetworkInterfaceIds=[network_interface_id])
        assert len(interface_info['NetworkInterfaces'][0]['PrivateIpAddresses']) > 1, (
            f"Error in assigning IP address. Output {interface_info}"
        )
        for ip in interface_info['NetworkInterfaces'][0]['PrivateIpAddresses']:
            if not ip['Primary']:
                new_ips.append(ip['PrivateIpAddress'])

        instance_info = self.get_validate_instance(InstanceIds=[instance_id])
        for ip in instance_info['Reservations'][0]['Instances'][0]['NetworkInterfaces'][0]['PrivateIpAddresses']:
            if not ip['Primary']:
                assert ip['PrivateIpAddress'] in new_ips, f"New Ip not found in instance. {ip}"
        logging.info(f"New IP {new_ips} assigned to network {network_interface_id} & instance {instance_id}")

    def get_network_interface(self, **kwargs):
        """
        Method to get details of network interface
        :param kwargs: Filters/DryRun/NetworkInterfaceIds/NextToken/MaxResults
        :return interface_info
        """
        interface_info = self.client.describe_network_interfaces(**kwargs)
        return interface_info

    def get_validate_network_interface(self, **kwargs):
        """
        Method to get details of network interface
        :param kwargs: Filters/DryRun/NetworkInterfaceIds/NextToken/MaxResults
        :return interface_info
        """
        interface_info = self.get_network_interface(**kwargs)
        assert interface_info['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Error in getting network interface info. Output {interface_info}"
        )
        return interface_info

    def create_security_group(self, description: str, grp_name: str, **kwargs):
        """
        Method to create a security group
        :param description: Description for the security group
        :param grp_name: Name of the security group.
        :param kwargs: VpcId/TagSpecifications/DryRun
        :return: create_security_grp
        """
        create_security_group = self.client.create_security_group(Description=description, GroupName=grp_name, **kwargs)
        return create_security_group

    def create_validate_security_group(self, description: str, grp_name: str, **kwargs):
        """
        Method to create and validate a security group
        :param description: Description for the security group
        :param grp_name: Name of the security group.
        :param kwargs: VpcId/TagSpecifications/DryRun
        :return: security group ID
        """
        logging.info(f"Creating security group")
        create_security_group = self.create_security_group(description, grp_name, **kwargs)
        assert create_security_group['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Error in creating security group. Output {create_security_group}"
        )
        grp_info = self.get_validate_security_group(GroupIds=[create_security_group['GroupId']])
        assert grp_info['SecurityGroups'][0]['GroupName'] == grp_name, (
            f"Error in getting security group info. {grp_info}"
        )
        logging.info(Fore.GREEN + f"Security group created successfully. Group Id: {create_security_group['GroupId']}"
                     + Style.RESET_ALL)
        return create_security_group['GroupId']

    def get_security_group(self, **kwargs):
        """
        Method to get information of security group
        :param kwargs: Filters/GroupIds/GroupNames/DryRun/NextToken/MaxResults
        :return: security group information
        """
        sec_grp_info = self.client.describe_security_groups(**kwargs)
        return sec_grp_info

    def get_validate_security_group(self, **kwargs):
        """
        Method to get information of security group
        :param kwargs: Filters/GroupIds/GroupNames/DryRun/NextToken/MaxResults
        :return: security group information
        """
        sec_grp_info = self.get_security_group(**kwargs)
        assert sec_grp_info['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Error in getting security group information. Output {sec_grp_info}"
        )
        return sec_grp_info

    def delete_security_group(self, group_id: str = "", group_name: str = "", **kwargs):
        """
        Method to delete a security group
        :param group_name: Security group name
        :param group_id: Security group id.
        :param kwargs:DryRun
        :return: delete_group/None
        """
        try:
            if group_id:
                delete_group = self.client.delete_security_group(GroupId=group_id, **kwargs)
            elif group_name:
                delete_group = self.client.delete_security_group(GroupName=group_name, **kwargs)
            else:
                raise ValueError("Either provide security group ID or Name")
            return delete_group
        except ClientError as err:
            if err.response['Error']['Code'] == "InvalidGroup.InUse":
                logging.info("Security group is associated with an instance or referenced by another security group")
            else:
                logging.info(f"Security group delete failed with error: {err.response['Error']['Code']}")

    def delete_validate_security_group(self, group_id: str = "", group_name: str = "", **kwargs):
        """
        Method to delete and validate a security group
        :param group_name: Security group name
        :param group_id: Security group id.
        :param kwargs:DryRun
        """
        grp_exist = True
        grp_info = None
        delete_sec_grp = self.delete_security_group(group_id, group_name, **kwargs)
        assert delete_sec_grp, f"Error in security group delete"
        assert delete_sec_grp['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Error in deleting security group. Output {delete_sec_grp}"
        )
        try:
            if group_id:
                grp_info = self.get_validate_security_group(GroupIds=[group_id])
            elif group_name:
                grp_info = self.get_validate_security_group(GroupNames=[group_name])
            else:
                raise ValueError("Either provide security group ID or Name")
        except ClientError as err:
            if err.response['Error']['Code'] == "InvalidGroup.NotFound":
                grp_exist = False

        assert not grp_exist, f"Got security group info. {grp_info}"
        logging.info(Fore.GREEN + f"Security group deleted successfully." + Style.RESET_ALL)
        if self.command_line:
            if group_id:
                return f"Security group with id - {group_id} deleted successfully."
            elif group_name:
                return f"Security group with name - {group_name} deleted successfully."

    def authorize_security_group_ingress(self, group_id: str, ip_permissions: list, **kwargs):
        """
        Method to authorize security group ingress(inbound)
        :param group_id: Security group id.
        :param ip_permissions: List of ip permissions for security group.
        :param kwargs:
        :return: authorize security group ingress
        """
        authorize_security_group_ingress = self.client.authorize_security_group_ingress(GroupId=group_id,
                                                                                        IpPermissions=ip_permissions,
                                                                                        **kwargs)
        return authorize_security_group_ingress

    def authorize_validate_security_group_ingress(self, group_id: str, ip_protocol: str, from_port: int,
                                                  to_port: int, cidr_ip: str, description: str = "", **kwargs):
        """
        Method to authorize and validate a security group ingress(inbound)
        :param group_id: Security group id.
        :param ip_protocol: IP protocol name (tcp , udp , icmp , icmpv6 ).
        :param from_port: The start of port range for the TCP and UDP protocols, or an ICMP/ICMPv6 type number.
        :param to_port: The end of port range for the TCP and UDP protocols, or an ICMP/ICMPv6 code.
        :param cidr_ip: IPv4 CIDR range.
        :param description: A description for the security group rule that references this IPv4 address range.
        :param kwargs:
        """
        try:
            logging.info(f"Authorize security group ingress")
            ip_permissions_dict = {
                "FromPort": from_port,
                "IpProtocol": ip_protocol,
                "ToPort": to_port,
                "IpRanges": [
                    {
                        "CidrIp": cidr_ip,
                        "Description": description,
                    },
                ]
            }
            ip_permissions = [ip_permissions_dict]
            authorize_security_group_ingress = self.authorize_security_group_ingress(group_id, ip_permissions, **kwargs)
            assert authorize_security_group_ingress['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
                f"Error in authorize security group ingress. Output {authorize_security_group_ingress}"
            )
            logging.info(
                Fore.GREEN + f"Authorized Security group with ingress successfully.\n"
                             f"Group Rule ID : {authorize_security_group_ingress['SecurityGroupRules'][0]['SecurityGroupRuleId']}"
                             f"\tGroup Id: {authorize_security_group_ingress['SecurityGroupRules'][0]['GroupId']}"
                + Style.RESET_ALL)
            return authorize_security_group_ingress
        except ClientError as err:
            if err.response['Error']['Code'] == "InvalidPermission.Duplicate":
                logging.error(Fore.RED + f"Authorize Security group ingress already exists." + Style.RESET_ALL)
            else:
                logging.error(Fore.RED + f"Authorize Security group Error: {err}"
                              + Style.RESET_ALL)

    def revoke_security_group_ingress(self, group_id: str, ip_permissions: list, **kwargs):
        """
        Method to revoke security group ingress(inbound)
        :param group_id: Security group id.
        :param ip_permissions: List of ip permissions for security group.
        :param kwargs:
        :return: revoke security group ingress
        """
        revoke_security_group_ingress = self.client.revoke_security_group_ingress(GroupId=group_id,
                                                                                  IpPermissions=ip_permissions,
                                                                                  **kwargs)
        return revoke_security_group_ingress

    def revoke_validate_security_group_ingress(self, group_id: str, ip_protocol: str, from_port: int,
                                               to_port: int, cidr_ip: str, description: str = "", **kwargs):
        """
        Method to revoke and validate a security group ingress(inbound)
        :param group_id: Security group id.
        :param ip_protocol: IP protocol name (tcp , udp , icmp , icmpv6 ).
        :param from_port: The start of port range for the TCP and UDP protocols, or an ICMP/ICMPv6 type number.
        :param to_port: The end of port range for the TCP and UDP protocols, or an ICMP/ICMPv6 code.
        :param cidr_ip: IPv4 CIDR range.
        :param description: A description for the security group rule that references this IPv4 address range.
        :param kwargs:
        """
        try:
            logging.info(f"Revoke security group ingress")
            ip_permissions_dict = {
                "FromPort": from_port,
                "IpProtocol": ip_protocol,
                "ToPort": to_port,
                "IpRanges": [
                    {
                        "CidrIp": cidr_ip,
                        "Description": description,
                    },
                ]
            }
            ip_permissions = [ip_permissions_dict]
            revoke_security_group_ingress = self.revoke_security_group_ingress(group_id, ip_permissions, **kwargs)
            if revoke_security_group_ingress.get('UnknownIpPermissions'):
                logging.info(Fore.YELLOW + f"Please validate existing Ip Permissions in Security group id: {group_id}"
                                           f" to revoke Security group ingress \n "
                                           f"{revoke_security_group_ingress['UnknownIpPermissions']}" + Style.RESET_ALL)
            else:
                assert revoke_security_group_ingress['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, \
                    (f"Error in revoke security group ingress. Output {revoke_security_group_ingress}")
                logging.info(Fore.GREEN + f"Revoke Security group with ingress successfully.\nGroup Id: {group_id}"
                             + Style.RESET_ALL)
                return revoke_security_group_ingress
        except ClientError as err:
            logging.error(Fore.RED + f"Revoke Security group ingress Error: {err}." + Style.RESET_ALL)

    def authorize_security_group_egress(self, group_id: str, ip_permissions: list, **kwargs):
        """
        Method to authorize security group egress(outbound)
        :param group_id: Security group id.
        :param ip_permissions: List of ip permissions for security group.
        :param kwargs:
        :return: authorize security group egress
        """
        authorize_security_group_egress = self.client.authorize_security_group_egress(GroupId=group_id,
                                                                                      IpPermissions=ip_permissions,
                                                                                      **kwargs)
        return authorize_security_group_egress

    def authorize_validate_security_group_egress(self, group_id: str, ip_protocol: str, from_port: int,
                                                 to_port: int, cidr_ip: str, description: str = "", **kwargs):
        """
        Method to authorize and validate a security group egress(outbound)
        :param group_id: Security group id.
        :param ip_protocol: IP protocol name (tcp , udp , icmp , icmpv6 ).
        :param from_port: The start of port range for the TCP and UDP protocols, or an ICMP/ICMPv6 type number.
        :param to_port: The end of port range for the TCP and UDP protocols, or an ICMP/ICMPv6 code.
        :param cidr_ip: IPv4 CIDR range.
        :param description: A description for the security group rule that references this IPv4 address range.
        :param kwargs:
        """
        try:
            logging.info(f"Authorize security group egress")
            ip_permissions_dict = {
                "FromPort": from_port,
                "IpProtocol": ip_protocol,
                "ToPort": to_port,
                "IpRanges": [
                    {
                        "CidrIp": cidr_ip,
                        "Description": description,
                    },
                ]
            }
            ip_permissions = [ip_permissions_dict]
            authorize_security_group_egress = self.authorize_security_group_egress(group_id, ip_permissions, **kwargs)
            assert authorize_security_group_egress['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
                f"Error in authorize security group ingress. Output {authorize_security_group_egress}"
            )
            logging.info(
                Fore.GREEN + f"Authorize Security group with egress successfully.\n"
                             f"Group Rule ID : {authorize_security_group_egress['SecurityGroupRules'][0]['SecurityGroupRuleId']}"
                             f"\tGroup Id: {authorize_security_group_egress['SecurityGroupRules'][0]['GroupId']}"
                + Style.RESET_ALL)
            return authorize_security_group_egress
        except ClientError as err:
            if err.response['Error']['Code'] == "InvalidPermission.Duplicate":
                logging.error(Fore.RED + f"Authorize Security group egress already exists." + Style.RESET_ALL)
            else:
                logging.error(Fore.RED + f"Authorize Security group Error: {err}"
                              + Style.RESET_ALL)

    def revoke_security_group_egress(self, group_id: str, ip_permissions: list, **kwargs):
        """
        Method to revoke security group egress(outbound)
        :param group_id: Security group id.
        :param ip_permissions: List of ip permissions for security group.
        :param kwargs:
        :return: revoke security group egress
        """
        revoke_security_group_egress = self.client.revoke_security_group_egress(GroupId=group_id,
                                                                                IpPermissions=ip_permissions, **kwargs)
        return revoke_security_group_egress

    def revoke_validate_security_group_egress(self, group_id: str, ip_protocol: str, from_port: int,
                                              to_port: int, cidr_ip: str, description: str = "", **kwargs):
        """
        Method to revoke and validate a security group egress(outbound)
        :param group_id: Security group id.
        :param ip_protocol: IP protocol name (tcp , udp , icmp , icmpv6 ).
        :param from_port: The start of port range for the TCP and UDP protocols, or an ICMP/ICMPv6 type number.
        :param to_port: The end of port range for the TCP and UDP protocols, or an ICMP/ICMPv6 code.
        :param cidr_ip: IPv4 CIDR range.
        :param description: A description for the security group rule that references this IPv4 address range.
        :param kwargs:
        """
        try:
            logging.info(f"Revoke security group egress")
            ip_permissions_dict = {
                "FromPort": from_port,
                "IpProtocol": ip_protocol,
                "ToPort": to_port,
                "IpRanges": [
                    {
                        "CidrIp": cidr_ip,
                        "Description": description,
                    },
                ]
            }
            ip_permissions = [ip_permissions_dict]
            revoke_security_group_egress = self.revoke_security_group_egress(group_id, ip_permissions, **kwargs)
            if revoke_security_group_egress.get('UnknownIpPermissions'):
                logging.info(Fore.YELLOW + f"Please validate existing Ip Permissions in Security group id: {group_id}"
                                           f" to revoke Security group egress \n "
                                           f"{revoke_security_group_egress['UnknownIpPermissions']}" + Style.RESET_ALL)
            else:
                assert revoke_security_group_egress['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, \
                    (f"Error in revoke security group egress. Output {revoke_security_group_egress}")
                logging.info(Fore.GREEN + f"Revoke Security group with egress successfully.\nGroup Id: {group_id}"
                             + Style.RESET_ALL)
            return revoke_security_group_egress
        except ClientError as err:
            logging.error(Fore.RED + f"Revoke Security group egress Error: {err}." + Style.RESET_ALL)

    def describe_validate_security_group(self, group_id: str = "", group_name: str = "", filter_group_name: str = "",
                                         filter_group_id: str = "", **kwargs):
        """
        Method to describe and validate security group
        :param group_name: Security group name
        :param group_id: Security group id.
        :param filter_group_name: Filter security group id.
        :param filter_group_id: Filter security group id.
        :param kwargs:DryRun
        """
        filter_input = []
        list_all = False

        def print_desc(desc, multi=False):
            row = []
            if multi:
                count = 1
                for new in desc:
                    print(f"{count}.")
                    for k, v in new.items():
                        print(f"\t{k}  :  {v}")
                    count += 1
            else:
                desc_data = [(colm, data) for colm, data in desc.items()]
                row = [[row_data[1] for row_data in desc_data]]
                table = PrettyTable([col_data[0] for col_data in desc_data])
                for row_data in row:
                    table.add_row(row_data)
                print(table)

        try:
            if group_id:
                desc_sec_grp = self.get_validate_security_group(GroupIds=[group_id])
            elif group_name:
                desc_sec_grp = self.get_validate_security_group(GroupNames=[group_name])
            else:
                if filter_group_name:
                    filter_input.append({'Name': 'group-name', 'Values': [filter_group_name]})
                if filter_group_id:
                    filter_input.append({'Name': 'group-id', 'Values': [filter_group_id]})
                if filter_input:
                    desc_sec_grp = self.get_validate_security_group(Filters=filter_input)
                else:
                    list_all = True
                    desc_sec_grp = self.get_validate_security_group()
                    response = desc_sec_grp['SecurityGroups']
                    table = PrettyTable(["Group id", "Group name", "Vpc id"])
                    for res in response:
                        table.add_row([res["GroupName"], res["GroupId"], res["VpcId"]])
                    print(Fore.GREEN + f"Describe Security Group successfully -" + Style.RESET_ALL)
                    print(table)

            assert desc_sec_grp, f"Error in security group describe"
            assert desc_sec_grp['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
                f"Error in describe security group. Output {desc_sec_grp}"
            )
            if not list_all:
                for desc in desc_sec_grp['SecurityGroups']:
                    if "IpPermissions" in desc.keys():
                        IpPermissions_data = desc["IpPermissions"]
                        del desc["IpPermissions"]
                    if "IpPermissionsEgress" in desc.keys():
                        IpPermissionsEgress_data = desc["IpPermissionsEgress"]
                        del desc["IpPermissionsEgress"]
                    print(Fore.GREEN + f"Describe Security Group successfully -" + Style.RESET_ALL)
                    print_desc(desc)
                    if IpPermissions_data:
                        print(Fore.GREEN + "Security Group ingress (Inbound rules) -" + Style.RESET_ALL)
                        print_desc(IpPermissions_data, True)
                    else:
                        print(
                            Fore.YELLOW + "No rules found for Security Group ingress (Inbound rules)" + Style.RESET_ALL)
                    if IpPermissionsEgress_data:
                        print(Fore.GREEN + "Security Group egress (Outbound rules) -" + Style.RESET_ALL)
                        print_desc(IpPermissionsEgress_data, True)
                    else:
                        print(
                            Fore.YELLOW + "No rules found for Security Group egress (Outbound rules)" + Style.RESET_ALL)
            if not desc_sec_grp['SecurityGroups']:
                print(
                    Fore.YELLOW + "Fetch empty result for security group (group_name or group_id or vpc_id) " + Style.RESET_ALL)
        except ClientError as err:
            if err.response['Error']['Code'] == "InvalidGroup.NotFound":
                logging.error(Fore.RED + f" InvalidGroup in Describe security group: {err}." + Style.RESET_ALL)
            elif err.response['Error']['Code'] == "InvalidGroupId.Malformed":
                logging.error(Fore.RED + f" InvalidGroup in Describe security group: {err}." + Style.RESET_ALL)

    def update_instance(self, instance_id: str, **kwargs):
        """
        Method to update attributes of an instance
        :param instance_id: Instance ID
        :param kwargs: SourceDestCheck/Attribute/BlockDeviceMappings/DisableApiTermination/DryRun/EbsOptimized/
        EnaSupport/Groups/InstanceInitiatedShutdownBehavior/InstanceType/Kernel/Ramdisk/SriovNetSupport/UserData/Value
        :retrun: modify_instance
        """
        if not kwargs:
            raise ValueError("Please provide one attribute which need to be updated")
        modify_instance = self.client.modify_instance_attribute(InstanceId=instance_id, **kwargs)
        return modify_instance

    def update_validate_instance(self, instance_id: str, **kwargs):
        """
        Method to update and validate attributes of an instance
        :param instance_id: Instance ID
        :param kwargs: SourceDestCheck/Attribute/BlockDeviceMappings/DisableApiTermination/DryRun/EbsOptimized/
        EnaSupport/Groups/InstanceInitiatedShutdownBehavior/InstanceType/Kernel/Ramdisk/SriovNetSupport/UserData/Value
        """
        modify_instance = self.update_instance(instance_id, **kwargs)
        assert modify_instance['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Error in updating security group. Output {modify_instance}"
        )
        logging.info(f"Instance updated successfully for attribute: {kwargs}")

    def attach_role_ec2_instance_validate(self, instance_id: str, role_name: str, instance_profile_arn: str):
        """
        Method to attach a role to an ec2 instance and validate its API response.
        :param instance_id: Ec2 instance_id.
        :param role_name: Existing role name.
        :param instance_profile_arn: instance profile Amazon resource number
        """
        attach_role_response = self.attach_role_ec2_instance(instance_id, role_name)
        assert attach_role_response, f"failed to attach role '{role_name}' to ec2 instance id '{instance_id}'"
        assert attach_role_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected: '{RESPONSE_OK}' but found "
            f"'{attach_role_response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        instance_response = self.get_validate_instance(
            InstanceIds=[instance_id])['Reservations'][0]['Instances'][0]['IamInstanceProfile']['Arn']
        assert instance_response == instance_profile_arn, (
            f"failed to attach role '{role_name}' to ec2 instance id '{instance_id}'")
        logging.info(Fore.GREEN + f"Role '{role_name}' attached to EC2 instance with id '{instance_id}' successfully" +
                     Style.RESET_ALL)
        return attach_role_response

    def attach_role_ec2_instance(self, instance_id: str, role_name: str):
        """
        Method to attach a role to an ec2 instance
        :param instance_id: Ec2 instance_id.
        :param role_name: Existing role name.
        :return: attach_role_response
        """

        try:
            attach_role_response = self.client.associate_iam_instance_profile(
                IamInstanceProfile={'Name': role_name}, InstanceId=instance_id
            )
            return attach_role_response
        except ClientError as err:
            if err.response['Error']['Code'] == "IncorrectState":
                print(Fore.RED)
                logging.info(f"Failed to attach role '{role_name}' to instance")
            elif err.response['Error']['Code'] == "InvalidInstanceID.Malformed":
                logging.info(f"Failed to attach role '{role_name}, due to incorrect {instance_id}")
            else:
                logging.info(f"Attach role to an instance failed, listing with err: '{err.response['Error']['Code']}'")
                logging.error(err)
                print(Style.RESET_ALL)

    def create_vpc(self, cidr_block: str, **kwargs):
        """
        Method to create VPC.
        :param cidr_block: Cidr block
        :param kwargs: AmazonProvidedIpv6CidrBlock/Ipv6Pool/Ipv6CidrBlock/DryRun/InstanceTenancy/
        Ipv6CidrBlockNetworkBorderGroup/TagSpecifications
        :return: create_vpc_response
        """
        try:
            create_vpc_response = self.client.create_vpc(CidrBlock=cidr_block, **kwargs)
            return create_vpc_response
        except ClientError as err:
            print(Fore.RED)
            logging.info(
                f"VPC creation for cidr block '{cidr_block}' failed, "
                f"listing with err: {err.response['Error']['Code']}"
            )
            logging.error(err)
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def create_vpc_validate(self, cidr_block: str, **kwargs):
        """
        Method to validate create vpc response.
        :param cidr_block: Cidr block
        :param kwargs: AmazonProvidedIpv6CidrBlock/Ipv6Pool/Ipv6CidrBlock/DryRun/InstanceTenancy/
        Ipv6CidrBlockNetworkBorderGroup/TagSpecifications
        :return: create_vpc_response
        """
        create_vpc_response = self.create_vpc(cidr_block, **kwargs)
        assert create_vpc_response, f"failed to create vpc with cidr'{cidr_block}'."
        assert create_vpc_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected:'{RESPONSE_OK}' but, found"
            f"'{create_vpc_response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        vpc_list = [vpc['VpcId'] for vpc in self.list_vpc_validate()['Vpcs']]
        assert create_vpc_response['Vpc']['VpcId'] in vpc_list, f"failed to create vpc with cidr '{cidr_block}'"
        logging.info(
            Fore.GREEN + f"VPC '{create_vpc_response['Vpc']['VpcId']}' created successfully'" + Style.RESET_ALL)
        return create_vpc_response

    def list_vpc(self, cons_log=False, **kwargs):
        """
        Method to list all vpc
        :param kwargs: Filters/VpcIds/DryRun/NextToken/MaxResults
        :return: list_vpc_response
        """
        try:
            list_vpc_response = self.client.describe_vpcs(**kwargs)
            if cons_log:
                mytable = PrettyTable(["CidrBlock", "DhcpOptionsId", "State", "VpcId", "OwnerId", "InstanceTenancy"])
                for vpc in list_vpc_response['Vpcs']:
                    mytable.add_row([vpc["CidrBlock"], vpc["DhcpOptionsId"], vpc["State"], vpc["VpcId"], vpc["OwnerId"],
                                     vpc["InstanceTenancy"]])
                mytable.hrules = 1
                print("\n".join(mytable.get_string().splitlines()))
            return list_vpc_response
        except ClientError as err:
            logging.info(
                f"failed to get vpcs, listing with err: {err.response['Error']['Code']}"
            )
            logging.error(err)

    def list_vpc_validate(self, **kwargs):
        """
        Method to validate list vpc response.
        :param kwargs: Filters/VpcIds/DryRun/NextToken/MaxResults.
        :return: list_vpc_response
        """
        list_vpc_response = self.list_vpc(**kwargs)
        assert list_vpc_response, "failed to list vpc metadata."
        assert list_vpc_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected:'{RESPONSE_OK}' but, found"
            f"'{list_vpc_response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        if not self.command_line:
            logging.info(list_vpc_response)
        return list_vpc_response

    def create_vpc_endpoint(self, vpc_id: str, service_name: str, **kwargs):
        """
        Method to create vpc end point
        :param vpc_id: VPC id.
        :param service_name: AWS service name
        :param kwargs: DryRun/VpcEndpointType/PolicyDocument/RouteTableIds/SubnetIds/SecurityGroupIds/ClientToken/
        PrivateDnsEnabled/TagSpecifications
        :return: create_vpc_endpoint_response.
        """
        try:
            create_vpc_endpoint_response = self.client.create_vpc_endpoint(
                VpcId=vpc_id, ServiceName=service_name, **kwargs
            )
            return create_vpc_endpoint_response
        except ClientError as err:
            print(Fore.RED)
            logging.info(
                f"vpc creation with endpoint failed, listing with err: {err.response['Error']['Code']}"
            )
            logging.error(err)
            print(Style.RESET_ALL)

    def create_vpc_endpoint_validate(self, vpc_id: str, service_name: str, **kwargs):
        """
        Method to create and validate vpc endpoint.
        :param vpc_id: VPC id.
        :param service_name: AWS service name
        :param kwargs: DryRun/VpcEndpointType/PolicyDocument/RouteTableIds/SubnetIds/SecurityGroupIds/ClientToken/
        PrivateDnsEnabled/TagSpecifications.
        :return: create_vpc_endpoint_response.
        """
        create_vpc_endpoint_response = self.create_vpc_endpoint(vpc_id, service_name, **kwargs)
        assert create_vpc_endpoint_response, (
            f"failed to create vpc endpoint with vpc_id '{vpc_id}' and service name '{service_name}'."
        )
        assert create_vpc_endpoint_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected:'{RESPONSE_OK}' but, found"
            f"'{create_vpc_endpoint_response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        list_vpc_endpoints = [
            vpc_endpoints['VpcEndpointId'] for vpc_endpoints in self.list_vpc_endpoints()['VpcEndpoints']]
        assert create_vpc_endpoint_response['VpcEndpoint']['VpcEndpointId'] in list_vpc_endpoints, (
            f"failed to create vpc endpoint with vpc_id '{vpc_id}' and service name '{service_name}'."
        )
        logging.info(Fore.GREEN +
                     f"VPC end point '{create_vpc_endpoint_response['VpcEndpoint']['VpcEndpointId']}' created successfully'"
                     + Style.RESET_ALL)
        return create_vpc_endpoint_response

    def list_vpc_endpoints(self, **kwargs):
        """
        Method to list all vpc endpoints.
        :param kwargs: DryRun/VpcEndpointIds/Filters/MaxResults/NextToken.
        :return: list_vpc_endpoint_response
        """
        try:
            list_vpc_endpoints_response = self.client.describe_vpc_endpoints(**kwargs)
            return list_vpc_endpoints_response
        except ClientError as err:
            logging.info(
                f"failed to get vpc endpoints, listing with err: {err.response['Error']['Code']}"
            )
            logging.error(err)

    def list_vpc_endpoints_validate(self, **kwargs):
        """
        Method to validate list all vpc endpoint response.
        :param kwargs: DryRun/VpcEndpointIds/Filters/MaxResults/NextToken.
        :return: list_vpc_endpoint_response.
        """
        list_vpc_endpoint_response = self.list_vpc_endpoints(**kwargs)
        assert list_vpc_endpoint_response, "failed to list vpc endpoints and metadata."
        assert list_vpc_endpoint_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected:'{RESPONSE_OK}' but, found"
            f"'{list_vpc_endpoint_response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        print(list_vpc_endpoint_response)
        return list_vpc_endpoint_response

    def delete_vpc_endpoint(self, vpc_endpoint_ids: list, **kwargs):
        """
        Method to delete VPC endpoints.
        :param kwargs: DryRun
        :param vpc_endpoint_ids: VPC endpoint ID.
        :return: delete_vpc_endpoint_response
        """
        try:
            delete_vpc_endpoint_response = self.client.delete_vpc_endpoints(
                VpcEndpointIds=vpc_endpoint_ids, **kwargs
            )
            return delete_vpc_endpoint_response
        except ClientError as err:
            print(Fore.RED)
            logging.info(
                f"failed to delete vpc endpoint '{vpc_endpoint_ids}', listing with err: {err.response['Error']['Code']}"
            )
            logging.error(err)
            print(Style.RESET_ALL)

    def delete_vpc_endpoint_validate(self, vpc_endpoint_ids: list, **kwargs):
        """
        Method to validate delete VPC endpoints response.
        :param kwargs: DryRun
        :param vpc_endpoint_ids: VPC endpoint ID.
        """
        delete_vpc_endpoint_response = self.delete_vpc_endpoint(vpc_endpoint_ids, **kwargs)
        assert delete_vpc_endpoint_response, (
            f"failed to delete vpc endpoint '{vpc_endpoint_ids}'."
        )
        assert delete_vpc_endpoint_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected:'{RESPONSE_OK}' but, found"
            f"'{delete_vpc_endpoint_response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        list_vpc_endpoints = [vpc_endpoints for vpc_endpoints in self.list_vpc_endpoints()['VpcEndpoints']]
        for end_points in vpc_endpoint_ids:
            assert end_points not in list_vpc_endpoints, (
                f"failed to delete vpc endpoint with vpc end point id '{vpc_endpoint_ids}"
            )
        logging.info(Fore.GREEN + f"VPC Endpoint- {vpc_endpoint_ids} Deleted Successfully" + Style.RESET_ALL)
        if self.command_line:
            return f"VPC Endpoint- {vpc_endpoint_ids} Deleted Successfully"

    def delete_vpc(self, vpc_id: str, **kwargs):
        """
        Method to delete vpc.
        :param vpc_id: VPC Id.
        :kwargs: DryRun.
        :return: Delete_vpc_response.
        """
        try:
            delete_vpc_response = self.client.delete_vpc(VpcId=vpc_id, **kwargs)
            return delete_vpc_response
        except ClientError as err:
            print(Fore.RED)
            logging.info(
                f"failed to delete vpc '{vpc_id}', listing with err: {err.response['Error']['Code']}"
            )
            logging.error(err)
            print(Style.RESET_ALL)

    def delete_vpc_validate(self, vpc_id: str, **kwargs):
        """
        Method to validate delete vpc response.
        :param vpc_id: VPC Id.
        :kwargs: DryRun
        """
        delete_vpc_response = self.delete_vpc(vpc_id, **kwargs)
        assert delete_vpc_response, f"failed to delete vpc '{vpc_id}'."
        assert delete_vpc_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected:'{RESPONSE_OK}' but, found"
            f"'{delete_vpc_response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        vpc_list = [vpc['VpcId'] for vpc in self.list_vpc_validate()['Vpcs']]
        assert vpc_id not in vpc_list, f"failed to delete vpc '{vpc_id}'"
        logging.info(Fore.GREEN + f"VPC '{vpc_id}' deleted successfully'" + Style.RESET_ALL)
        if self.command_line:
            return f"VPC '{vpc_id}' deleted successfully'"

    def create_elastic_ip(self, **kwargs):
        """
        Method to create elastic ip
        :param kwargs: Domain/Address/PublicIpv4Pool/NetworkBorderGroup/CustomerOwnedIpv4Pool/DryRun
        :return: create_elastic_ip_response.
        """
        try:
            create_elastic_ip_response = self.client.allocate_address(**kwargs)
            return create_elastic_ip_response
        except ClientError as err:
            print(Fore.RED)
            logging.info(
                f"failed to allocate elastic ip, listing with err: {err.response['Error']['Code']}"
            )
            logging.error(err)
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def create_elastic_ip_validate(self, **kwargs):
        """
        Method to validate create elastic ip response.
        :param kwargs: Domain/Address/PublicIpv4Pool/NetworkBorderGroup/CustomerOwnedIpv4Pool/DryRun
        :return: create_elastic_ip_response.
        """
        create_elastic_ip_response = self.create_elastic_ip(**kwargs)
        assert create_elastic_ip_response, f"failed to allocate elastic ip'."
        assert create_elastic_ip_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected:'{RESPONSE_OK}' but, found"
            f"'{create_elastic_ip_response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        allocation_id_list = [address['AllocationId'] for address in self.list_elastic_ip_validate()['Addresses']]
        assert create_elastic_ip_response['AllocationId'] in allocation_id_list, (
            f"failed to create elastic ip '{allocation_id_list}'"
        )
        logging.info(Fore.GREEN +
                     f"elastic ip address having allocation_id "
                     f"'{create_elastic_ip_response['AllocationId']}', allocated successfully."
                     + Style.RESET_ALL)
        return create_elastic_ip_response

    def list_elastic_ip(self, **kwargs):
        """
        Method to list elastic ip.
        :param kwargs: Filters/PublicIps/AllocationIds/DryRun.
        :return: list_elastic_ip_response.
        """
        try:
            list_elastic_ip_response = self.client.describe_addresses(**kwargs)
            return list_elastic_ip_response
        except ClientError as err:
            logging.info(
                f"failed to get elastic ip list, listing with err: {err.response['Error']['Code']}"
            )
            logging.error(err)

    def list_elastic_ip_validate(self, **kwargs):
        """
        Method to validate list elastic ip response.
        :param kwargs: Filters/PublicIps/AllocationIds/DryRun.
        :return: list_elastic_ip_response.
        """
        list_elastic_ip_response = self.list_elastic_ip(**kwargs)
        assert list_elastic_ip_response, f"failed to get elastic ip list response."
        assert list_elastic_ip_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected:'{RESPONSE_OK}' but, found"
            f"'{list_elastic_ip_response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        return list_elastic_ip_response

    def release_elastic_ip(self, allocation_id: str, **kwargs):
        """
        Method to release the allocated ip address.
        :param allocation_id: allocation id.
        :param kwargs: PublicIp/NetworkBorderGroup/DryRun.
        :return: release_elastic_ip_response
        """
        try:
            release_elastic_ip_response = self.client.release_address(AllocationId=allocation_id, **kwargs)
            return release_elastic_ip_response
        except ClientError as err:
            print(Fore.RED)
            logging.info(
                f"failed to release elastic ip with allocation id '{allocation_id}',"
                f"listing with err: {err.response['Error']['Code']}"
            )
            logging.error(err)
            print(Style.RESET_ALL)

    def release_elastic_ip_validate(self, allocation_id: str, **kwargs):
        """
        Method to validate the release elastic ip response.
        :param allocation_id: allocation id.
        :param kwargs: PublicIp/NetworkBorderGroup/DryRun.
        """
        release_elastic_ip_response = self.release_elastic_ip(allocation_id, **kwargs)
        assert release_elastic_ip_response, f"failed to release elastic ip having allocation id'{allocation_id}'."
        assert release_elastic_ip_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected:'{RESPONSE_OK}' but, found"
            f"'{release_elastic_ip_response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        allocation_id_list = [address['AllocationId'] for address in self.list_elastic_ip_validate()['Addresses']]
        assert allocation_id not in allocation_id_list, (
            f"failed to release elastic_ip having allocation_id '{allocation_id}'."
        )
        logging.info(
            Fore.GREEN + f"elastic ip having allocation id '{allocation_id}' released successfully." + Style.RESET_ALL)
        if self.command_line:
            return f"elastic ip having allocation id '{allocation_id}' released successfully."

    def create_internet_gateway(self, **kwargs):
        """
        Method to create internet gateway.
        :kwargs: TagSpecifications/DryRun.
        return: create_internet_gateway_response.
        """
        try:
            create_internet_gateway_response = self.client.create_internet_gateway(**kwargs)
            return create_internet_gateway_response
        except ClientError as err:
            logging.info(
                f"failed to create internet gateway, listing with err: {err.response['Error']['Code']}"
            )
            logging.error(err)

    def create_internet_gateway_validate(self, **kwargs):
        """
        Method to validate create internet gateway response.
        :kwargs: TagSpecifications/DryRun.
        return: create_internet_gateway_response.
        """
        create_internet_gateway_response = self.create_internet_gateway(**kwargs)
        assert create_internet_gateway_response, "failed to create internet gateway."
        assert create_internet_gateway_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected:'{RESPONSE_OK}' but, found"
            f"'{create_internet_gateway_response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        internet_gateway_list = [
            internet_gateway_id['InternetGatewayId'] for internet_gateway_id in self.list_internet_gateway_validate(
            )['InternetGateways']]
        assert create_internet_gateway_response['InternetGateway']['InternetGatewayId'] in internet_gateway_list, (
            "failed to create internet gateway"
        )
        logging.info(
            f"Internet gateway '{create_internet_gateway_response['InternetGateway']['InternetGatewayId']}',"
            f"created successfully."
        )
        return create_internet_gateway_response

    def list_internet_gateway(self, **kwargs):
        """
        Method to get internet gateways.
        :param kwargs: Filters/DryRun/InternetGatewayIds/NextToken/MaxResults
        :return: list_internet_gateway_response
        """
        try:
            list_internet_gateway_response = self.client.describe_internet_gateways(**kwargs)
            return list_internet_gateway_response
        except ClientError as err:
            logging.info(
                f"failed to get internet gateway data, listing with err: {err.response['Error']['Code']}"
            )
            logging.error(err)

    def list_internet_gateway_validate(self, **kwargs):
        """
        Method to validate get internet gateways response.
        :param kwargs: Filters/DryRun/InternetGatewayIds/NextToken/MaxResults
        :return: list_internet_gateway_response
        """
        list_internet_gateway_response = self.list_internet_gateway(**kwargs)
        assert list_internet_gateway_response, "failed to get internet gateway data."
        assert list_internet_gateway_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected:'{RESPONSE_OK}' but, found"
            f"'{list_internet_gateway_response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        return list_internet_gateway_response

    def attach_internet_gateway(self, internet_gateway_id: str, vpc_id: str, **kwargs):
        """
        Method to attach internet gateway to vpc.
        :param internet_gateway_id: internet gateway id.
        :param vpc_id: vpc id.
        :kwargs :DryRun.
        :return :attach_internet_gateway_response.
        """
        try:
            attach_internet_gateway_response = self.client.attach_internet_gateway(
                InternetGatewayId=internet_gateway_id,
                VpcId=vpc_id,
                **kwargs
            )
            return attach_internet_gateway_response
        except ClientError as err:
            logging.info(
                f"failed to attach internet gateway '{internet_gateway_id}' to vpc '{vpc_id}',"
                f" listing with err: {err.response['Error']['Code']}"
            )
            logging.error(err)

    def attach_internet_gateway_validate(self, internet_gateway_id: str, vpc_id: str, **kwargs):
        """
        Method to validate attach internet gateway response.
        :param internet_gateway_id: internet gateway id
        :param vpc_id: vpc id
        :kwargs :DryRun
        """
        attach_internet_gateway_response = self.attach_internet_gateway(internet_gateway_id, vpc_id, **kwargs)
        assert attach_internet_gateway_response, (
            f"failed to attach internet gateway '{internet_gateway_id}' to vpc '{vpc_id}'."
        )
        assert attach_internet_gateway_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected:'{RESPONSE_OK}' but, found"
            f"'{attach_internet_gateway_response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        list_internet_gateway_validate_response = self.list_internet_gateway_validate(
            InternetGatewayIds=[internet_gateway_id]
        )
        vpc_id_list = [attachments['VpcId']
                       for attachments in list_internet_gateway_validate_response['InternetGateways'][0]['Attachments']]
        assert vpc_id in vpc_id_list, (
            f"failed to attach internet gateway '{internet_gateway_id}' to vpc '{vpc_id}'."
        )
        logging.info(f"Internet gateway '{internet_gateway_id}' attached to vpc '{vpc_id}' successfully")

    def detach_internet_gateway(self, internet_gateway_id: str, vpc_id: str, **kwargs):
        """
        Method to detach internet gateway
        :param internet_gateway_id: internet gateway id.
        :param vpc_id: VPC id.
        :param kwargs: DryRun
        :return: detach_internet_gateway_response.
        """
        try:
            detach_internet_gateway_response = self.client.detach_internet_gateway(
                InternetGatewayId=internet_gateway_id,
                VpcId=vpc_id,
                **kwargs
            )
            return detach_internet_gateway_response
        except ClientError as err:
            logging.info(
                f"failed to detach internet gateway '{internet_gateway_id}' from vpc '{vpc_id}',"
                f" listing with err: {err.response['Error']['Code']}"
            )
            logging.error(err)

    def detach_internet_gateway_validate(self, internet_gateway_id: str, vpc_id: str, **kwargs):
        """
        Method to validate detach internet gateway response.
        :param internet_gateway_id: internet gateway id.
        :param vpc_id: VPC id.
        :param kwargs: DryRun
        """
        detach_internet_gateway_response = self.detach_internet_gateway(internet_gateway_id, vpc_id, **kwargs)
        assert detach_internet_gateway_response, (
            f"failed to detach internet gateway '{internet_gateway_id}' from vpc '{vpc_id}'."
        )
        assert detach_internet_gateway_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected:'{RESPONSE_OK}' but, found"
            f"'{detach_internet_gateway_response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        list_internet_gateway_validate_response = self.list_internet_gateway_validate(
            InternetGatewayIds=[internet_gateway_id]
        )
        vpc_id_list = [attachments['VpcId']
                       for attachments in list_internet_gateway_validate_response['InternetGateways'][0]['Attachments']]
        assert vpc_id not in vpc_id_list, (
            f"failed to detach internet gateway '{internet_gateway_id}' to vpc '{vpc_id}'."
        )
        logging.info(f"Internet gateway '{internet_gateway_id}' detached successfully")

    def delete_internet_gateway(self, internet_gateway_id: str, **kwargs):
        """
        Method to delete internet gateway.
        :param internet_gateway_id: internet gateway id.
        :param kwargs: DryRun.
        :return:  delete_internet_gateway_response.
        """
        try:
            delete_internet_gateway_response = self.client.delete_internet_gateway(
                InternetGatewayId=internet_gateway_id,
                **kwargs
            )
            return delete_internet_gateway_response
        except ClientError as err:
            logging.info(
                f"failed to delete internet gateway '{internet_gateway_id}',"
                f" listing with err: {err.response['Error']['Code']}"
            )
            logging.error(err)

    def delete_internet_gateway_validate(self, internet_gateway_id: str, **kwargs):
        """
        Method to delete internet gateway.
        :param internet_gateway_id: internet gateway id.
        :param kwargs: DryRun.
        """
        delete_internet_gateway_response = self.delete_internet_gateway(internet_gateway_id, **kwargs)
        assert delete_internet_gateway_response, (
            f"failed to delete internet gateway '{internet_gateway_id}'."
        )
        assert delete_internet_gateway_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected:'{RESPONSE_OK}' but, found"
            f"'{delete_internet_gateway_response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        internet_gateway_list = [
            internet_gateway_id['InternetGatewayId'] for internet_gateway_id in self.list_internet_gateway_validate(
            )['InternetGateways']]
        assert internet_gateway_id not in internet_gateway_list, (
            f"failed to delete internet gateway '{internet_gateway_id}'."
        )
        logging.info(f"Internet gateway '{internet_gateway_id}' deleted successfully.")

    def create_subnet(self, cidr_block: str, vpc_id: str, **kwargs):
        """
        Method to create subnet.
        :param cidr_block: CIDR block.
        :param vpc_id: VPC id.
        :param kwargs: TagSpecifications/AvailabilityZone/AvailabilityZoneId/Ipv6CidrBlock/OutpostArn/DryRun.
        :return: create_subnet_response
        """
        try:
            create_subnet_response = self.client.create_subnet(
                CidrBlock=cidr_block,
                VpcId=vpc_id,
                **kwargs
            )
            return create_subnet_response
        except ClientError as err:
            print(Fore.RED)
            logging.info(
                f"failed to create subnet with cidr '{cidr_block}',"
                f" listing with err: {err.response['Error']['Code']}"
            )
            logging.error(err)
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def create_subnet_validate(self, cidr_block: str, vpc_id: str, **kwargs):
        """
        Method to create subnet.
        :param cidr_block: CIDR block.
        :param vpc_id: VPC id.
        :param kwargs: TagSpecifications/AvailabilityZone/AvailabilityZoneId/Ipv6CidrBlock/OutpostArn/DryRun.
        :return: create_subnet_response.
        """
        create_subnet_response = self.create_subnet(cidr_block, vpc_id, **kwargs)
        assert create_subnet_response, (
            f"failed to create subnet with cidr '{cidr_block}'."
        )
        assert create_subnet_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected:'{RESPONSE_OK}' but, found"
            f"'{create_subnet_response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        subnet_id_list = [subnet['SubnetId'] for subnet in self.list_subnets_validate()['Subnets']]
        assert create_subnet_response['Subnet']['SubnetId'] in subnet_id_list, (
            f"failed to create subnet with cidr '{cidr_block}'"
        )
        logging.info(
            Fore.GREEN + f"subnet '{create_subnet_response['Subnet']['SubnetId']}' created successfully." + Style.RESET_ALL)
        return create_subnet_response

    def list_subnets(self, **kwargs):
        """
        Method to get subnets.
        :param kwargs: Filters/SubnetIds/DryRun/NextToken/MaxResults.
        :return: describe_subnets_response
        """
        try:
            describe_subnets_response = self.client.describe_subnets(**kwargs)
            return describe_subnets_response
        except ClientError as err:
            logging.info(
                f"failed to get subnet response, listing with err: {err.response['Error']['Code']}"
            )
            logging.error(err)

    def list_subnets_validate(self, **kwargs):
        """
        Method to validate get subnets response.
        :param kwargs: Filters/SubnetIds/DryRun/NextToken/MaxResults.
        :return: describe_subnets_response
        """
        describe_subnets_response = self.list_subnets(**kwargs)
        assert describe_subnets_response, "failed to get subnet data."
        assert describe_subnets_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected:'{RESPONSE_OK}' but, found"
            f"'{describe_subnets_response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        return describe_subnets_response

    def delete_subnet(self, subnet_id: str, **kwargs):
        """
        Method to delete subnet.
        :param subnet_id: Subnet ID.
        :param kwargs: DryRun
        :return: delete_subnet_response.
        """
        try:
            delete_subnet_response = self.client.delete_subnet(SubnetId=subnet_id, **kwargs)
            return delete_subnet_response
        except ClientError as err:
            print(Fore.RED)
            logging.info(
                f"failed to delete subnet '{subnet_id}', listing with err: {err.response['Error']['Code']}"
            )
            logging.error(err)
            print(Style.RESET_ALL)

    def delete_subnet_validate(self, subnet_id: str, **kwargs):
        """
        Method to validate delete subnet response.
        :param subnet_id: Subnet ID.
        :param kwargs: DryRun.
        """
        delete_subnet_response = self.delete_subnet(subnet_id, **kwargs)
        assert delete_subnet_response, (
            f"failed to delete subnet '{subnet_id}'."
        )
        assert delete_subnet_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected:'{RESPONSE_OK}' but, found"
            f"'{delete_subnet_response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        subnet_id_list = [subnet['SubnetId'] for subnet in self.list_subnets_validate()['Subnets']]
        assert subnet_id not in subnet_id_list, f"failed to delete subnet '{subnet_id}'."
        logging.info(Fore.GREEN + f"subnet '{subnet_id}' deleted successfully." + Style.RESET_ALL)
        if self.command_line:
            return f"subnet '{subnet_id}' deleted successfully."

    def create_route_table(self, vpc_id: str, **kwargs):
        """
        Method to create route_table.
        :param vpc_id: VPC id.
        :param kwargs: DryRun/TagSpecifications
        :return: create_route_table_response
        """
        try:
            create_route_table_response = self.client.create_route_table(VpcId=vpc_id, **kwargs)
            return create_route_table_response
        except ClientError as err:
            print(Fore.RED)
            logging.info(
                f"failed to create route_table for vpc '{vpc_id}', listing with err: {err.response['Error']['Code']}"
            )
            logging.error(err)
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def create_route_table_validate(self, vpc_id: str, **kwargs):
        """
        Method to validate create route table response.
        :param vpc_id: VPC id.
        :param kwargs: DryRun/TagSpecifications
        :return: create_route_table_response
        """
        create_route_table_response = self.create_route_table(vpc_id, **kwargs)
        assert create_route_table_response, (
            f"failed to create and associate route table with vpc '{vpc_id}'."
        )
        assert create_route_table_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected:'{RESPONSE_OK}' but, found"
            f"'{create_route_table_response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        route_table_list = [
            route_tables['RouteTableId'] for route_tables in self.list_route_table_validate()['RouteTables']]
        assert create_route_table_response['RouteTable']['RouteTableId'] in route_table_list, (
            f"failed to create and associate route table with vpc '{vpc_id}'."
        )
        logging.info(Fore.GREEN +
                     f"Route table '{create_route_table_response['RouteTable']['RouteTableId']}',"
                     f"for vpc '{vpc_id}' created successfully'" + Style.RESET_ALL
                     )
        return create_route_table_response

    def create_route(self, route_table_id: str, destination_cidr: str, **kwargs):
        """
        Method to create route.
        :param route_table_id: route table id
        :param destination_cidr: Destination cidr block
        :param kwargs: DestinationCidrBlock/DestinationIpv6CidrBlock/DestinationPrefixListId/DryRun/
        EgressOnlyInternetGatewayId/GatewayId/InstanceId/NatGatewayId/TransitGatewayId/LocalGatewayId/CarrierGatewayId/
        NetworkInterfaceId/VpcPeeringConnectionId.
        :return: create_route_response
        """
        try:
            create_route_response = self.client.create_route(
                RouteTableId=route_table_id,
                DestinationCidrBlock=destination_cidr,
                **kwargs)
            return create_route_response
        except ClientError as err:
            print(Fore.RED)
            logging.info(
                f"failed to create route, listing with err: {err.response['Error']['Code']}"
            )
            logging.error(err)
            print(Style.RESET_ALL)

    def create_route_validate(self, route_table_id: str, destination_cidr: str, **kwargs):
        """
        Method to validate create route response.
        :param route_table_id: route table id.:
        :param destination_cidr: destination cidr block.
        :param kwargs: DestinationCidrBlock/DestinationIpv6CidrBlock/DestinationPrefixListId/DryRun/
        EgressOnlyInternetGatewayId/GatewayId/InstanceId/NatGatewayId/TransitGatewayId/LocalGatewayId/CarrierGatewayId/
        NetworkInterfaceId/VpcPeeringConnectionId.
        :return: create_route_response
        """
        create_route_response = self.create_route(route_table_id, destination_cidr, **kwargs)
        assert create_route_response, "failed to create route."
        assert create_route_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected:'{RESPONSE_OK}' but, found"
            f"'{create_route_response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        routes_destination_cidr = [routes['DestinationCidrBlock'] for routes in self.list_route_table_validate(
            RouteTableIds=[route_table_id])['RouteTables'][0]['Routes']]
        assert destination_cidr in routes_destination_cidr, f"failed to add route to route table '{route_table_id}'."
        logging.info(Fore.GREEN + "Route created successfully'" + Style.RESET_ALL)
        if self.command_line:
            return create_route_response

    def list_route_table(self, **kwargs):
        """
        Method to list route tables.
        :param kwargs: Filters/DryRun/RouteTableIds/NextToken/MaxResults
        :return: describe_route_table_response
        """
        try:
            describe_route_table_response = self.client.describe_route_tables(**kwargs)
            return describe_route_table_response
        except ClientError as err:
            logging.info(
                f"failed to get route table, listing with err: {err.response['Error']['Code']}"
            )
            logging.error(err)

    def list_route_table_validate(self, **kwargs):
        """
        Method to validate list route table response.
        :param kwargs: Filters/DryRun/RouteTableIds/NextToken/MaxResults
        :return: describe_route_table_response
        """
        describe_route_table_response = self.list_route_table(**kwargs)
        assert describe_route_table_response, "failed to get route table."
        assert describe_route_table_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected:'{RESPONSE_OK}' but, found"
            f"'{describe_route_table_response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        return describe_route_table_response

    def delete_route(self, route_table_id: str, destination_cidr: str, **kwargs):
        """
        Method to delete route.
        :param route_table_id: route table id.
        :param destination_cidr: Destination Cidr Block
        :param kwargs: DestinationIpv6CidrBlock/DestinationPrefixListId/DryRun.
        :return: delete_route_response
        """
        try:
            delete_route_response = self.client.delete_route(
                RouteTableId=route_table_id,
                DestinationCidrBlock=destination_cidr,
                **kwargs
            )
            return delete_route_response
        except ClientError as err:
            print(Fore.RED)
            logging.info(
                f"failed to delete route with destination cidr '{destination_cidr}',"
                f" listing with err: {err.response['Error']['Code']}"
            )
            logging.error(err)
            print(Style.RESET_ALL)

    def delete_route_validate(self, route_table_id: str, destination_cidr: str, **kwargs):
        """
        Method to validate delete route response.
        :param route_table_id: route table id.
        :param destination_cidr: Destination Cidr Block
        :param kwargs: DestinationIpv6CidrBlock/DestinationPrefixListId/DryRun.
        :return: delete_route_response
        """
        delete_route_response = self.delete_route(route_table_id, destination_cidr, **kwargs)
        assert delete_route_response, f"failed to delete route for destination cidr block '{destination_cidr}'."
        assert delete_route_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected:'{RESPONSE_OK}' but, found"
            f"'{delete_route_response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        routes_destination_cidr = [routes['DestinationCidrBlock'] for routes in self.list_route_table_validate(
            RouteTableIds=[route_table_id])['RouteTables'][0]['Routes']]
        assert destination_cidr not in routes_destination_cidr, (
            f"failed to delete route for destination cidr block '{destination_cidr}'."
        )
        logging.info(Fore.GREEN + f"Route for destination '{destination_cidr}' deleted successfully'" + Style.RESET_ALL)
        if self.command_line:
            return f"Route for destination '{destination_cidr}' deleted successfully'"

    def delete_route_table(self, route_table_id: str, **kwargs):
        """
        Method to delete route table.
        :param route_table_id: route table id.
        :return: delete_route_table_response
        """
        try:
            delete_route_table_response = self.client.delete_route_table(RouteTableId=route_table_id, **kwargs)
            return delete_route_table_response
        except ClientError as err:
            print(Fore.RED)
            logging.info(
                f"failed to delete route table '{route_table_id}', listing with err: {err.response['Error']['Code']}"
            )
            logging.error(err)
            print(Style.RESET_ALL)

    def delete_route_table_validate(self, route_table_id: str, **kwargs):
        """
        Method to validate delete route table response.
        :param route_table_id: route table id.
        """
        delete_route_table_response = self.delete_route_table(route_table_id, **kwargs)
        assert delete_route_table_response, f"failed to delete route table '{route_table_id}'."
        assert delete_route_table_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected:'{RESPONSE_OK}' but, found"
            f"'{delete_route_table_response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        route_table_list = [route_tables['RouteTableId'] for route_tables in
                            self.list_route_table_validate()['RouteTables']]
        assert route_table_id not in route_table_list, (
            f"failed to delete route table '{route_table_id}'."
        )
        logging.info(Fore.GREEN + f"Route table '{route_table_id}' deleted successfully." + Style.RESET_ALL)
        if self.command_line:
            return f"Route table '{route_table_id}' deleted successfully."

    def create_nat_gateway(self, allocation_id: str, subnet_id: str, **kwargs):
        """
        Method to create NAT gateway.
        :param allocation_id: allocation ID of an Elastic IP address.
        :param subnet_id: subnet in which to create the NAT gateway
        :param kwargs: ClientToken/DryRun/TagSpecifications.
        :return: create_nat_gateway_response.
        """
        try:
            create_nat_gateway_response = self.client.create_nat_gateway(
                AllocationId=allocation_id,
                SubnetId=subnet_id,
                **kwargs
            )
            return create_nat_gateway_response
        except ClientError as err:
            logging.info(
                f"failed to create nat gateway with elastic address allocation id '{allocation_id}',"
                f"listing with err: {err.response['Error']['Code']}"
            )
            logging.error(err)

    def create_nat_gateway_validate(self, allocation_id: str, subnet_id: str, **kwargs):
        """
        Method to validate create NAT gateway response.
        :param allocation_id: allocation ID of an Elastic IP address.
        :param subnet_id: subnet in which to create the NAT gateway
        :param kwargs: ClientToken/DryRun/TagSpecifications.
        :return: create_nat_gateway_response.
        """
        create_nat_gateway_response = self.create_nat_gateway(allocation_id, subnet_id, **kwargs)
        assert create_nat_gateway_response, (
            f"failed to create nat gateway with elastic address allocation id '{allocation_id}'."
        )
        assert create_nat_gateway_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected:'{RESPONSE_OK}' but, found"
            f"'{create_nat_gateway_response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        nat_gateway_id_list = [
            nat_gateway_list['NatGatewayId'] for nat_gateway_list in self.list_nat_gateway_validate()['NatGateways']]
        assert create_nat_gateway_response['NatGateway']['NatGatewayId'] in nat_gateway_id_list, (
            f"failed to create nat gateway with elastic address allocation id '{allocation_id}'."
        )
        logging.info(f"nat gateway '{create_nat_gateway_response['NatGateway']['NatGatewayId']}' created successfully.")
        return create_nat_gateway_response

    def list_nat_gateways(self, **kwargs):
        """
        Method to list nat gateways
        :param kwargs: DryRun/Filters/MaxResults/NatGatewayIds/NextToken
        :return: describe_nat_gateway_response
        """
        try:
            describe_nat_gateway_response = self.client.describe_nat_gateways(**kwargs)
            return describe_nat_gateway_response
        except ClientError as err:
            logging.info(
                f"failed to get nat gateway, listing with err: {err.response['Error']['Code']}"
            )
            logging.error(err)

    def list_nat_gateway_validate(self, **kwargs):
        """
        Method to validate list nat gateways.
        :param kwargs: DryRun/Filters/MaxResults/NatGatewayIds/NextToken
        :return: describe_nat_gateway_response
        """
        describe_nat_gateway_response = self.list_nat_gateways(**kwargs)
        assert describe_nat_gateway_response, "failed to get nat gateway response."
        assert describe_nat_gateway_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected:'{RESPONSE_OK}' but, found"
            f"'{describe_nat_gateway_response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        return describe_nat_gateway_response

    def delete_nat_gateway(self, nat_gateway_id: str, **kwargs):
        """
        Method to delete nat gateway.
        :param nat_gateway_id: NAT gateway id.
        :param kwargs: DryRun
        :return: delete_nat_gateway_response
        """
        try:
            delete_nat_gateway_response = self.client.delete_nat_gateway(NatGatewayId=nat_gateway_id, **kwargs)
            return delete_nat_gateway_response
        except ClientError as err:
            logging.info(
                f"failed to delete nat gateway '{nat_gateway_id}',"
                f"listing with err: {err.response['Error']['Code']}"
            )
            logging.error(err)

    def nat_gateway_status_check(self, nat_gateway_id: str):
        """
        Method to toggel the status of nat gateway.
        :param nat_gateway_id: NAT gateway id.
        """
        nat_gateway_status = self.list_nat_gateway_validate(NatGatewayIds=[nat_gateway_id])['NatGateways'][0]['State']
        if nat_gateway_status == "deleted":
            return True
        else:
            return False

    def delete_nat_gateway_validate(self, nat_gateway_id: str, **kwargs):
        """
        Method to validate delete nat gateway response.
        :param nat_gateway_id: NAT gateway id.
        :param kwargs: DryRun
        """
        delete_status = False
        delete_nat_gateway_response = self.delete_nat_gateway(nat_gateway_id, **kwargs)
        assert delete_nat_gateway_response, f"failed to delete nat gateway '{nat_gateway_id}'."
        assert delete_nat_gateway_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected:'{RESPONSE_OK}' but, found"
            f"'{delete_nat_gateway_response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        for _ in range(0, 20):
            delete_status = self.nat_gateway_status_check(nat_gateway_id)
            if delete_status:
                break
            else:
                time.sleep(5)
        assert delete_status, (
            f"failed to delete nat gateway '{nat_gateway_id}'."
        )
        logging.info(f"nat gateway '{nat_gateway_id}' deleted successfully.")

    def associate_cidr_block(self, vpc_id: str, **kwargs):
        """
        Method to associate a new cidr block to existing vpc
        :param vpc_id: VPC id.
        :param kwargs: AmazonProvidedIpv6CidrBlock/CidrBlock/Ipv6CidrBlockNetworkBorderGroup/Ipv6Pool/Ipv6CidrBlock.
        :return: associate_cidr_response.
        """
        try:
            associate_cidr_response = self.client.associate_vpc_cidr_block(
                VpcId=vpc_id, **kwargs
            )
            return associate_cidr_response
        except ClientError as err:
            logging.info(
                f"failed to associate new cidr block to vpc '{vpc_id}',"
                f"listing with err: {err.response['Error']['Code']}"
            )
            logging.error(err)

    def associate_cidr_block_validate(self, vpc_id: str, **kwargs):
        """
        Method to validate association of new cidr block to existing vpc.
        :param vpc_id: VPC id.
        :param kwargs: AmazonProvidedIpv6CidrBlock/CidrBlock/Ipv6CidrBlockNetworkBorderGroup/Ipv6Pool/Ipv6CidrBlock.
        """
        associate_cidr_response = self.associate_cidr_block(vpc_id, **kwargs)
        assert associate_cidr_response, f"failed to associate cidr to vpc '{vpc_id}'."
        assert associate_cidr_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected:'{RESPONSE_OK}' but, found"
            f"'{associate_cidr_response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        vpc_list = self.list_vpc_validate(VpcIds=[vpc_id])
        for key, value in kwargs.items():
            keyowrd_list_ipv6 = ('AmazonProvidedIpv6CidrBlock', 'Ipv6CidrBlock', 'Ipv6Pool')
            if key in keyowrd_list_ipv6:
                ipv6_cidr_block_list = [
                    iplist['Ipv6CidrBlock'] for iplist in vpc_list['Vpcs'][0]['Ipv6CidrBlockAssociationSet']]
                assert value in ipv6_cidr_block_list, f"failed to associate cidr '{value}' to vpc '{vpc_id}'"
            elif key == 'CidrBlock':
                ipv4_cidr_block_list = [
                    iplist['CidrBlock'] for iplist in vpc_list['Vpcs'][0]['CidrBlockAssociationSet']]
                assert value in ipv4_cidr_block_list, f"failed to associate cidr '{value}' to vpc '{vpc_id}'"
            else:
                raise Exception('Invalid parameter.')
        logging.info(f"cidr block associated to vpc '{vpc_id}' successfully")

    def assign_elastic_ip(self, instance_id: str, allocation_id: str, **kwargs):
        """
        Method to allocate elastic ip to ec2 instance.
        :param instance_id: ec2 instance id
        :param allocation_id: allocation id
        :param kwargs: PublicIp/AllowReassociation/DryRun/NetworkInterfaceId/PrivateIpAddress
        :return: assign_ip
        """
        try:
            assign_ip = self.client.associate_address(
                AllocationId=allocation_id, InstanceId=instance_id, **kwargs
            )
            return assign_ip
        except ClientError as err:
            logging.info(f"Failed to assign elastic ip to instance {instance_id}")
            logging.error(err)

    def assign_validate_elastic_ipaddress(self, instance_id: str, allocation_id: str, elastic_ip: str, **kwargs):
        """
        Method to allocate and validate elastic ip assigned to ec2 instance.
        :param instance_id: ec2 instance id
        :param allocation_id: allocation id
        :param elastic_ip: Public IP
        :param kwargs: PublicIp/AllowReassociation/DryRun/NetworkInterfaceId/PrivateIpAddress
        """
        assign_elastic_ip = self.assign_elastic_ip(instance_id, allocation_id, **kwargs)
        assert assign_elastic_ip, f"Failed to assign ip to instance {instance_id}"
        assert assign_elastic_ip['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected:'{RESPONSE_OK}' but, found"
            f"'{assign_elastic_ip['ResponseMetadata']['HTTPStatusCode']}'"
        )
        list_elastic_ip = self.list_elastic_ip_validate(AllocationIds=[allocation_id])
        assert assign_elastic_ip['AssociationId'] == (
            list_elastic_ip['Addresses'][0]['AssociationId']
        ), "Cannot assign elastic ip"
        assert allocation_id == list_elastic_ip['Addresses'][0]['AllocationId'], (
            "Can not get allocation id while assign elastic ip"
        )
        logging.info(
            f"Elastic ip {elastic_ip}"
            f"assigned to instance {list_elastic_ip['Addresses'][0]['InstanceId']} successfully"
            f"Association id is {assign_elastic_ip}"
        )

    def create_network_interface(self, subnet_id: str, **kwargs):
        """
        Method to create network interface
        :param subnet_id: subnet_id
        :param kwargs:Description/DryRun/Groups/Ipv6AddressCount/Ipv6Addresses/PrivateIpAddress/PrivateIpAddresses/
        SecondaryPrivateIpAddressCount/InterfaceType/SubnetId/TagSpecifications
        :return: network_interface: network interface creation response
        """
        try:
            network_interface = self.client.create_network_interface(SubnetId=subnet_id, **kwargs)
            return network_interface
        except ClientError as err:
            logging.info(f"Failed to create network interface for subnet id {subnet_id}")
            logging.error(err)

    def attach_network_interface(self, device_index: int, instance_id: str, network_interface_id: str, **kwargs):
        """
        Method to attach network interface
        :param device_index: device index
        :param instance_id: EC2 instance id
        :param network_interface_id: network interface id
        :kwargs: DryRun/NetworkCardIndex
        :return: attach_network_interface
        """
        try:
            attach_network_interface = self.client.attach_network_interface(
                DeviceIndex=device_index, InstanceId=instance_id, NetworkInterfaceId=network_interface_id, **kwargs
            )
            return attach_network_interface
        except ClientError as err:
            logging.error(err)

    def create_validate_network_interface(self, instance_id: str, **kwargs):
        """
        Method to create network interface and validate it created successfully
        :param instance_id: instance_id
        :param kwargs: escription/DryRun/Groups/Ipv6AddressCount/Ipv6Addresses/PrivateIpAddress/PrivateIpAddresses/
        SecondaryPrivateIpAddressCount/InterfaceType/SubnetId/TagSpecifications
        :return: create_network_interface_response
        """
        instance_info = self.get_validate_instance(InstanceIds=[instance_id])
        create_network_interface_response = self.create_network_interface(
            instance_info['Reservations'][0]['Instances'][0]['SubnetId'], **kwargs
        )
        assert create_network_interface_response, "Failed to create network interface"
        assert create_network_interface_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected:'{RESPONSE_OK}' but, found"
            f"'{create_network_interface_response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        list_validate_network_interfaces_response = self.get_network_interface(
            NetworkInterfaceIds=[create_network_interface_response['NetworkInterface']['NetworkInterfaceId']]
        )
        assert list_validate_network_interfaces_response['NetworkInterfaces'][0]['SubnetId'] == (
            instance_info['Reservations'][0]['Instances'][0]['SubnetId']
        ), (
            f"Failed to creating network interface with subnet id "
            f"{instance_info['Reservations'][0]['Instances'][0]['SubnetId']}"
        )
        assert list_validate_network_interfaces_response['NetworkInterfaces'][0]['VpcId'] == (
            instance_info['Reservations'][0]['Instances'][0]['VpcId']
        ), (
            f"Failed to creating network interface with subnet id "
            f"{instance_info['Reservations'][0]['Instances'][0]['VpcId']}"
        )
        logging.info(f"Network Interface {create_network_interface_response['NetworkInterface']['NetworkInterfaceId']}"
                     f"created suceessfully.")

        return create_network_interface_response

    def validate_attach_network_interface(self, instance_id: str, network_interface_id: str, device_index: int,
                                          **kwargs):
        """
        Method to attach network interface to EC2 instance and validate network interface is attached.
        :param instance_id: EC2 instance id
        :param network_interface_id: Network interface id
        :param device_index: device index
        :param kwargs: DryRun/NetworkCardIndex
        :return: network interface id
        """
        network_interface_info = None
        attach_network_interface_response = self.attach_network_interface(
            device_index, instance_id, network_interface_id, **kwargs
        )
        assert attach_network_interface_response, f"Failed to create network interface"
        assert attach_network_interface_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected:'{RESPONSE_OK}' but, found"
            f"'{attach_network_interface_response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        for _ in range(20):
            network_interface_info = self.get_validate_network_interface(
                NetworkInterfaceIds=[network_interface_id], **kwargs
            )
            logging.info(f"Current network interface attachment status "
                         f"{network_interface_info['NetworkInterfaces'][0]['Attachment']['Status']}"
                         )
            if network_interface_info['NetworkInterfaces'][0]['Attachment']['Status'] == "attached":
                break
            time.sleep(5)
        instance_info = self.get_validate_instance(InstanceIds=[instance_id])
        assert network_interface_info['NetworkInterfaces'][0]['Attachment']['AttachmentId'] == (
            instance_info['Reservations'][0]['Instances'][0]['NetworkInterfaces'][1]['Attachment']['AttachmentId']
        ), (
            f"Failed to attach network interface id "
            f"{instance_info['Reservations'][0]['Instances'][0]['NetworkInterfaces'][1]['Attachment']['AttachmentId']}"
        )
        assert instance_info['Reservations'][0]['Instances'][0]['NetworkInterfaces'][1]['Attachment']['Status'] == (
            network_interface_info['NetworkInterfaces'][0]['Attachment']['Status']
        ), (
            f"Failed to attach network interface id "
            f"{instance_info['Reservations'][0]['Instances'][0]['NetworkInterfaces'][1]['Attachment']['Status']}"
        )
        logging.info(f"Network Interface attched successfully. {network_interface_id}")

        return network_interface_info['NetworkInterfaces'][0]['Attachment']['AttachmentId']

    def detach_network_interface(self, attachment_id: str, **kwargs):
        """
        Method to detach network interface from ec2 instance
        :param attachment_id: nework interface attachment id
        :param kwargs: DryRun/Force
        :return: detach_network_interface_response
        """
        try:
            detach_network_interface_response = self.client.detach_network_interface(
                AttachmentId=attachment_id, **kwargs
            )

            return detach_network_interface_response
        except ClientError as err:
            logging.error(f"Error in detach network interface : {err}")

    def validate_detach_network_interface(self, network_attachment_id: str, interface_id: str, **kwargs):
        """
        Method to detach network interface id
        :param network_attachment_id: Network attachment id
        :param interface_id: Network Interface id
        :param kwargs: DryRun/Force
        """
        detach_network = self.detach_network_interface(network_attachment_id, **kwargs)
        assert detach_network, f"failed to detach network interface'."
        assert detach_network['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected:'{RESPONSE_OK}' but, found"
            f"'{detach_network['ResponseMetadata']['HTTPStatusCode']}'"
        )
        for _ in range(20):
            network_interface_info = self.get_validate_network_interface(
                NetworkInterfaceIds=[interface_id],
            )
            status = network_interface_info['NetworkInterfaces'][0]['Status']
            if status == "available":
                logging.info(f"Now current state of network interface is :'{status}'")
                break
            time.sleep(5)
        network_interface_info = self.get_validate_network_interface(
            NetworkInterfaceIds=[interface_id],
        )
        assert network_interface_info['NetworkInterfaces'][0]['Status'] == (
            "available"), f"Network interface {interface_id} detached successfully."
        logging.info("Network Interface detached successfully.")

    def delete_network_interface(self, network_interface_id: str, **kwargs):
        """
        Method to delete network interface id
        :param network_interface_id: network interface id
        :param kwargs:DryRun
        :return: delete_network_interface
        """
        try:
            delete_network_interface = self.client.delete_network_interface(
                NetworkInterfaceId=network_interface_id, **kwargs
            )
            return delete_network_interface
        except ClientError as err:
            logging.error(f"Failed to delete network interface: {err}")

    def validate_delete_network_interface(self, network_interface_id: str, **kwargs):
        """
        Method to delete network interface and validate it deleted successfully.
        :param network_interface_id: network interface id
        :param kwargs:DryRun
        """
        for _ in range(20):
            network_interface_info = self.get_validate_network_interface(
                NetworkInterfaceIds=[network_interface_id], **kwargs
            )
            if network_interface_info['NetworkInterfaces'][0]['Status'] == 'available':
                logging.info(f"Interface state is '{network_interface_info['NetworkInterfaces'][0]['Status']}'")
                break
            time.sleep(5)
        delete_network_interface = self.delete_network_interface(
            network_interface_id, **kwargs
        )
        assert delete_network_interface, f"Failed to create network interface"
        assert delete_network_interface['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected:'{RESPONSE_OK}' but, found"
            f"'{delete_network_interface['ResponseMetadata']['HTTPStatusCode']}'"
        )
        network_interface_info = self.get_validate_network_interface()
        network_interfaces_list = [network_interface_info["NetworkInterfaces"][network_interfaces]['NetworkInterfaceId']
                                   for network_interfaces in range(len(network_interface_info))]
        assert network_interface_id not in network_interfaces_list, (
            f"Failed to delete network interface {network_interface_id}"
        )
        logging.info(f"Network Interface {network_interface_id} deleted successfully.")

    def delete_non_existing_ec2_instance(self, instance_id: str):
        """
        Method to delete non-existing EC2 instance
        :param instance_id: EC2 instance id
        :return: error_message
        """
        try:
            self.remove_validate_instance(instance_id)
        except ClientError as error_message:
            logging.error(error_message)
            return error_message

    def validate_delete_non_existing_instance(self, instance_id: str):
        """
        Method to delete non-existing EC2 instance and validate error
        :param instance_id: EC2 innstance id
        """
        delete_non_existing_instance = self.delete_non_existing_ec2_instance(instance_id)
        assert delete_non_existing_instance, "Failed to get an error message"
        assert str(delete_non_existing_instance) == (
            f"An error occurred (InvalidInstanceID.Malformed) when calling the DescribeInstances operation: "
            f"Invalid id: \"{instance_id}\""
        )
        logging.info("Test is passed with appropriate error meassage")


def main():
    # Common Parsers
    parent_parser = argparse.ArgumentParser(add_help=False)
    parent_parser.add_argument("--instance_id", type=str,
                               help="ID of the instance" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                               default=argparse.SUPPRESS,
                               required=True)
    parent_parser.add_argument("--DryRun", "--dryrun", type=bool,
                               help="Checks whether you have the required permissions for the action, without actually "
                                    "making the request, and provides an error response.", default=argparse.SUPPRESS)
    parser = argparse.ArgumentParser()
    ec2_method_subparser = parser.add_subparsers(dest='ec2_method')

    # Get Instance Info Commands
    get_ec2_info_parser = ec2_method_subparser.add_parser("info", parents=[parent_parser],
                                                          help="Fetches the instance information")
    get_ec2_info_parser.add_argument("--Filters", "--filters", type=list,
                                     help="The filters.", default=argparse.SUPPRESS)
    get_ec2_info_parser.add_argument("--MaxResults", "--max-results", type=int,
                                     help="The maximum number of results to return in a single call.",
                                     default=argparse.SUPPRESS)
    get_ec2_info_parser.add_argument("--NextToken", "--nexttoken", type=str,
                                     help="The token to request the next page of results.", default=argparse.SUPPRESS)

    # LAUNCH Instance Commands
    launch_ec2_parser = ec2_method_subparser.add_parser("launch",
                                                        help="Launches the ec2 information with given parameters")
    launch_ec2_parser.add_argument("--mincount", type=int,
                                   help="Minimum Count of Instances" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                   required=True)
    launch_ec2_parser.add_argument("--maxcount", type=int, default="m1.small",
                                   help="Maximum Count of Instances" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                   required=True)
    launch_ec2_parser.add_argument("--image_id", type=str,
                                   help="The ID of the AMI. An AMI ID is required to launch an instance and must be "
                                        "specified here or in a launch template." + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                   required=True)
    launch_ec2_parser.add_argument("--InstanceType", "--instance-type", type=str, required=True,
                                   help="The EC2 Instance Type" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL)
    launch_ec2_parser.add_argument("--BlockDeviceMappings", "--block-device-mappings", type=list,
                                   help="Specify the EC2 operation you want to perform", default=argparse.SUPPRESS)
    launch_ec2_parser.add_argument("--Ipv6AddressCount", "--ipv6-address-count", type=int,
                                   help="The number of IPv6 addresses to associate with the primary network interface. "
                                        "Amazon EC2 chooses the IPv6 addresses from the range of your subnet. "
                                        "You cannot specify this option and the option to assign specific IPv6 "
                                        "addressesin the same request. You can specify this option if you've specified "
                                        "a minimum number of instances to launch.", default=argparse.SUPPRESS)
    launch_ec2_parser.add_argument("--Ipv6Addresses", "--ipv6-addresses", type=list,
                                   help="[EC2-VPC] The IPv6 addresses from the range of the subnet to associate with "
                                        "the primary network interface. You cannot specify this option and the option "
                                        "to assign a number of IPv6 addresses in the same request. You cannot specify "
                                        "this option if you've specified a minimum number of instances to launch.",
                                   default=argparse.SUPPRESS)
    launch_ec2_parser.add_argument("--KernelId", "--kernel-id", type=str, help="The ID of the kernel.",
                                   default=argparse.SUPPRESS)
    launch_ec2_parser.add_argument("--KeyName", "--key-name", type=str, help="The name of the key pair.",
                                   default=argparse.SUPPRESS)
    launch_ec2_parser.add_argument("--Monitoring", "--monitoring", type=str, help="Specifies whether detailed "
                                                                                  "monitoring is enabled for the "
                                                                                  "instance.",
                                   default=argparse.SUPPRESS)
    launch_ec2_parser.add_argument("--Placement", "--placement", type=str, help="The placement for the instance.",
                                   default=argparse.SUPPRESS)
    launch_ec2_parser.add_argument("--RamdiskId", "--ramdisk-id", type=str,
                                   help="The ID of the RAM disk to select. Some kernels require additional drivers at "
                                        "launch. Check the kernel requirements for information about whether you need "
                                        "to specify a RAM disk. To find kernel requirements, go to the Amazon Web "
                                        "Services Resource Center and search for the kernel ID.",
                                   default=argparse.SUPPRESS)
    launch_ec2_parser.add_argument("--SecurityGroupIds", "--security-group-ids", type=list,
                                   help="The IDs of the security groups.", default=argparse.SUPPRESS)
    launch_ec2_parser.add_argument("--SecurityGroups", "--security-groups", type=list,
                                   help="The names of the security groups. For a nondefault VPC, "
                                        "you must use security group IDs instead.", default=argparse.SUPPRESS)
    launch_ec2_parser.add_argument("--SubnetId", "--subnet-id", type=str,
                                   help="The ID of the subnet to launch the instance into.", default=argparse.SUPPRESS)
    launch_ec2_parser.add_argument("--UserData", "--user-data", type=str,
                                   help="The user data to make available to the instance.", default=argparse.SUPPRESS)
    launch_ec2_parser.add_argument("--AdditionalInfo", "--additional-info", type=str,
                                   help="Specify the EC2 operation you want to perform", default=argparse.SUPPRESS)
    launch_ec2_parser.add_argument("--IamInstanceProfile", "--iam-instance-profile", type=str,
                                   default=argparse.SUPPRESS,
                                   help="The name or Amazon Resource Name (ARN) of an IAM instance profile.")
    launch_ec2_parser.add_argument("--email", type=str,
                                   help="Specify email ID to send email notification (Multiple comma-separated "
                                        "email IDs are acceptable)",
                                   default=argparse.SUPPRESS)

    # Instance Status Check Commands
    status_check_parser = ec2_method_subparser.add_parser("status",
                                                          help="Verifies EC2 instance state (2/2 state)")
    status_check_parser.add_argument("--instance_id", "--instanceid", type=str,
                                     help="Instance ID" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL, required=True)

    # List All Instance
    list_instances_parser = ec2_method_subparser.add_parser("list-instances",
                                                            help="List all instances available")

    # STOP Instance Commands
    stop_ec2_parser = ec2_method_subparser.add_parser("stop", parents=[parent_parser],
                                                      help="Stops instance(shut-down)")
    stop_ec2_parser.add_argument("--AdditionalInfo", "--additional-info", type=str,
                                 help="Reserved.", default=argparse.SUPPRESS)
    stop_ec2_parser.add_argument("--email", type=str,
                                 help="Specify email ID to send email notification (Multiple comma-separated "
                                      "email IDs are acceptable)",
                                 default=argparse.SUPPRESS)

    # Start Instance Commands
    start_ec2_parser = ec2_method_subparser.add_parser("start", parents=[parent_parser],
                                                       help="Starts instance")
    start_ec2_parser.add_argument("--AdditionalInfo", "--additional-info", type=str,
                                  help="Reserved.", default=argparse.SUPPRESS)
    start_ec2_parser.add_argument("--email", type=str,
                                  help="Specify email ID to send email notification (Multiple comma-separated "
                                       "email IDs are acceptable)",
                                  default=argparse.SUPPRESS)

    # Reboot Instance Commands
    reboot_ec2_parser = ec2_method_subparser.add_parser("reboot", parents=[parent_parser],
                                                        help="Reboots instance")
    reboot_ec2_parser.add_argument("--email", type=str,
                                   help="Specify email ID to send email notification (Multiple comma-separated "
                                        "email IDs are acceptable)",
                                   default=argparse.SUPPRESS)

    # TERMINATE Instance Commands
    terminate_ec2_parser = ec2_method_subparser.add_parser("terminate", parents=[parent_parser],
                                                           help="Terminates instance")
    terminate_ec2_parser.add_argument("--email", type=str,
                                      help="Specify email ID to send email notification (Multiple "
                                           "comma-separated email IDs are acceptable)",
                                      default=argparse.SUPPRESS)

    # Create EBS Volume Commands
    create_ebs_parser = ec2_method_subparser.add_parser("create-ebs", help="Create EBS Volume")
    create_ebs_parser.add_argument("--availability_zone", type=str, help="availability zone" + Fore.RED + " [REQUIRED]"
                                                                         + Style.RESET_ALL, required=True)
    create_ebs_parser.add_argument("--size", type=int, help="EBS volume size in GiBs [default 0]", default=0)
    create_ebs_parser.add_argument("--snapshot_id", type=str, help="snapshot id from which to create the volume.",
                                   default="")
    create_ebs_parser.add_argument("--email", type=str,
                                   help="Specify email ID to send email notification (Multiple comma-separated "
                                        "email IDs are acceptable)",
                                   default=argparse.SUPPRESS)

    # Get EBS Volume commands
    get_ebs_parser = ec2_method_subparser.add_parser("get-ebs", help="Get EBS Volume")
    get_ebs_parser.add_argument("--VolumeIds", "--volume_ids", type=str, help="Volume IDs", required=True)

    # Attach EBS commands
    attach_ebs_parser = ec2_method_subparser.add_parser("attach-ebs", parents=[parent_parser], help="Attach EBS Volume"
                                                                                                    " to a running or stopped instance and exposes it to the instance"
                                                                                                    " with the specified device name")
    attach_ebs_parser.add_argument("--device", type=str,
                                   help="Device name i.e. /dev/sdh or xvdh" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                   required=True)
    attach_ebs_parser.add_argument("--volume_id", type=str,
                                   help="EBS volume Id" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL, required=True)
    attach_ebs_parser.add_argument("--email", type=str,
                                   help="Specify email ID to send email notification (Multiple comma-separated "
                                        "email IDs are acceptable)",
                                   default=argparse.SUPPRESS)

    # Detach EBS Commands
    detach_ebs_parser = ec2_method_subparser.add_parser("detach-ebs", parents=[parent_parser], help="Detach EBS Volume")
    detach_ebs_parser.add_argument("--volume_id", type=str,
                                   help="EBS volume Id" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL, required=True)
    detach_ebs_parser.add_argument("--email", type=str,
                                   help="Specify email ID to send email notification (Multiple comma-separated "
                                        "email IDs are acceptable)",
                                   default=argparse.SUPPRESS)

    # Delete EBS Commands
    delete_ebs_parser = ec2_method_subparser.add_parser("delete-ebs", help="Delete EBS Volume")
    delete_ebs_parser.add_argument("--volume_id", type=str, help="EBS volume Id"  + Fore.RED + " [REQUIRED]" + Style.RESET_ALL, required=True)
    delete_ebs_parser.add_argument("--email", type=str,
                                   help="Specify email ID to send email notification (Multiple comma-separated "
                                        "email IDs are acceptable)",
                                   default=argparse.SUPPRESS)

    # Create AMI Commands
    create_ami_parser = ec2_method_subparser.add_parser("create-ami", parents=[parent_parser], help="Create an AMI")
    create_ami_parser.add_argument("--name", type=str, help="AMI name" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                   required=True)
    create_ami_parser.add_argument("--email", type=str,
                                   help="Specify email ID to send email notification (Multiple comma-separated "
                                        "email IDs are acceptable)",
                                   default=argparse.SUPPRESS)

    # get AMI Commands
    get_ami_parser = ec2_method_subparser.add_parser("get-ami-info", help="Fetch image info")
    get_ami_parser.add_argument("--ImageIds", "--image_ids", type=str, help="AMI Image ID" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL, required=True)

    # de-register AMI Commands
    de_reg_parser = ec2_method_subparser.add_parser("deregister-ami", help="de-register ami")
    de_reg_parser.add_argument("--image_id", type=str, help="AMI ID" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL, required=True)
    de_reg_parser.add_argument("--delete_snapshot", type=bool, help="True/False if snapshot created by image need to "
                                                                    "delete. [Default- True]", default=True)
    de_reg_parser.add_argument("--email", type=str,
                               help="Specify email ID to send email notification (Multiple comma-separated "
                                    "email IDs are acceptable)",
                               default=argparse.SUPPRESS)

    # Create snapshot Commands
    create_snap_parser = ec2_method_subparser.add_parser("create-snapshot", help="create crash-consistent snapshots of "
                                                                                 "multiple EBS volumes including boot "
                                                                                 "volume attached to the instance",
                                                         parents=[parent_parser])
    create_snap_parser.add_argument("--email", type=str,
                                    help="Specify email ID to send email notification (Multiple comma-separated "
                                         "email IDs are acceptable)",
                                    default=argparse.SUPPRESS)

    # Get validate snapshot
    get_snap_parser = ec2_method_subparser.add_parser("get-snapshot", help="Get & validate information of snapshot")
    get_snap_parser.add_argument("--SnapshotIds", "--snapshot_ids", type=str, help="Snapshot IDs" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                 required=True)

    # Delete snapshot
    del_snap_parser = ec2_method_subparser.add_parser("delete-snapshot", help="delete a snapshot")
    del_snap_parser.add_argument("--snapshot_ids", type=str,
                                 help="Snapshot ID" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL, required=True)
    del_snap_parser.add_argument("--email", type=str,
                                 help="Specify email ID to send email notification (Multiple comma-separated "
                                      "email IDs are acceptable)",
                                 default=argparse.SUPPRESS)

    # Create Tag in Instance
    create_tag_parser = ec2_method_subparser.add_parser("create-tag", help="Create Tag in Instance")
    create_tag_parser.add_argument("--instance_ids", type=str, help="List of Instance IDs where tag needs to be added."
                                                                    "(Mention multiple instances separated by commas)"
                                                                    + Fore.RED + " [REQUIRED]" + Style.RESET_ALL
                                   , required=True)
    create_tag_parser.add_argument("--tags", type=str, help="List of Key value pair tag which need to add in instance"
                                                            + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                   required=True)
    create_tag_parser.add_argument("--email", type=str,
                                   help="Specify email ID to send email notification (Multiple comma-separated "
                                        "email IDs are acceptable)",
                                   default=argparse.SUPPRESS)

    # Create Security Group
    create_sec_grp_parser = ec2_method_subparser.add_parser("create-security-group", help="create a security group")
    create_sec_grp_parser.add_argument("--grp_name", type=str, help="Name of the security group" + Fore.RED +
                                                                    " [REQUIRED]" + Style.RESET_ALL, required=True)
    create_sec_grp_parser.add_argument("--description", type=str, help="Description for the security group"
                                                                       + Fore.RED + " [REQUIRED]" + Style.RESET_ALL
                                       , required=True)
    create_sec_grp_parser.add_argument("--email", type=str,
                                       help="Specify email ID to send email notification (Multiple comma-separated "
                                            "email IDs are acceptable)",
                                       default=argparse.SUPPRESS)

    # Delete Security Group
    del_sec_grp_parser = ec2_method_subparser.add_parser("delete-security-group", help="Delete Existing security "
                                                                                       "group [Either provide "
                                                                                       "security group ID or Name]")
    del_sec_grp_parser.add_argument("--group_id", type=str, help="Security group name" + Fore.CYAN +
                                                                 " [Either provide security group ID or group Name]" +
                                                                 Style.RESET_ALL, default="")
    del_sec_grp_parser.add_argument("--group_name", type=str, help="Security group id" + Fore.CYAN +
                                                                   " [Either provide security group ID or group Name]" +
                                                                   Style.RESET_ALL, default="")
    del_sec_grp_parser.add_argument("--email", type=str,
                                    help="Specify email ID to send email notification (Multiple comma-separated "
                                         "email IDs are acceptable)",
                                    default=argparse.SUPPRESS)

    # Authorize Security Group Ingress
    authorize_sec_grp_ingress_parser = ec2_method_subparser.add_parser("authorize-ingress",
                                                                       help="Adds the specific inbound(ingress) rules to security group")
    authorize_sec_grp_ingress_parser.add_argument("--group_id", type=str,
                                                  help="Security group id" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                                  required=True)
    authorize_sec_grp_ingress_parser.add_argument("--ip_protocol", type=str,
                                                  help="IP protocol name (tcp , udp , icmp , icmpv6 )" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                                  required=True)
    authorize_sec_grp_ingress_parser.add_argument("--from_port", type=int,
                                                  help="The start of port range for the TCP and UDP protocols, or an ICMP/ICMPv6 type number" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                                  required=True)
    authorize_sec_grp_ingress_parser.add_argument("--to_port", type=int,
                                                  help="The end of port range for the TCP and UDP protocols, or an ICMP/ICMPv6 code." + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                                  required=True)
    authorize_sec_grp_ingress_parser.add_argument("--cidr_ip", type=str,
                                                  help="IPv4 CIDR range" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                                  required=True)
    authorize_sec_grp_ingress_parser.add_argument("--description", type=str,
                                                  help="A description for the security group rule that references this IPv4 address range" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                                  required=True)
    authorize_sec_grp_ingress_parser.add_argument("--email", type=str,
                                                  help="Specify email ID to send email notification (Multiple comma-separated "
                                                       "email IDs are acceptable)",
                                                  default=argparse.SUPPRESS)

    # Revoke Security Group Ingress
    revoke_sec_grp_ingress_parser = ec2_method_subparser.add_parser("revoke-ingress",
                                                                    help="Remove the specific inbound(ingress) rules to security group")
    revoke_sec_grp_ingress_parser.add_argument("--group_id", type=str,
                                               help="Security group id" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                               required=True)
    revoke_sec_grp_ingress_parser.add_argument("--ip_protocol", type=str,
                                               help="IP protocol name (tcp , udp , icmp , icmpv6 )" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                               required=True)
    revoke_sec_grp_ingress_parser.add_argument("--from_port", type=int,
                                               help="The start of port range for the TCP and UDP protocols, or an ICMP/ICMPv6 type number" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                               required=True)
    revoke_sec_grp_ingress_parser.add_argument("--to_port", type=int,
                                               help="The end of port range for the TCP and UDP protocols, or an ICMP/ICMPv6 code." + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                               required=True)
    revoke_sec_grp_ingress_parser.add_argument("--cidr_ip", type=str,
                                               help="IPv4 CIDR range" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                               required=True)
    revoke_sec_grp_ingress_parser.add_argument("--description", type=str,
                                               help="Description for the security group [Should match with the "
                                                    "description provided while authorizing]"
                                                    + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                               required=True)
    revoke_sec_grp_ingress_parser.add_argument("--email", type=str,
                                               help="Specify email ID to send email notification (Multiple comma-separated "
                                                    "email IDs are acceptable)",
                                               default=argparse.SUPPRESS)

    # Authorize Security Group Egress
    authorize_sec_grp_egress_parser = ec2_method_subparser.add_parser("authorize-egress",
                                                                      help="Adds the specific outbound(egress) rules to security group")
    authorize_sec_grp_egress_parser.add_argument("--group_id", type=str,
                                                 help="Security group id" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                                 required=True)
    authorize_sec_grp_egress_parser.add_argument("--ip_protocol", type=str,
                                                 help="IP protocol name (tcp , udp , icmp , icmpv6 )" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                                 required=True)
    authorize_sec_grp_egress_parser.add_argument("--from_port", type=int,
                                                 help="The start of port range for the TCP and UDP protocols, or an ICMP/ICMPv6 type number" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                                 required=True)
    authorize_sec_grp_egress_parser.add_argument("--to_port", type=int,
                                                 help="The end of port range for the TCP and UDP protocols, or an ICMP/ICMPv6 code." + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                                 required=True)
    authorize_sec_grp_egress_parser.add_argument("--cidr_ip", type=str,
                                                 help="IPv4 CIDR range" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                                 required=True)
    authorize_sec_grp_egress_parser.add_argument("--description", type=str,
                                                 help="A description for the security group rule that references this IPv4 address range" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                                 required=True)
    authorize_sec_grp_egress_parser.add_argument("--email", type=str,
                                                 help="Specify email ID to send email notification (Multiple comma-separated "
                                                      "email IDs are acceptable)",
                                                 default=argparse.SUPPRESS)

    # Revoke Security Group Egress
    revoke_sec_grp_egress_parser = ec2_method_subparser.add_parser("revoke-egress",
                                                                   help="Remove the specific outbound(egress) rules to security group")
    revoke_sec_grp_egress_parser.add_argument("--group_id", type=str,
                                              help="Security group id" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                              required=True)
    revoke_sec_grp_egress_parser.add_argument("--ip_protocol", type=str,
                                              help="IP protocol name (tcp , udp , icmp , icmpv6 )" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                              required=True)
    revoke_sec_grp_egress_parser.add_argument("--from_port", type=int,
                                              help="The start of port range for the TCP and UDP protocols, or an ICMP/ICMPv6 type number" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                              required=True)
    revoke_sec_grp_egress_parser.add_argument("--to_port", type=int,
                                              help="The end of port range for the TCP and UDP protocols, or an ICMP/ICMPv6 code." + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                              required=True)
    revoke_sec_grp_egress_parser.add_argument("--cidr_ip", type=str,
                                              help="IPv4 CIDR range" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                              required=True)
    revoke_sec_grp_egress_parser.add_argument("--description", type=str,
                                              help="A description for the security group rule that references this "
                                                   "IPv4 address range[Should match with the "
                                                    "description provided while authorizing]" +
                                                   Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                              required=True)
    revoke_sec_grp_egress_parser.add_argument("--email", type=str,
                                              help="Specify email ID to send email notification (Multiple comma-separated "
                                                   "email IDs are acceptable)",
                                              default=argparse.SUPPRESS)

    # Describe Security Group
    desc_sec_grp_parser = ec2_method_subparser.add_parser("describe-security-group",
                                                          help="Describe the specific security group or all [Either provide security group ID or Name]")
    desc_sec_grp_parser.add_argument("--group_id", type=str, help="Security group id", default="")
    desc_sec_grp_parser.add_argument("--group_name", type=str, help="Security group name", default="")
    desc_sec_grp_parser.add_argument("--filter_group_name", type=str, help="Filter security by group name", default="")
    desc_sec_grp_parser.add_argument("--filter_group_id", type=str, help="Filter security by group id", default="")

    # Attach Role to an EC2 Instance
    attach_role_to_ec2_parser = ec2_method_subparser.add_parser("attach-role", help="attach a role to an ec2 instance")
    attach_role_to_ec2_parser.add_argument("--instance_id", type=str,
                                           help="Instance ID" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL
                                           , required=True)
    attach_role_to_ec2_parser.add_argument("--role_name", type=str,
                                           help="Existing role name" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                           required=True)
    attach_role_to_ec2_parser.add_argument("--instance_profile_arn", type=str, help="instance profile Amazon resource"
                                                                                    " number" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                           required=True)
    attach_role_to_ec2_parser.add_argument("--email", type=str,
                                           help="Specify email ID to send email notification (Multiple comma-separated "
                                                "email IDs are acceptable)",
                                           default=argparse.SUPPRESS)

    # Create VPC
    create_vpc_parser = ec2_method_subparser.add_parser("create-vpc", help="Create VPC")
    create_vpc_parser.add_argument("--cidr_block", type=str,
                                   help="Cidr block" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL
                                   , required=True)
    create_vpc_parser.add_argument("--email", type=str,
                                   help="Specify email ID to send email notification (Multiple comma-separated "
                                        "email IDs are acceptable)",
                                   default=argparse.SUPPRESS)

    # List VPC
    list_vpc_parser = ec2_method_subparser.add_parser("list-vpc", help="List VPCs")

    # Delete VPC
    del_vpc_parser = ec2_method_subparser.add_parser("delete-vpc", help="Delete VPC")
    del_vpc_parser.add_argument("--vpc_id", type=str, help="VPC ID" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                required=True)
    del_vpc_parser.add_argument("--email", type=str,
                                help="Specify email ID to send email notification (Multiple comma-separated "
                                     "email IDs are acceptable)",
                                default=argparse.SUPPRESS)

    # Create VPC Endpoint
    create_vpc_ep_parser = ec2_method_subparser.add_parser("create-vpc-endpoint", help="create vpc end point")
    create_vpc_ep_parser.add_argument("--vpc_id", type=str, help="VPC ID" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL
                                      , required=True)
    create_vpc_ep_parser.add_argument("--service_name", type=str,
                                      help="Service name" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL
                                      , required=True)
    create_vpc_ep_parser.add_argument("--email", type=str,
                                      help="Specify email ID to send email notification (Multiple comma-separated "
                                           "email IDs are acceptable)",
                                      default=argparse.SUPPRESS)

    # Delete VPC Endpoint
    del_vpc_ep_parser = ec2_method_subparser.add_parser("delete-vpc-endpoint", help="create vpc end point")
    del_vpc_ep_parser.add_argument("--vpc_endpoint_ids", type=str,
                                   help="VPC endpoint IDs" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL
                                   , required=True)
    del_vpc_ep_parser.add_argument("--email", type=str,
                                      help="Specify email ID to send email notification (Multiple comma-separated "
                                           "email IDs are acceptable)",
                                      default=argparse.SUPPRESS)

    # Create Elastic IP
    create_eip_parser = ec2_method_subparser.add_parser("create-elastic-ip", help="Create elastic ip")
    create_eip_parser.add_argument("--email", type=str,
                                   help="Specify email ID to send email notification (Multiple comma-separated "
                                        "email IDs are acceptable)",
                                   default=argparse.SUPPRESS)
    # Domain/Address/PublicIpv4Pool/NetworkBorderGroup/CustomerOwnedIpv4Pool/DryRun

    # Release Elastic IP
    rel_eip_parser = ec2_method_subparser.add_parser("release-elastic-ip", help="Release the allocated ip address")
    rel_eip_parser.add_argument("--allocation_id", type=str,
                                help="allocation id" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL
                                , required=True)
    rel_eip_parser.add_argument("--email", type=str,
                                help="Specify email ID to send email notification (Multiple comma-separated "
                                     "email IDs are acceptable)",
                                default=argparse.SUPPRESS)

    # Create Subnet
    create_subnet_parser = ec2_method_subparser.add_parser("create-subnet", help="Create Subnet")
    create_subnet_parser.add_argument("--cidr_block", type=str,
                                      help="CIDR Block" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL, required=True)
    create_subnet_parser.add_argument("--vpc_id", type=str, help="VPC ID" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                      required=True)
    create_subnet_parser.add_argument("--email", type=str,
                                      help="Specify email ID to send email notification (Multiple comma-separated "
                                           "email IDs are acceptable)",
                                      default=argparse.SUPPRESS)

    # Delete Subnet
    del_subnet_parser = ec2_method_subparser.add_parser("delete-subnet", help="Delete Subnet")
    del_subnet_parser.add_argument("--subnet_id", type=str,
                                   help="Subnet ID" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL, required=True)
    del_subnet_parser.add_argument("--email", type=str,
                                   help="Specify email ID to send email notification (Multiple comma-separated "
                                        "email IDs are acceptable)",
                                   default=argparse.SUPPRESS)

    # Create Route Table
    create_route_table_parser = ec2_method_subparser.add_parser("create-route-table", help="Create Route Table")
    create_route_table_parser.add_argument("--vpc_id", type=str,
                                           help="VPC ID" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL, required=True)
    create_route_table_parser.add_argument("--email", type=str,
                                           help="Specify email ID to send email notification (Multiple comma-separated "
                                                "email IDs are acceptable)",
                                           default=argparse.SUPPRESS)

    # Create Route
    create_route_parser = ec2_method_subparser.add_parser("create-route", help="Create new route")
    create_route_parser.add_argument("--route_table_id", type=str,
                                     help="route table id" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL, required=True)
    create_route_parser.add_argument("--destination_cidr", type=str,
                                     help="Destination cidr block" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                     required=True)
    create_route_parser.add_argument("--GatewayId", "--gateway_id", type=str, help="Gateway ID",
                                     default=argparse.SUPPRESS)
    create_route_parser.add_argument("--email", type=str,
                                     help="Specify email ID to send email notification (Multiple comma-separated "
                                          "email IDs are acceptable)",
                                     default=argparse.SUPPRESS)

    # Delete Route
    delete_route_parser = ec2_method_subparser.add_parser("delete-route", help="Delete existing route")
    delete_route_parser.add_argument("--route_table_id", type=str,
                                     help="route table id" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL, required=True)
    delete_route_parser.add_argument("--destination_cidr", type=str,
                                     help="Destination cidr block" + Fore.RED + "[REQUIRED]" + Style.RESET_ALL,
                                     required=True)
    delete_route_parser.add_argument("--email", type=str,
                                     help="Specify email ID to send email notification (Multiple comma-separated "
                                          "email IDs are acceptable)",
                                     default=argparse.SUPPRESS)

    # Delete Route Table
    del_route_table_parser = ec2_method_subparser.add_parser("delete-route-table", help="Delete route table")
    del_route_table_parser.add_argument("--route_table_id", type=str, help="Route Table ID" + Fore.RED + " [REQUIRED]"
                                                                           + Style.RESET_ALL, required=True)
    del_route_table_parser.add_argument("--email", type=str,
                                        help="Specify email ID to send email notification (Multiple comma-separated "
                                             "email IDs are acceptable)",
                                        default=argparse.SUPPRESS)

    args = parser.parse_args()
    if not args.ec2_method:
        parser.print_help()
        return
    parse_args_to_execute(args)


@send_email("EC2", "ec2_method")
def parse_args_to_execute(args, config_data=None):
    if args.ec2_method and config_data:
        ec2_obj = EC2(config_data, command_line=True)
        args_dict = vars(args)
        if args.ec2_method == "launch":
            del args_dict['ec2_method']
            instance_id = ec2_obj.create_validate_instance_from_image(**args_dict)
            return f"Instance created with instance ID: {instance_id}"
        elif args.ec2_method == "status":
            del args_dict['ec2_method']
            ec2_obj.validate_status_check(**args_dict)
        elif args.ec2_method == "info":
            del args_dict['ec2_method']
            ec2_obj.fetch_instance_info(**args_dict)
        elif args.ec2_method == "list-instances":
            del args_dict['ec2_method']
            ec2_obj.list_all_instances()
        elif args.ec2_method == "reboot":
            del args_dict['ec2_method']
            return ec2_obj.reboot_validate_instance(**args_dict)
        elif args.ec2_method == "start":
            del args_dict['ec2_method']
            return ec2_obj.start_validate_instance(**args_dict)
        elif args.ec2_method == "stop":
            del args_dict['ec2_method']
            return ec2_obj.stop_validate_instance(**args_dict)
        elif args.ec2_method == "terminate":
            del args_dict['ec2_method']
            return ec2_obj.remove_validate_instance(**args_dict)
        elif args.ec2_method == "create-ebs":
            del args_dict['ec2_method']
            vol_id = ec2_obj.validate_create_ebs_volume(**args_dict)
            return f"EBS volume created successfully. Volume ID: {vol_id}"
        elif args.ec2_method == "get-ebs":
            del args_dict['ec2_method']
            args_dict['VolumeIds'] = args_dict['VolumeIds'].split(",")
            ec2_obj.validate_get_ebs_volume(**args_dict)
        elif args.ec2_method == "attach-ebs":
            del args_dict['ec2_method']
            return ec2_obj.attach_validate_ebs_volume(**args_dict)
        elif args.ec2_method == "detach-ebs":
            del args_dict['ec2_method']
            return ec2_obj.detach_validate_ebs_volume(**args_dict)
        elif args.ec2_method == "delete-ebs":
            del args_dict['ec2_method']
            return ec2_obj.delete_validate_ebs_volume(**args_dict)
        elif args.ec2_method == "create-ami":
            del args_dict['ec2_method']
            image_id = ec2_obj.create_validate_ami(**args_dict)
            return f"AMI Created Successfully. ID - {image_id}"
        elif args.ec2_method == "get-ami-info":
            del args_dict['ec2_method']
            args_dict["ImageIds"] = args_dict["ImageIds"].split(",")
            ec2_obj.validate_get_image(**args_dict)
        elif args.ec2_method == "deregister-ami":
            del args_dict['ec2_method']
            return ec2_obj.deregister_validate_ami(**args_dict)
        elif args.ec2_method == "create-snapshot":
            del args_dict['ec2_method']
            snap_ids = ec2_obj.create_validate_snapshot(**args_dict)
            return f"snapshot created successfully. Active snapshot id's - {snap_ids}"
        elif args.ec2_method == "get-snapshot":
            del args_dict['ec2_method']
            args_dict['SnapshotIds'] = args_dict['SnapshotIds'].split(",")
            ec2_obj.get_validate_snapshot(**args_dict)
        elif args.ec2_method == "delete-snapshot":
            del args_dict['ec2_method']
            args_dict["snapshot_ids"] = args_dict["snapshot_ids"].split(",")
            return ec2_obj.delete_validate_snapshot(**args_dict)
        elif args.ec2_method == "create-tag":
            del args_dict['ec2_method']
            args_dict["instance_ids"] = args_dict["instance_ids"].split(",")
            args_dict["tags"] = json.loads(args_dict["tags"])
            ec2_obj.create_validate_tag(**args_dict)
            return "Tags added successfully to instance"
        elif args.ec2_method == "create-security-group":
            del args_dict['ec2_method']
            sec_grp_id = ec2_obj.create_validate_security_group(**args_dict)
            return f"Security group created successfully. Group Id: {sec_grp_id}"
        elif args.ec2_method == "delete-security-group":
            del args_dict['ec2_method']
            return ec2_obj.delete_validate_security_group(**args_dict)
        elif args.ec2_method == "authorize-ingress":
            del args_dict['ec2_method']
            return ec2_obj.authorize_validate_security_group_ingress(**args_dict)
        elif args.ec2_method == "revoke-ingress":
            del args_dict['ec2_method']
            return ec2_obj.revoke_validate_security_group_ingress(**args_dict)
        elif args.ec2_method == "authorize-egress":
            del args_dict['ec2_method']
            return ec2_obj.authorize_validate_security_group_egress(**args_dict)
        elif args.ec2_method == "revoke-egress":
            del args_dict['ec2_method']
            return ec2_obj.revoke_validate_security_group_egress(**args_dict)
        elif args.ec2_method == "describe-security-group":
            del args_dict['ec2_method']
            ec2_obj.describe_validate_security_group(**args_dict)
        elif args.ec2_method == "attach-role":
            del args_dict['ec2_method']
            return ec2_obj.attach_role_ec2_instance_validate(**args_dict)
        elif args.ec2_method == "create-vpc":
            del args_dict['ec2_method']
            return ec2_obj.create_vpc_validate(**args_dict)
        elif args.ec2_method == "list-vpc":
            del args_dict['ec2_method']
            ec2_obj.list_vpc(cons_log=True, **args_dict)
        elif args.ec2_method == "delete-vpc":
            del args_dict['ec2_method']
            return ec2_obj.delete_vpc_validate(**args_dict)
        elif args.ec2_method == "create-vpc-endpoint":
            del args_dict['ec2_method']
            return ec2_obj.create_vpc_endpoint_validate(**args_dict)
        elif args.ec2_method == "delete-vpc-endpoint":
            del args_dict['ec2_method']
            args_dict["vpc_endpoint_ids"] = args_dict["vpc_endpoint_ids"].split(",")
            return ec2_obj.delete_vpc_endpoint_validate(**args_dict)
        elif args.ec2_method == "create-elastic-ip":
            del args_dict['ec2_method']
            return ec2_obj.create_elastic_ip_validate(**args_dict)
        elif args.ec2_method == "release-elastic-ip":
            del args_dict['ec2_method']
            return ec2_obj.release_elastic_ip_validate(**args_dict)
        elif args.ec2_method == "create-subnet":
            del args_dict['ec2_method']
            return ec2_obj.create_subnet_validate(**args_dict)
        elif args.ec2_method == "delete-subnet":
            del args_dict['ec2_method']
            return ec2_obj.delete_subnet_validate(**args_dict)
        elif args.ec2_method == "create-route-table":
            del args_dict['ec2_method']
            return ec2_obj.create_route_table_validate(**args_dict)
        elif args.ec2_method == "create-route":
            del args_dict['ec2_method']
            return ec2_obj.create_route_validate(**args_dict)
        elif args.ec2_method == "delete-route":
            del args_dict['ec2_method']
            return ec2_obj.delete_route_validate(**args_dict)
        elif args.ec2_method == "delete-route-table":
            del args_dict['ec2_method']
            return ec2_obj.delete_route_table_validate(**args_dict)


if __name__ == '__main__':
    main()
