#!/usr/bin/env python3
import argparse
import json
import logging
import sys
import time
import os
import datetime
import logging.handlers

import boto3
from colorama import Fore, Style
from prettytable import PrettyTable

from email_notifications import send_email
from constants import RESPONSE_OK


class RDS:
    def __init__(self, config, command_line=False):
        self.client = boto3.client(
            "rds", **config
        )
        self.config = config
        self.command_line = command_line
        self.config = config
        self.command_line = command_line
        if command_line:
            home_dir = os.path.expanduser("~")
            cur_date = datetime.datetime.now().strftime("%d_%b_%Y")
            log_dir_path = os.path.join(home_dir, ".a4cloudstack_logs")
            final_log_path = log_dir_path + "/log_" + cur_date
            if not os.path.exists(final_log_path):
                os.makedirs(final_log_path, mode=0o777, exist_ok=True)
            logging.getLogger().setLevel(logging.NOTSET)
            console = logging.StreamHandler(sys.stdout)
            console.setLevel(logging.INFO)
            formater = logging.Formatter('%(message)s')
            console.setFormatter(formater)
            logging.getLogger().addHandler(console)

            # Add file rotating handler, with level DEBUG
            rotatingHandler = logging.handlers.RotatingFileHandler(filename=final_log_path + "/" + 'rds.log',
                                                                   maxBytes=100000, backupCount=5)
            rotatingHandler.setLevel(logging.INFO)
            formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
            rotatingHandler.setFormatter(formatter)
            logging.getLogger().addHandler(rotatingHandler)
            sys.tracebacklimit = 0

    def create_db(self, storage: int, instance_class: str, instance_name: str, db_engine: str, username: str,
                  password: str, **kwargs):
        """
        Method to Create new DB instance.
        @param storage: add the store for the DB instance
        @param instance_class: name of the instance type you want to deploy
        @param instance_name: name of the instance which you want to create
        @param db_engine: name of the DB type you want to deploy
        @param username: username for the DB instance
        @param password: Password for the DB instance
        @param kwargs:
        @return:
        """
        try:
            logging.info("creating db with name " + str(instance_name))
            logging.info("This may take a while, Please wait....")
            db_instance = self.client.create_db_instance(AllocatedStorage=storage, DBInstanceClass=instance_class,
                                                         DBInstanceIdentifier=instance_name, Engine=db_engine,
                                                         MasterUsername=username, MasterUserPassword=password, **kwargs)
            assert db_instance, f"Failed to create Database"

            for _ in range(12):
                db_instance_info = self.client.describe_db_instances(DBInstanceIdentifier=instance_name)
                if db_instance_info['DBInstances'][0]['DBInstanceStatus'] == 'creating':
                    logging.info(
                        f"Current status of DB instance is: {db_instance_info['DBInstances'][0]['DBInstanceStatus']}")
                    break
                time.sleep(5)
            else:
                raise Exception(
                    "Unable to create your server.... Please check the instance state or on console")
            for _ in range(48):
                db_instance_info = self.client.describe_db_instances(DBInstanceIdentifier=instance_name)
                if db_instance_info['DBInstances'][0]['DBInstanceStatus'] == 'backing-up':
                    logging.info(
                        f"Current status of DB instance is: {db_instance_info['DBInstances'][0]['DBInstanceStatus']}")
                    break
                time.sleep(5)
            else:
                raise Exception(
                    "Unable to backup your server.... Please check the instance state or on console")
            for _ in range(48):
                db_instance_info = self.client.describe_db_instances(DBInstanceIdentifier=instance_name)
                if db_instance_info['DBInstances'][0]['DBInstanceStatus'] == 'available':
                    logging.info(
                        f"Current status of the DB Instance is: {db_instance_info['DBInstances'][0]['DBInstanceStatus']}")
                    break
                time.sleep(5)
            else:
                raise Exception(
                    "Your DB Instance not powered-on... If the instance size is "
                    "large, it will take time to spinup the instance. you can check the status of the instance using "
                    "command")
            print(
                Fore.GREEN + f"DB Instance  - {db_instance['DBInstance']['DBInstanceIdentifier']} is available to use" + Style.RESET_ALL)
            return db_instance['DBInstance']['DBInstanceIdentifier']
        except Exception as err:
            print(Fore.RED)
            logging.error(err)
            logging.error(f"Failed to create db instance in RDS with error: {err}")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def fetch_instance_info(self, instance_name: str):
        """ Method for get info of DB and print on console in readable format.
        @param instance_name: name of the instance which you want to fetch info
        @return: db_status_info
        """
        try:
            db_status_info = self.client.describe_db_instances(DBInstanceIdentifier=instance_name)
            # logging.info(db_status_info)
            logging.info(json.dumps(db_status_info, indent=7, sort_keys=True, default=str))
            return db_status_info
        except Exception as err:
            logging.error(f"Unable to fetch instance information. Error - {err}")

    def get_instance_info(self, instance_name: str):
        """ Method for get info of DB.
        @param instance_name: name of the instance which you want to fetch info
        @return: db_status_info
        """
        try:
            db_status_info = self.client.describe_db_instances(DBInstanceIdentifier=instance_name)
            return db_status_info
        except Exception as err:
            logging.error(f"Unable to fetch instance information. Error - {err}")

    def check_rds_instance_status(self, instance_name: str):
        """ Method for get current status of DB instances.
        @param instance_name: name of the instance which you want to fetch state
        @return: db_status_info
        """
        try:
            db_status_info = self.client.describe_db_instances(DBInstanceIdentifier=instance_name)
            db_status_info_list = [(k, v) for k, v in db_status_info.items()]
            instances = db_status_info_list[0][1]
            instance_info = (instances[0])
            logging.info(
                f"Your instance {instance_info['DBInstanceIdentifier']} is in {instance_info['DBInstanceStatus']} state")
            return instance_info['DBInstanceStatus']
        except Exception as err:
            logging.error(f"Unable to fetch instance state. Error - {err}")

    def start_validate_instance(self, instance_name: str, negative_case: bool = False):
        """
        This method is for validating and power on a DB instance.
        @param instance_name: name of the instance which you want to start DB instance
        @param negative_case:
        """
        logging.info(f"Power on the DB instance with instance name: {instance_name}")
        self.start_db(instance_name)
        start_instance_info = self.get_instance_info(instance_name=instance_name)
        if negative_case:
            assert not start_instance_info, f"Power on done on Running DB instance: {start_instance_info}"
            logging.info("DB Instance is already in running state.")
        else:
            time.sleep(10)
            assert start_instance_info, f"Error in power on DB instance: {start_instance_info}"
            assert start_instance_info['DBInstances'][0]['DBInstanceStatus'] == "starting", (
                f"Error in Instance start: {start_instance_info}"
            )
            for _ in range(6):
                node = self.get_instance_info(instance_name=instance_name)
                node_list = [(k, v) for k, v in node.items()]
                instances = node_list[0][1]
                instance_info = (instances[0])
                if instance_info['DBInstanceStatus'] == 'Available':
                    logging.info(Fore.GREEN + "Your DB Instance powered-on successfully." + Style.RESET_ALL)
                    break
                logging.info(f"DB Instance current state is {instance_info['DBInstanceStatus']}")
                time.sleep(20)
                return "Instance started successfully"
            else:
                print(
                    Fore.RED + "Your DB Instance not powered-on in 120 sec after power-on the instance. If the "
                               "instance size is large, it will take time to spinup the instance. Please check the "
                               "instance status after some time" + Style.RESET_ALL)
                return "Instance start initiated. (If the instance size is large, it will take time to spinup the " \
                       "instance. Please check the instance state after some time) "

    def start_db(self, instance_name: str):
        """ This method is for power on a DB instance.
        @param instance_name: name of the instance which you want to start DB instance
        @return: instance_start.
        """
        instance_start = None
        node = self.get_instance_info(instance_name=instance_name)
        if node['DBInstances'][0]['DBInstanceStatus'] == 'Available':
            logging.info(
                Fore.YELLOW + f"Instance {node['DBInstances'][0]['DBInstanceIdentifier']} is already Running" + Style.RESET_ALL)
            if self.command_line:
                exit()
        else:
            try:
                db_start = self.client.start_db_instance(DBInstanceIdentifier=instance_name)
                return db_start
            except Exception as err:
                print(Fore.RED)
                logging.error(err)
                logging.error(
                    f"Failed to Stop Instance '{instance_name}' with error: {err}"
                )
                print(Style.RESET_ALL)
                if self.command_line:
                    exit()

    def stop_validate_instance(self, instance_name: str, negative_case: bool = False):
        """
        This method is for validating and power off a DB instance.
        @param instance_name: name of the instance which you want to stop DB instance
        @param negative_case: true/false
        """
        logging.info(f"Power off the instance with DB instance name: {instance_name}")
        self.stop_db(instance_name)
        stop_instance_info = self.get_instance_info(instance_name=instance_name)
        if negative_case:
            assert not stop_instance_info, f"Power off done on stopped DB instance: {stop_instance_info}"
            logging.info("Your DB Instance is already in stopped state.")
        else:
            time.sleep(10)
            assert stop_instance_info, f"Error in power off DB instance: {stop_instance_info}"
            assert stop_instance_info['DBInstances'][0]['DBInstanceStatus'] == "stopping", (
                f"Error in Instance stop: {stop_instance_info}"
            )
            for _ in range(6):
                node = self.get_instance_info(instance_name=instance_name)
                node_list = [(k, v) for k, v in node.items()]
                instances = node_list[0][1]
                instance_info = (instances[0])
                if instance_info['DBInstanceStatus'] == 'stopped':
                    logging.info(Fore.GREEN + "Your DB Instance powered-off successfully." + Style.RESET_ALL)
                    break
                logging.info(f"DB Instance current state is {instance_info['DBInstanceStatus']}")
                time.sleep(20)
            else:
                print(
                    Fore.RED + "Your DB not powered-off in 120 sec after power-off the instance. If the "
                               "instance size is large, it will take time to stop the instance. Please check the "
                               "instance status after some time" + Style.RESET_ALL)
                return "Instance stop initiated. (If the instance size is large, it will take time to spinup the " \
                       "instance. Please check the instance state after some time) "

    def stop_db(self, instance_name: str):
        """ This method is for power off a DB instance.
        @param instance_name: Instance name of DB instance to be power off.
        @return: db_stop
        """
        instance_stop = None
        node = self.get_instance_info(instance_name=instance_name)
        if node['DBInstances'][0]['DBInstanceStatus'] == 'stopped':
            logging.info(
                Fore.YELLOW + f"Instance {node['DBInstances'][0]['DBInstanceIdentifier']} is already stopped" + Style.RESET_ALL)
            if self.command_line:
                exit()
        else:
            try:
                db_stop = self.client.stop_db_instance(DBInstanceIdentifier=instance_name)
                return db_stop
            except Exception as err:
                print(Fore.RED)
                logging.error(err)
                logging.error(
                    f"Failed to Stop Instance '{instance_name}' with error: {err}"
                )
                print(Style.RESET_ALL)
                if self.command_line:
                    exit()

    def reboot_db(self, instance_name: str, **kwargs):
        """ Method for Reboot instances.
        @param instance_name: Instance name of DB instance to be reboot.
        @return: db_reboot
        """
        try:
            db_reboot = self.client.reboot_db_instance(DBInstanceIdentifier=instance_name, **kwargs)
            return db_reboot
        except Exception as err:
            logging.error(f"Unable to reboot instance. Error - {err}")

    def reboot_validate_instance(self, instance_name: str, **kwargs):
        """ This method is for validating and reboot DB instance.
        @param instance_name: DB Instance name of instance to be rebooted.
        """
        logging.info(f"Reboot the db with instance name: {instance_name}")
        reboot_instance = self.reboot_db(instance_name, **kwargs)
        assert reboot_instance['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Error in rebooting instance. Output: {reboot_instance}"
        )
        for _ in range(6):
            node = self.get_instance_info(instance_name=instance_name)
            if node['DBInstances'][0]['DBInstanceStatus'] == 'available':
                break
            logging.info(f"Instance current state is {node['DBInstances'][0]['DBInstanceStatus']}")
            time.sleep(20)
        else:
            raise TimeoutError(
                Fore.RED + "Instance not powered-on in 120 sec after power-on the instance. If the instance size is "
                           "large, it will take time to spinup the instance. you can check the status of the "
                           "instance" +
                Style.RESET_ALL)
        logging.info(Fore.GREEN + "Instance rebooted successfully." + Style.RESET_ALL)

    def delete_db_instance(self, instance_name: str, skipfinalsnapshot: bool, negative_case: bool = False):
        """
        This method is for Delete DB instance.
        @param instance_name: name of the instance you want to delete
        @param skipfinalsnapshot: Boolean value to skip snapshot while deleting the DB instance
        @param negative_case:
        @return:
        """
        try:
            logging.info(f"Terminating instance with instance name: {instance_name}")
            delete_db = None
            node = self.get_instance_info(instance_name=instance_name)
            if node['DBInstances'][0]['DBInstanceStatus'] == 'deleting':
                logging.info(
                    Fore.YELLOW + f"Instance {node['DBInstances'][0]['DBInstanceIdentifier']} is already deleted" + Style.RESET_ALL)
                if self.command_line:
                    exit()
            else:
                try:
                    delete_db = self.client.delete_db_instance(DBInstanceIdentifier=instance_name,
                                                               SkipFinalSnapshot=skipfinalsnapshot)
                except Exception as err:
                    print(Fore.RED)
                    logging.error(err)
                    logging.error(
                        f"Failed to Remove Instance '{instance_name}' with error: {err}"
                    )
                    print(Style.RESET_ALL)
                    if self.command_line:
                        exit()
            if negative_case:
                assert not delete_db, f"Error in deleting instance: {delete_db}"
                logging.info("Instance already deleted.")
            else:
                assert delete_db, f"Error in delete instance: {delete_db}"
                logging.info(Fore.GREEN + "Instance terminated successfully." + Style.RESET_ALL)
            return "Delete instance initiated.... Your Instance will be terminated shortly"
        except Exception as err:
            print(Fore.RED)
            logging.error(err)
            logging.error(f"Failed to Delete db instance in RDS with error: {err}")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def list_all_instances(self):
        """ Method for get info of instances.
        :return: Instance_info
        """
        try:
            instances_info = self.client.describe_db_instances()
            print("Instance Name\t\t\tInstance Type\t\tStorage(GB)\t\tDB Engine\t\t\tState")
            for instace in instances_info['DBInstances']:
                # #db_name = i['DBName']
                db_instance_name = instace['DBInstanceIdentifier']
                db_type = instace['DBInstanceClass']
                db_storage = instace['AllocatedStorage']
                db_engine = instace['Engine']
                status = instace['DBInstanceStatus']
                print("{0}\t\t\t{1}\t\t{2}\t\t\t{3}\t\t\t{4}\n".format(db_instance_name, db_type, db_storage, db_engine, status))
        except Exception as err:
            print(Fore.RED)
            logging.error(f"Unable to list instances. Error - {err}")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def fetch_db_snapshot(self, instance_name: str, snapshot_type: str, **kwargs):
        """
        This method is for Fetch snapshot details.
        @param instance_name: name of the instance for which you want to fetch the snapshot details
        @param kwargs:
        @return: snapshot details of the instance
        """
        try:
            db_snap = self.client.describe_db_snapshots(DBInstanceIdentifier=instance_name, SnapshotType=snapshot_type, **kwargs)
            logging.info(json.dumps(db_snap, indent=7, sort_keys=True, default=str))
            return db_snap
        except Exception as err:
            logging.error(f"Unable to fetch Snapshot information. Error - {err}")

    def list_db_snapshot(self):
        """
        Method for get info of Snapshots.
        :return: Snapshot_info
        """
        try:
            db_snap = self.client.describe_db_snapshots()
            mytable = PrettyTable(["Snapshot Name", "Snapshot Type", "DB Engine", "State"])
            for snapshots in db_snap['DBSnapshots']:
                mytable.add_row([snapshots['DBSnapshotIdentifier'], snapshots['SnapshotType'], snapshots['Engine'],
                                 snapshots['Status']])
            mytable.hrules = 1
            print("\n".join(mytable.get_string().splitlines()))
        except Exception as err:
            print(Fore.RED)
            logging.error(f"Unable to list instances. Error - {err}")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def create_snapshot(self, instance_name: str, snapshot_name: str, **kwargs):
        """
        This method is for create snapshot.
        @param instance_name: name of the instance for which you want to create the snaphsot
        @param snapshot_name: specify name of the snapshot instance
        @param kwargs:
        @return: details of the snapshot created for your instance
        """
        try:
            logging.info(F"Creating DB Snapshot for Instance {instance_name} with snapshot_name {snapshot_name}")
            db_snapshot = self.client.create_db_snapshot(DBSnapshotIdentifier=snapshot_name,
                                                         DBInstanceIdentifier=instance_name, **kwargs)
            time.sleep(10)
            assert db_snapshot, f"Failed to create DB snapshot"

            for _ in range(10):
                db_snapshot_info = self.client.describe_db_snapshots(DBInstanceIdentifier=instance_name, SnapshotType='manual', **kwargs)
                logging.info(f"Current status of Snapshot is: {db_snapshot_info['DBSnapshots'][0]['Status']}")
                if db_snapshot_info['DBSnapshots'][0]['Status'] == 'available':
                    logging.info(f"Status of the Snapshot is: {db_snapshot_info['DBSnapshots'][0]['Status']}")
                    break
                time.sleep(20)
            else:
                raise Exception(
                    "Instance not available after 200 sec. If the instance size is large, it will take time to create "
                    "the snapshot. you can check the status of the snapshot")
            print(
                Fore.GREEN + f"DB Instance  - {db_snapshot_info['DBSnapshots'][0]['DBSnapshotIdentifier']} is "
                             f"available to use" + Style.RESET_ALL)
            return db_snapshot_info['DBSnapshots'][0]['DBSnapshotIdentifier']

        except Exception as err:
            logging.error(f"Unable to create Snapshot information. Error - {err}")

    def restore_db(self, instance_name: str, snapshot_name: str, **kwargs):
        """
        This method is to restore snapshot and create new instance.
        @param instance_name: name of the new instance which you want to specify for the restored snapshot
        @param snapshot_name: name of the snapshot you want to restore
        @param kwargs:
        @return: the new instance from the snapshot
        """
        try:
            logging.info("restoring db from snapshot " + str(snapshot_name))
            db_instance = self.client.restore_db_instance_from_db_snapshot(DBInstanceIdentifier=instance_name,
                                                                           DBSnapshotIdentifier=snapshot_name, **kwargs)
            assert db_instance, f"Failed to restore snapshot"

            for _ in range(12):
                db_instance_info = self.client.describe_db_instances(DBInstanceIdentifier=instance_name)
                if db_instance_info['DBInstances'][0]['DBInstanceStatus'] == 'creating':
                    logging.info(
                        f"Current status of DB instance is: {db_instance_info['DBInstances'][0]['DBInstanceStatus']}")
                    break
                time.sleep(5)
            else:
                raise Exception(
                    "Unable to create your server.... Please check the instance state or on console")
            for _ in range(48):
                db_instance_info = self.client.describe_db_instances(DBInstanceIdentifier=instance_name)
                if db_instance_info['DBInstances'][0]['DBInstanceStatus'] == 'backing-up':
                    logging.info(
                        f"Current status of DB instance is: {db_instance_info['DBInstances'][0]['DBInstanceStatus']}")
                    break
                time.sleep(5)
            else:
                raise Exception(
                    "Unable to backup your server.... Please check the instance state or on console")
            for _ in range(48):
                db_instance_info = self.client.describe_db_instances(DBInstanceIdentifier=instance_name)
                if db_instance_info['DBInstances'][0]['DBInstanceStatus'] == 'Modifying':
                    logging.info(
                        f"Current status of DB instance is: {db_instance_info['DBInstances'][0]['DBInstanceStatus']}")
                    break
                time.sleep(5)
            else:
                raise Exception(
                    "Unable to modify your server.... Please check the instance state or on console")
            for _ in range(48):
                db_instance_info = self.client.describe_db_instances(DBInstanceIdentifier=instance_name)
                if db_instance_info['DBInstances'][0]['DBInstanceStatus'] == 'available':
                    logging.info(
                        f"Current status of the DB Instance is: {db_instance_info['DBInstances'][0]['DBInstanceStatus']}")
                    break
                time.sleep(5)
            else:
                raise Exception(
                    "Restore snapshot is not completed. If the instance size is large, it will take time "
                    "to spinup the instance. you can check the status of the instance")
            print(
                Fore.GREEN + f"DB Instance  - {db_instance['DBInstance']['DBInstanceIdentifier']} is available to use" + Style.RESET_ALL)
            return db_instance['DBInstance']['DBInstanceIdentifier']
        except Exception as err:
            print(Fore.RED)
            logging.error(err)
            logging.error(f"Failed to restore db snapshot with error: {err}")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def delete_snapshot(self, snapshot_name: str):
        """
        This method is to delete snapshot.
        @param snapshot_name: name of the snapshot you want to delete
        """
        try:
            logging.info(f"removing snapshot {snapshot_name}")
            del_snapshot = self.client.delete_db_snapshot(DBSnapshotIdentifier=snapshot_name)
            assert del_snapshot, f"Failed to delete snapshot"
            return "Delete snapshot initiated...Your snapshot will be deleted shortly"
        except Exception as err:
            logging.error(f"Unable to remove Snapshot. Error - {err}")
            return "Unable to remove Snapshot."


def main():
    # Common Parsers
    parent_parser = argparse.ArgumentParser(add_help=False)
    parent_parser.add_argument("--instance_name", type=str,
                               help="Name of the instance" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                               default=argparse.SUPPRESS,
                               required=True)
    parser = argparse.ArgumentParser()
    rds_method_subparser = parser.add_subparsers(dest='rds_method')

    # Create RDS instance
    create_rds_method_subparser = rds_method_subparser.add_parser("create-rds-instance",
                                                                  help="Create new RDS Instance")
    create_rds_method_subparser.add_argument("--storage", type=int,
                                             help="The allocated storage size for the DB instance specified in "
                                                  "gibibytes (GiB)" + Fore.RED + " [REQUIRED]" +
                                                  Style.RESET_ALL)
    create_rds_method_subparser.add_argument("--instance_class", type=str,
                                             help="Contains the name of the compute and memory capacity class of the "
                                                  "DB instance." + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                             default=argparse.SUPPRESS, required=True)
    create_rds_method_subparser.add_argument("--instance_name", type=str,
                                             help="The database identifier for the DB instance" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL)
    create_rds_method_subparser.add_argument("--db_engine", type=str,
                                             help="The name of the database engine to be used for this DB instance. "
                                                  "e.g mysql, SQL Server" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL)
    create_rds_method_subparser.add_argument("--username", type=str,
                                             help="Username of the DB" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL)
    create_rds_method_subparser.add_argument("--password", type=str,
                                             help="Master Password for your DB" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL)
    create_rds_method_subparser.add_argument("--dbsecuritygrp", type=list,
                                             help="Security group your DB", default=argparse.SUPPRESS)
    create_rds_method_subparser.add_argument("--vpcsecuritygrpid", type=list,
                                             help="VPC Security group ID your DB", default=argparse.SUPPRESS)
    create_rds_method_subparser.add_argument("--az", type=list,
                                             help="Availability group for your DB", default=argparse.SUPPRESS)
    create_rds_method_subparser.add_argument("--dbsubnetgrpname", type=list,
                                             help="Security group name your DB", default=argparse.SUPPRESS)
    create_rds_method_subparser.add_argument("--port", type=int,
                                             help="port number for DB", default=argparse.SUPPRESS)
    create_rds_method_subparser.add_argument("--multiaz", type=bool,
                                             help="You can make as true is you want multi AZ for your DB",
                                             default=argparse.SUPPRESS)
    create_rds_method_subparser.add_argument("--dbversion", type=str,
                                             help="DB version", default=argparse.SUPPRESS)
    create_rds_method_subparser.add_argument("--storagetype", type=str,
                                             help="Define storage type for your DB", default=argparse.SUPPRESS)
    create_rds_method_subparser.add_argument("--email", type=str,
                                             help="Specify email ID to send email notification (Multiple "
                                                  "comma-separated email IDs are acceptable)",
                                             default=argparse.SUPPRESS)

    # Delete RDS Instance
    delete_rds_method_subparser = rds_method_subparser.add_parser("delete-rds-instance",
                                                                  help="Delete RDS Instance")
    delete_rds_method_subparser.add_argument("--instance_name", type=str,
                                             help="The database identifier for the DB instance" + Fore.RED + " [REQUIRED]" +
                                                  Style.RESET_ALL)
    delete_rds_method_subparser.add_argument("--skipfinalsnapshot", type=bool,
                                             help="A value that indicates whether to skip the creation of a final DB "
                                                  "snapshot before deleting the instance." + Fore.RED + " [REQUIRED]"
                                                  + Style.RESET_ALL)
    delete_rds_method_subparser.add_argument("--finaldbsnapshotidentifier", type=str,
                                             help="The DBSnapshotIdentifier of the new DBSnapshot created when the "
                                                  "SkipFinalSnapshot parameter is disabled.",
                                             default=argparse.SUPPRESS)
    delete_rds_method_subparser.add_argument("--email", type=str,
                                             help="Specify email ID to send email notification (Multiple "
                                                  "comma-separated email IDs are acceptable)",
                                             default=argparse.SUPPRESS)

    # Get RDS Instance Information
    get_rds_info_parser = rds_method_subparser.add_parser("db-info", parents=[parent_parser],
                                                          help="Describe Instance Info")
    get_rds_info_parser.add_argument("--MaxRecords", "--max-record", type=int,
                                     help="Reserved.", default=argparse.SUPPRESS)
    get_rds_info_parser.add_argument("--email", type=str,
                                             help="Specify email ID to send email notification (Multiple "
                                                  "comma-separated email IDs are acceptable)",
                                             default=argparse.SUPPRESS)

    # STOP Instance Commands
    stop_rds_parser = rds_method_subparser.add_parser("stop", parents=[parent_parser],
                                                      help="Method will stop the DB instance if it is in running state")
    stop_rds_parser.add_argument("--email", type=str,
                                          help="Specify email ID to send email notification (Multiple "
                                               "comma-separated email IDs are acceptable)",
                                          default=argparse.SUPPRESS)

    # Start Instance Commands
    start_rds_parser = rds_method_subparser.add_parser("start", parents=[parent_parser],
                                                       help="Method will start the DB instance if it is in stopped state")
    start_rds_parser.add_argument("--email", type=str,
                                 help="Specify email ID to send email notification (Multiple "
                                      "comma-separated email IDs are acceptable)",
                                 default=argparse.SUPPRESS)

    # Reboot Instance Commands
    reboot_rds_parser = rds_method_subparser.add_parser("reboot", parents=[parent_parser],
                                                       help="Method will reboot the DB instance")
    reboot_rds_parser.add_argument("--failover", type=bool,
                                   help="the value should be True or False only if the DB instance is multi AZ",
                                   default=argparse.SUPPRESS)
    reboot_rds_parser.add_argument("--email", type=str,
                                  help="Specify email ID to send email notification (Multiple "
                                       "comma-separated email IDs are acceptable)",
                                  default=argparse.SUPPRESS)

    # List All Instance
    list_instances_parser = rds_method_subparser.add_parser("list-instances",
                                                            help="List all instances available")

    # Create DB Snapshot
    snapshot_rds_method_parser = rds_method_subparser.add_parser("create-rds-snapshot",
                                                                    help="Create snapshot of the DB")
    snapshot_rds_method_parser.add_argument("--instance_name", type=str,
                                               help="Name of the instance of which snapshot needs to be taken" + Fore.RED + " [REQUIRED]" +
                                                    Style.RESET_ALL)
    snapshot_rds_method_parser.add_argument("--snapshot_name", type=str,
                                               help="Name needs to be provided to snapshot" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL)
    snapshot_rds_method_parser.add_argument("--email", type=str,
                                  help="Specify email ID to send email notification (Multiple "
                                       "comma-separated email IDs are acceptable)",
                                  default=argparse.SUPPRESS)

    # Restore DB Snapshot
    restore_snapshot_rds_method_parser = rds_method_subparser.add_parser("restore-rds-snapshot",
                                                                            help="Restore snapshot of the DB and "
                                                                                 "create new instance")
    restore_snapshot_rds_method_parser.add_argument("--instance_name", type=str,
                                                       help="Name of the new instance on which snapshot needs to be "
                                                            "restored e.g snapshot-restore" + Fore.RED + " [REQUIRED]" +
                                                            Style.RESET_ALL)
    restore_snapshot_rds_method_parser.add_argument("--snapshot_name", type=str,
                                                       help="Name needs to be provided to snapshot" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL)
    restore_snapshot_rds_method_parser.add_argument("--email", type=str,
                                               help="Specify email ID to send email notification (Multiple "
                                                    "comma-separated email IDs are acceptable)",
                                               default=argparse.SUPPRESS)

    #delete created snapshot
    delete_snapshot_rds_method_parser = rds_method_subparser.add_parser("delete-rds-snapshot",
                                                                            help="Delete snapshot of the DB")
    delete_snapshot_rds_method_parser.add_argument("--snapshot_name", type=str,
                                                       help="Name of the snapshot which needs to be delete" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL)
    delete_snapshot_rds_method_parser.add_argument("--email", type=str,
                                                       help="Specify email ID to send email notification (Multiple "
                                                            "comma-separated email IDs are acceptable)",
                                                       default=argparse.SUPPRESS)

    # Get RDS Instance Status
    instance_status_info_parser = rds_method_subparser.add_parser("rds-instance-state", parents=[parent_parser],
                                                                  help="Describe Instance State")
    instance_status_info_parser.add_argument("--MaxRecords", "--max-record", type=int,
                                             help="Reserved.", default=argparse.SUPPRESS)
    instance_status_info_parser.add_argument("--email", type=str,
                                             help="Specify email ID to send email notification (Multiple "
                                                  "comma-separated email IDs are acceptable)",
                                             default=argparse.SUPPRESS)

    # Get RDS Snapshot Details
    rds_snapshot_info_parser = rds_method_subparser.add_parser("rds-snapshot-info", parents=[parent_parser],
                                                                  help="Describe RDS Snapshot Info")
    rds_snapshot_info_parser.add_argument("--snapshot_type", type=str,
                                          help="specify snapshot type)"
                                               + Fore.RED + " [REQUIRED]" + Style.RESET_ALL)
    rds_snapshot_info_parser.add_argument("--email", type=str,
                                             help="Specify email ID to send email notification (Multiple "
                                                  "comma-separated email IDs are acceptable)",
                                             default=argparse.SUPPRESS)

    # List All RDS Snapshot
    list_snapshot_parser = rds_method_subparser.add_parser("list-snapshot",
                                                            help="List all Snapshot available")

    args = parser.parse_args()
    if not args.rds_method:
        parser.print_help()
        return
    parse_args_to_execute(args)


@send_email("RDS", "rds_method")
def parse_args_to_execute(args, config_data=None):
    if args.rds_method and config_data:
        rds_obj = RDS(config_data, command_line=True)
        args_dict = vars(args)
        if args.rds_method == "create-rds-instance":
            del args_dict['rds_method']
            return rds_obj.create_db(**args_dict)
        elif args.rds_method == "delete-rds-instance":
            del args_dict['rds_method']
            return rds_obj.delete_db_instance(**args_dict)
        elif args.rds_method == "db-info":
            del args_dict['rds_method']
            return rds_obj.fetch_instance_info(**args_dict)
        elif args.rds_method == "stop":
            del args_dict['rds_method']
            return rds_obj.stop_validate_instance(**args_dict)
        elif args.rds_method == "reboot":
            del args_dict['rds_method']
            return rds_obj.reboot_validate_instance(**args_dict)
        elif args.rds_method == "start":
            del args_dict['rds_method']
            return rds_obj.start_validate_instance(**args_dict)
        elif args.rds_method == "list-instances":
            del args_dict['rds_method']
            rds_obj.list_all_instances()
        elif args.rds_method == "create-rds-snapshot":
            del args_dict['rds_method']
            return rds_obj.create_snapshot(**args_dict)
        elif args.rds_method == "restore-rds-snapshot":
            del args_dict['rds_method']
            return rds_obj.restore_db(**args_dict)
        elif args.rds_method == "rds-instance-state":
            del args_dict['rds_method']
            return rds_obj.check_rds_instance_status(**args_dict)
        elif args.rds_method == "delete-rds-snapshot":
            del args_dict['rds_method']
            return rds_obj.delete_snapshot(**args_dict)
        elif args.rds_method == "rds-snapshot-info":
            del args_dict['rds_method']
            return rds_obj.fetch_db_snapshot(**args_dict)
        elif args.rds_method == "list-snapshot":
            del args_dict['rds_method']
            rds_obj.list_db_snapshot()


if __name__ == '__main__':
    main()
