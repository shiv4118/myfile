#!/usr/bin/env python3
import argparse
import json
import logging
import sys
import os
import datetime
import logging.handlers

import boto3
from botocore.exceptions import ClientError
from colorama import Fore, Style
from prettytable import PrettyTable

from email_notifications import send_email
from constants import *


class IAM:

    def __init__(self, config, command_line=False):

        self.iam_client = boto3.client(
            'iam', **config
        )
        self.config = config
        self.command_line = command_line
        if command_line:
            home_dir = os.path.expanduser("~")
            # logging.basicConfig(level=logging.INFO, format='%(message)s')
            # sys.tracebacklimit = 0
            cur_date = datetime.datetime.now().strftime("%d_%b_%Y")
            log_dir_path = os.path.join(home_dir, ".a4cloudstack_logs")
            final_log_path = log_dir_path + "/log_" + cur_date
            if not os.path.exists(final_log_path):
                os.makedirs(final_log_path, mode=0o777, exist_ok=True)
            logging.getLogger().setLevel(logging.NOTSET)
            console = logging.StreamHandler(sys.stdout)
            console.setLevel(logging.INFO)
            formater = logging.Formatter('%(message)s')
            console.setFormatter(formater)
            logging.getLogger().addHandler(console)

            # Add file rotating handler, with level DEBUG
            rotatingHandler = logging.handlers.RotatingFileHandler(filename=final_log_path + "/" + 'iam.log',
                                                                   maxBytes=100000, backupCount=5)
            rotatingHandler.setLevel(logging.INFO)
            formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
            rotatingHandler.setFormatter(formatter)
            logging.getLogger().addHandler(rotatingHandler)
            sys.tracebacklimit = 0

    def create_user(self, user_name: str, **kwargs):
        """
        Method to create new IAM user.
        :param user_name: New user name
        :param kwargs: PermissionsBoundary/Tags/Path
        :return: user_response
        """
        try:
            user_response = self.iam_client.create_user(UserName=user_name, **kwargs)
            return user_response
        except ClientError as err:
            print(Fore.RED)
            if err.response['Error']['Code'] == "EntityAlreadyExists":
                logging.info(Fore.RED + f"User: '{user_name}' is already Exist" + Style.RESET_ALL)
            elif err.response['Error']['Code'] == "InvalidInput":
                logging.info(Fore.RED + f"User: '{user_name}' creation failed, Invalid parameters" + Style.RESET_ALL)
            else:
                logging.info(
                    Fore.RED + f"Create User failed with err: {err.response['Error']['Code']}" + Style.RESET_ALL)
                logging.error(err)
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def create_validate_user(self, user_name: str, **kwargs):
        """
        Function to Create user and validate user response
        :param user_name: New user.
        :param kwargs: PermissionsBoundary/Tags/Path
        """
        response = self.create_user(user_name, **kwargs)
        assert response, f"failed to create {user_name} user"
        assert response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (f"failed to verify response code. "
                                                                               f"Expected:'{RESPONSE_OK}' but, found"
                                                                               f"'{response['ResponseMetadata']['HTTPStatusCode']}'") + Style.RESET_ALL
        logging.info(Fore.GREEN + f"User '{user_name}' created successfully" + Style.RESET_ALL)
        return response

    def list_validate_user(self, user_name: str = ""):
        """
        Function to validate if user exist in the user list or not.
        :param user_name: User name
        :return: user_list
        """
        users_list = []
        users = self.list_user()
        assert users, Fore.RED + f"Error in listing users: {users}" + Style.RESET_ALL
        for user in users:
            users_list.append(user["UserName"])
        if user_name:
            logging.info(f"Checking if user with user_name: {user_name} in IAM user list")
            try:
                assert user_name in users_list
                logging.info(Fore.GREEN + f"User: {user_name} present in IAM user list." + Style.RESET_ALL)
            except Exception as e:
                logging.info(Fore.RED + f"User: {user_name} is not in IAM User list." + Style.RESET_ALL)
        else:
            logging.info("Listing all the Users Name.")
            for user in users_list:
                logging.info(user)
            return users_list

    def list_user(self, user_name: str = ""):
        """
        Method to list metadata of all and single user
        :param user_name: username of specific user, Default value 'None'
        :return: user_list, user
        """
        if user_name:
            user = self.iam_client.get_user(UserName=user_name)
            return user
        else:
            user_list = self.iam_client.list_users()["Users"]
            return user_list

    def delete_user_validate(self, user_name: str):
        """
        Method to validate delete user response
        :param user_name: user name
        """
        delete_resp = self.delete_user(user_name)
        assert delete_resp, f"Failed to delete '{user_name}' User"
        assert delete_resp['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Failed to verify response code, Expected: '{RESPONSE_OK}' but,found"
            f" '{delete_resp['ResponseMetadata']['HTTPStatusCode']}'")
        user_list = self.list_user()
        assert user_name not in user_list, f"Failed to delete '{user_name}' User"
        logging.info(Fore.GREEN + f"User '{user_name}' deleted successfully" + Style.RESET_ALL)
        if self.command_line:
            del_msg = f"User {user_name} deleted successfully."
            return del_msg

    def delete_user(self, user_name: str):
        """
        Method to delete user.
        :param user_name: user name to be deleted.
        :return: delete_user_resp
        """
        try:
            delete_user_resp = self.iam_client.delete_user(UserName=user_name)
            return delete_user_resp
        except ClientError as err:
            print(Fore.RED)
            logging.error(err)
            logging.error(
                f"Failed to Delete '{user_name}' user with error: {err.response['Error']['Code']}"
            )
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def create_role_validate(self, role_name: str, role_document: dict, negative_case: bool = False, **kwargs):
        """
        Method to create role and validate api response.
        :param role_name: New role name.
        :param role_document: Assume role policy document.
        :param negative_case: for negative TC scenario.
        :param kwargs: Path/Description/MaxSessionDuration/PermissionsBoundary/Tags.
        """

        role_response = self.create_role(role_name, role_document, **kwargs)
        if negative_case:
            assert not role_response, f"{role_name} role created which is unexpected. Output {role_response}."
            logging.info(f"Failed to create Role '{role_name}'")

        else:
            assert role_response, f"failed to create {role_name} Role"
            assert role_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
                f"failed to verify response code. Expected:'{RESPONSE_OK}',but found"
                f"'{role_response['ResponseMetadata']['HTTPStatusCode']}'"
            )
            assert self.iam_client.get_role(RoleName=role_name)['Role']['RoleName'] == role_name, (
                f"failed to create {role_name} Role"
            )
            logging.info(Fore.GREEN + f"Role '{role_name}' created successfully" + Style.RESET_ALL)
        return role_response

    def create_role(self, role_name: str, role_document: dict, **kwargs):

        """
        Method to create IAM role
        :param role_name: New role name
        :param role_document: Assume role policy document
        :param kwargs: Path/Description/MaxSessionDuration/PermissionsBoundary/Tags
        :return: role_response
        """
        try:
            role_response = self.iam_client.create_role(
                RoleName=role_name, AssumeRolePolicyDocument=json.dumps(role_document), **kwargs
            )
            return role_response
        except ClientError as err:
            print(Fore.RED)
            if err.response['Error']['Code'] == "EntityAlreadyExists":
                logging.info(f"Role: '{role_name}' already Exist")
            else:

                logging.info(f"Create role failed with err: {err.response['Error']['Code']}")
                logging.error(err)
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def list_roles(self, **kwargs):
        """
        Lists the IAM roles.
        """
        try:
            list_role_response = self.iam_client.list_roles(**kwargs)
            mytable = PrettyTable(["Role Name", "Role ID"])
            for role in list_role_response["Roles"]:
                mytable.add_row([role['RoleName'], role['RoleId']])
            mytable.hrules = 1
            print("\n".join(mytable.get_string().splitlines()))
        except ClientError as err:
            print(Fore.RED)
            logging.info(f"List roles failed with error: {err.response['Error']['Code']}")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def check_role_info(self, role_name: str):
        """
        Method to fetch role information
        :param role_name: New role name
        """
        try:
            list_role_response = self.iam_client.get_role(RoleName=role_name)
            roles_info = list_role_response.get("Role", {})
            last_used_info = list_role_response.get("RoleLastUsed", {})
            if self.command_line:
                print(f"Role Name                   : {roles_info.get('RoleName', 'NA')}\n"
                      f"Role ID                     : {roles_info.get('RoleId', 'NA')}\n"
                      f"ARN                         : {roles_info.get('Arn', 'NA')}\n"
                      f"Path                        : {roles_info.get('Path', 'NA')}\n"
                      f"Description                 : {roles_info.get('Description', 'NA')}\n"
                      f"Assume Role Policy Document : {roles_info.get('AssumeRolePolicyDocument', 'NA')}\n"
                      f"Permissions Boundary        : {roles_info.get('PermissionsBoundary', 'NA')}\n"
                      f"MaxSession Duration         : {roles_info.get('MaxSessionDuration', 'NA')}\n"
                      f"Tags                        : {list_role_response.get('Tags', 'NA')}\n"
                      f"Region                      : {last_used_info.get('Region', 'NA')}\n"
                      f"Create Date                 : {roles_info.get('CreateDate', 'NA')}\n"
                      f"Last Used                   : {last_used_info.get('LastUsedDate', 'NA')}\n")
                return list_role_response
        except ClientError as err:
            print(Fore.RED)
            logging.info(f"Unable to fetch role details: {err.response['Error']['Code']}")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def list_role_instance_profiles(self, role_name: str):
        """
        Lists the instance profiles that have the specified associated IAM role
        :param role_name: New role name
        """
        all_instance_prof_list = []
        try:
            instance_prof_role_response = self.iam_client.list_instance_profiles_for_role(RoleName=role_name)
            if self.command_line and instance_prof_role_response['InstanceProfiles']:
                for instance_profile in instance_prof_role_response['InstanceProfiles']:
                    instance_profile_tup = (
                        instance_profile['InstanceProfileName'], instance_profile['InstanceProfileId']
                        , instance_profile['Arn'])
                    all_instance_prof_list.append(instance_profile_tup)

                for profile in all_instance_prof_list:
                    print(f"Instance Profile  Name                   : {profile[0]}\n"
                          f"Instance Profile  ID                     : {profile[1]}\n"
                          f"Instance Profile  ARN                    : {profile[2]}\n")
            else:
                print(Fore.YELLOW + f"No Instance Profiles are attached to the role - {role_name}" + Style.RESET_ALL)
        except ClientError as err:
            print(Fore.RED)
            logging.info(f"Unable to fetch instance profile details: {err}")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def list_role_policies(self, role_name: str):
        """
        Lists all managed policies that are attached to the specified IAM role.
        :param role_name: New role name
        """
        try:
            attached_policies_role_response = self.iam_client.list_attached_role_policies(RoleName=role_name)
            if self.command_line and attached_policies_role_response['AttachedPolicies']:
                print("Policy Name\t\t\tPolicy ARN")
                for policy in attached_policies_role_response['AttachedPolicies']:
                    print(f"{policy['PolicyName']}\t\t\t{policy['PolicyArn']}")
            else:
                print(Fore.YELLOW + f"No Policies are attached to the role - {role_name}" + Style.RESET_ALL)
            return attached_policies_role_response
        except ClientError as err:
            print(Fore.RED)
            logging.info(f"Unable to fetch attached policies to the role: {err}")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def delete_role_validate(self, role_name: str):
        """
        Method to delete role and validate api response
        :role_name: Existing role name.
        """

        delete_resp = self.delete_role(role_name)
        assert delete_resp, f"Failed to delete '{role_name}' Role"
        assert delete_resp['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Failed to verify response code, Expected: '{RESPONSE_OK}'but, found"
            f"'{delete_resp['ResponseMetadata']['HTTPStatusCode']}'"
        )
        role_list = [role['RoleName'] for role in self.iam_client.list_roles()['Roles']]
        assert role_name not in role_list, f"Failed to delete '{role_name}' Role. Existing role: {role_list}"
        logging.info(Fore.GREEN + f"Role '{role_name}' deleted successfully" + Style.RESET_ALL)
        if self.command_line:
            return f"Role '{role_name}' deleted successfully"

    def delete_role(self, role_name: str):
        """
        Method to delete role.
        :Param role_name: Existing role name.
        :return: delete_role_resp.
        """
        try:
            delete_role_resp = self.iam_client.delete_role(RoleName=role_name)
            return delete_role_resp
        except ClientError as err:
            print(Fore.RED)
            logging.error(err)
            logging.error(
                f"Failed to Delete {role_name} role with error: {err.response['Error']['Code']}")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def create_policy_validate(self, policy_name: str, policy_document: dict, **kwargs):
        """
        Method to validate create policy api response.
        :param policy_name: New policy name.
        :param policy_document: Json document to create policy with certain access rules.
        :param kwargs: Path/Description.
        :return validate_response.
        """
        validate_response = self.create_policy(policy_name, policy_document, **kwargs)
        assert validate_response, f"failed to create policy '{policy_name}' "
        assert validate_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected: '{RESPONSE_OK}' but, found"
            f"'{validate_response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        assert self.list_policy(policy_name)['PolicyName'] == policy_name, f"failed to create policy '{policy_name}'"
        logging.info(Fore.GREEN + f"Policy '{policy_name}' created successfully" + Style.RESET_ALL)
        return validate_response

    def create_policy(self, policy_name: str, policy_document: dict, **kwargs):
        """
        Method to create policy.
        :param policy_name: new policy name.
        :param policy_document: new policy document.
        :param kwargs: Path/Description.
        :return: policy_response.
        """
        try:
            policy_response = self.iam_client.create_policy(
                PolicyName=policy_name, PolicyDocument=json.dumps(policy_document), **kwargs
            )
            return policy_response
        except ClientError as err:
            print(Fore.RED)
            if err.response['Error']['Code'] == "EntityAlreadyExists":
                logging.info(f" Policy with name '{policy_name}' already exist")
            else:
                logging.info(f"Create Policy failed listing with err: {err.response['Error']['Code']}")
            logging.error(err)
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def list_policy(self, policy_name: str = "", list_all: bool = False):
        """
        Method to return policy list.
        :param policy_name: Existing Policy name
        :param list_all: list all policies on terminal
        :return: list_policy_response.
        """
        list_policy_response = self.iam_client.list_policies(MaxItems=1000)['Policies']
        if policy_name:
            for policy in list_policy_response:
                if policy_name == policy['PolicyName']:
                    if self.command_line:
                        print(f"Policy Name                     : {policy['PolicyName']}\n"
                              f"Policy ID                       : {policy['PolicyId']}\n"
                              f"ARN                             : {policy['Arn']}\n"
                              f"Path                            : {policy['Path']}\n"
                              f"Default Version Id              : {policy['DefaultVersionId']}\n"
                              f"Attachment Count                : {policy['AttachmentCount']}\n"
                              f"Permissions Boundary Usage Count: {policy['PermissionsBoundaryUsageCount']}\n"
                              f"Is Attachable                   : {policy['IsAttachable']}\n"
                              f"Create Date                     : {policy['CreateDate']}\n"
                              f"Update Date                     : {policy['UpdateDate']}\n")
                    else:
                        logging.info(policy)
                    return policy
        elif list_all:
            mytable = PrettyTable(["Policy Name", "Policy ID"])
            for policy in list_policy_response:
                mytable.add_row([policy['PolicyName'], policy['PolicyId']])
            mytable.hrules = 1
            print("\n".join(mytable.get_string().splitlines()))
        else:
            return list_policy_response

    def attach_policy_role_validate(self, policy_arn: str, role_name: str):
        """
        Method to attach policy to role and validate api response.
        :param policy_arn: Policy amazon resource number.
        :param role_name: role to attach with policy
        """
        attach_role_policy_response = self.attach_policy_role(policy_arn, role_name)
        assert attach_role_policy_response, f"failed to attach policy to role '{role_name}'"
        assert attach_role_policy_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected: '{RESPONSE_OK}' but, found"
            f"'{attach_role_policy_response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        policy_list = [policy['PolicyArn'] for policy in self.iam_client.list_attached_role_policies(
            RoleName=role_name)['AttachedPolicies']]
        assert policy_arn in policy_list, f"failed to attach policy to role '{role_name}'"
        logging.info(
            Fore.GREEN + f"Policy '{policy_arn}' attached to role '{role_name}' successfully" + Style.RESET_ALL)
        if self.command_line:
            return attach_role_policy_response

    def attach_policy_role(self, policy_arn: str, role_name: str):
        """
        Method to attach policy role.
        :param policy_arn: Policy amazon resource number.
        :param role_name: role to attach with policy
        :return: attach_role_policy_response.
        """
        try:
            attach_role_policy_response = self.iam_client.attach_role_policy(PolicyArn=policy_arn, RoleName=role_name)
            return attach_role_policy_response
        except ClientError as err:
            print(Fore.RED)
            if err.response['Error']['Code'] == "NoSuchEntity":
                logging.info(f"Policy or role  does not Exist")
            else:
                logging.info(f"Attach Policy to role failed listing with err: {err.response['Error']['Code']}")
                logging.error(err)
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def detach_role_policy_validate(self, role_name: str, policy_arn: str):
        """
        Method to Validate detach_role_policy response.
        :param role_name: role name.
        :param policy_arn: policy amazon resource number.
        """
        detach_role_policy_response = self.detach_role_policy(role_name, policy_arn)
        assert detach_role_policy_response, f"failed to detach role '{role_name}' from policy: '{policy_arn}'"
        assert detach_role_policy_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected: '{RESPONSE_OK}' but found"
            f"'{detach_role_policy_response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        policy_list = [policy['PolicyArn'] for policy in self.iam_client.list_attached_role_policies(
            RoleName=role_name)['AttachedPolicies']]
        assert policy_arn not in policy_list, f"failed to detach role: '{role_name}' from policy: '{policy_arn}'"
        logging.info(
            Fore.GREEN + f"Policy '{policy_arn}' detached from role '{role_name}' successfully." + Style.RESET_ALL)
        if self.command_line:
            return detach_role_policy_response

    def detach_role_policy(self, role_name: str, policy_arn: str):
        """
        Method to detach role from policy.
        :param role_name: attached role name.
        :param policy_arn: policy attached resource number.
        :return: detach_role_policy_response.
        """
        try:
            detach_role_policy_response = self.iam_client.detach_role_policy(RoleName=role_name, PolicyArn=policy_arn)
            return detach_role_policy_response
        except ClientError as err:
            print(Fore.RED)
            if err.response['Error']['Code'] == "NoSuchEntityException":
                logging.info(f"No such entity exist '{role_name}'/'{policy_arn}', role detach failed.")
            elif err.response['Error']['Code'] == "InvalidInputException":
                logging.info(f"Invalid Input, policy detach failed.")
            elif err.response['Error']['Code'] == "UnmodifiableEntityException":
                logging.info(f"Access denied, Can't detach role")
            else:
                logging.info(f"detach role from policy failed, listing with err: {err.response['Error']['Code']}")
            logging.error(err)
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def attach_user_policy(self, user_name: str, policy_arn: str):
        """
        Method to attach policy to user.
        :param user_name: IAM user name
        :param policy_arn: Policy amazon resource number.
        :return: attach_user_policy_response.
        """
        try:
            attach_user_policy_response = self.iam_client.attach_user_policy(UserName=user_name, PolicyArn=policy_arn)
            return attach_user_policy_response
        except ClientError as err:
            print(Fore.RED)
            if err.response['Error']['Code'] == "NoSuchEntityException":
                logging.info(f"No such entity found '{user_name}'/'{policy_arn}', policy to user attachment failed")
            elif err.response['Error']['Code'] == "PolicyNotAttachableException":
                logging.info(f"Can't attach  policy to user, attachment failed")
            else:
                logging.info(f"attach policy to user failed, listing with err: {err.response['Error']['Code']}")
            logging.error(err)
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def attach_user_policy_validate(self, user_name: str, policy_arn: str):
        """
        Method to validate attach_user_policy Response.
        :param user_name: IAM user_name
        :param policy_arn: Policy amazon resource number.
        """

        attach_user_policy_response = self.attach_user_policy(user_name, policy_arn)
        assert attach_user_policy_response, f"failed to attach user '{user_name}' to policy '{policy_arn}'"
        assert attach_user_policy_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected: '{RESPONSE_OK}' but, found"
            f"'{attach_user_policy_response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        policy_list = [policy['PolicyArn'] for policy in self.iam_client.list_attached_user_policies(
            UserName=user_name)['AttachedPolicies']]
        assert policy_arn in policy_list, f"failed to attach user '{user_name}' to policy '{policy_arn}'"
        logging.info(
            Fore.GREEN + f"Role '{policy_arn}' attached to user with user name:'{user_name}' successfully'" + Style.RESET_ALL)
        if self.command_line:
            return attach_user_policy_response

    def detach_user_policy(self, user_name: str, policy_arn: str):
        """
        Method to detach policy from user.
        :param user_name: IAM user_name
        :param policy_arn: Policy amazon resource number.
        :return: detach_user_policy_response.
        """
        try:
            detach_user_policy_response = self.iam_client.detach_user_policy(UserName=user_name, PolicyArn=policy_arn)
            return detach_user_policy_response
        except ClientError as err:
            print(Fore.RED)
            if err.response['Error']['Code'] == "NoSuchEntityException":
                logging.info(f"No such entity exist '{user_name}'/'{policy_arn}', policy detach failed.")
            elif err.response['Error']['Code'] == "InvalidInputException":
                logging.info(f"Invalid Input, policy detach failed.")
            else:
                logging.info(f"detach role to policy failed, listing with err: {err.response['Error']['Code']}")
            logging.error(err)
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def detach_user_policy_validate(self, user_name: str, policy_arn: str):
        """
        Method to validate detach_user_policy Response.
        :param user_name: IAM user_name
        :param policy_arn: Policy amazon resource number.
        """
        detach_user_policy_response = self.detach_user_policy(user_name, policy_arn)
        assert detach_user_policy_response, f"failed to detach user '{user_name}' to policy '{policy_arn}'"
        assert detach_user_policy_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected: '{RESPONSE_OK}' but,found "
            f"'{detach_user_policy_response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        policy_list = [policy['PolicyArn'] for policy in self.iam_client.list_attached_user_policies(
            UserName=user_name)['AttachedPolicies']]
        assert policy_arn not in policy_list, f"failed to detach user '{user_name}' to policy '{policy_arn}'"
        logging.info(
            Fore.GREEN + f"Policy '{policy_arn}' detached from user with user name '{user_name}' successfully'" + Style.RESET_ALL)
        return detach_user_policy_response

    def delete_policy(self, policy_arn: str):
        """
        Method  to delete policy.
        :param policy_arn: policy amazon resource number.
        :return: delete_policy_response.
        """
        try:
            delete_policy_response = self.iam_client.delete_policy(PolicyArn=policy_arn)
            return delete_policy_response
        except ClientError as err:
            print(Fore.RED)
            logging.error(err)
            logging.error(
                f"Failed to Delete policy '{policy_arn}' role with error: {err.response['Error']['Code']}")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def delete_policy_validate(self, policy_arn: str):
        """
        Method to validate delete_policy response
        :param policy_arn: policy amazon resource number.
        """
        delete_policy_response = self.delete_policy(policy_arn)
        assert delete_policy_response, f"failed to delete policy '{policy_arn}'."
        assert delete_policy_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected: '{RESPONSE_OK}' but,found "
            f"'{delete_policy_response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        policy_list = [policy['Arn'] for policy in self.iam_client.list_policies()['Policies']]
        assert policy_arn not in policy_list, f"failed to delete policy '{policy_arn}'."
        logging.info(Fore.GREEN + f"Policy '{policy_arn}' deleted successfully'" + Style.RESET_ALL)
        if self.command_line:
            return delete_policy_response

    def create_instance_profile(self, instance_profile_name: str):
        """
        Method to create Instance profile.
        :param instance_profile_name: new Instance_profile_name
        :return: create instance profile response
        """
        try:
            create_instance_profile_response = self.iam_client.create_instance_profile(
                InstanceProfileName=instance_profile_name
            )
            return create_instance_profile_response
        except ClientError as err:
            print(Fore.RED)
            logging.info(f"Instance profile creation failed, listing with err: {err.response['Error']['Code']}")
            logging.error(err)
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def create_instance_profile_validate(self, instance_profile_name: str):
        """
        Method to validate create_instance_profile response
        :param instance_profile_name: new Instance_profile_name
        """
        instance_profile_response = self.create_instance_profile(instance_profile_name)
        assert instance_profile_response, f"failed to create instance profile '{instance_profile_name}'."
        assert instance_profile_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected: '{RESPONSE_OK}' but, found "
            f"'{instance_profile_response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        instance_profile_list = [instance_profile['InstanceProfileName']
                                 for instance_profile in self.iam_client.list_instance_profiles()['InstanceProfiles']]
        assert instance_profile_name in instance_profile_list, (
            f"failed to create instance profile:'{instance_profile_name}'."
        )
        logging.info(Fore.GREEN + f"instance profile '{instance_profile_name}' created successfully'" + Style.RESET_ALL)
        return instance_profile_response

    def add_role_to_instance_profile(self, instance_profile_name: str, role_name: str):
        """
        Method to add role to instance profile
        :param instance_profile_name: instance profile name.
        :param role_name: role name.
        :return: add_role_response
        """

        try:
            add_role_response = self.iam_client.add_role_to_instance_profile(
                InstanceProfileName=instance_profile_name, RoleName=role_name
            )
            return add_role_response
        except ClientError as err:
            print(Fore.RED)
            logging.info(
                f"Role '{role_name}' add to Instance profile '{instance_profile_name}' failed,"
                f"listing with err: {err.response['Error']['Code']}")
            logging.error(err)
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def add_role_to_instance_profile_validate(self, instance_profile_name: str, role_name: str):
        """
        Method to validate add_role_to_instance_profile response.
        :param instance_profile_name: instance profile name.
        :param role_name: role name.
        :return: Instance profile ARN.
        """
        add_response = self.add_role_to_instance_profile(instance_profile_name, role_name)
        assert add_response, f"failed to add role '{role_name}' to instance profile '{instance_profile_name}'."
        assert add_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected: '{RESPONSE_OK}' but, found "
            f"'{add_response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        instance_profile_data = self.iam_client.get_instance_profile(
            InstanceProfileName=instance_profile_name)['InstanceProfile']
        assert instance_profile_data['Roles'][0]['RoleName'] == role_name, (
            f"failed to add role '{role_name}'to instance profile '{instance_profile_name}'"
        )
        logging.info(
            Fore.GREEN + f"role '{role_name}' added successfully to instance profile - {instance_profile_name}'" +
            f"\nInstance Profile ARN - {instance_profile_data['Arn']}" + Style.RESET_ALL)
        return instance_profile_data['Arn']

    def remove_role_instance_profile(self, instance_profile_name: str, role_name: str):
        """
        Method to remove role from instance profile
        :param instance_profile_name: instance profile name
        :param role_name: role name
        :return: remove_response
        """
        try:
            remove_response = self.iam_client.remove_role_from_instance_profile(
                InstanceProfileName=instance_profile_name, RoleName=role_name
            )
            return remove_response
        except ClientError as err:
            print(Fore.RED)
            logging.info(
                f"Remove Role '{role_name}' from Instance profile '{instance_profile_name}' failed,"
                f"listing with err: {err.response['Error']['Code']}"
            )
            logging.error(err)
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def remove_role_instance_profile_validate(self, instance_profile_name: str, role_name: str):
        """
        Method to validate remove_role_instance_profile response.
        :param instance_profile_name: instance profile name
        :param role_name: role name
        """
        remove_response = self.remove_role_instance_profile(instance_profile_name, role_name)
        assert remove_response, f"failed to remove role from instance profile '{instance_profile_name}'."
        assert remove_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected: '{RESPONSE_OK}' but, found "
            f"'{remove_response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        instance_profile_data = self.iam_client.get_instance_profile(
            InstanceProfileName=instance_profile_name)['InstanceProfile']
        assert len(instance_profile_data['Roles']) == 0, (
            f"failed to remove role from instance profile '{instance_profile_name}'."
        )
        logging.info(
            Fore.GREEN + f"Role '{role_name}' Removed successfully from Instance profile '{instance_profile_name}'"
            + Style.RESET_ALL)
        if self.command_line:
            return f"Role '{role_name}' Removed successfully from Instance profile '{instance_profile_name}'"

    def delete_instance_profile(self, instance_profile_name: str):
        """
        Method to delete instance profile
        :param instance_profile_name: instance profile_name
        :return: delete_response
        """
        try:
            delete_response = self.iam_client.delete_instance_profile(InstanceProfileName=instance_profile_name)
            return delete_response
        except ClientError as err:
            print(Fore.RED)
            logging.info(
                f"Deletion of Instance profile '{instance_profile_name}' failed, "
                f"listing with err: {err.response['Error']['Code']}"
            )
            logging.error(err)
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def delete_instance_profile_validate(self, instance_profile_name: str):
        """
        Method to validate delete_instance_profile response.
        :param instance_profile_name: instance profile_name
        """
        delete_response = self.delete_instance_profile(instance_profile_name)
        assert delete_response, f"failed to delete instance profile '{instance_profile_name}'."
        assert delete_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"failed to verify response code. Expected: '{RESPONSE_OK}' but, found "
            f"'{delete_response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        instance_profile_list = [instance_profile['InstanceProfileName'] for instance_profile in
                                 self.iam_client.list_instance_profiles()['InstanceProfiles']]
        assert instance_profile_name not in instance_profile_list, (
            f"failed to delete instance profile: '{instance_profile_name}'."
        )
        logging.info(Fore.GREEN + f"instance profile '{instance_profile_name}' deleted successfully'" + Style.RESET_ALL)
        if self.command_line:
            return f"instance profile '{instance_profile_name}' deleted successfully'"


def main():
    parser = argparse.ArgumentParser()
    iam_method_subparser = parser.add_subparsers(dest='iam_method')

    # Create User Commands
    create_user_parser = iam_method_subparser.add_parser("create-user", help="Create new user")
    create_user_parser.add_argument("--user_name", type=str,
                                    help="The name of the user to create." + Fore.RED + " [REQUIRED]" +
                                         Style.RESET_ALL, required=True)
    create_user_parser.add_argument("--Path", "--path", type=str,
                                    help="The path for the user name", default=argparse.SUPPRESS)
    create_user_parser.add_argument("--PermissionsBoundary", "--permission_boundary", type=str,
                                    help="The ARN of the policy that is used to set the permissions boundary "
                                         "for the user.", default=argparse.SUPPRESS)
    create_user_parser.add_argument("--Tags", "--tags", type=list,
                                    help="A list of tags that you want to attach to the new user. Each tag consists of "
                                         "a key name and an associated value.", default=argparse.SUPPRESS)
    create_user_parser.add_argument("--email", type=str,
                                    help="Specify email ID to send email notification (Multiple comma-separated "
                                         "email IDs are acceptable)",
                                    default=argparse.SUPPRESS)

    # Check User Status
    user_info_parser = iam_method_subparser.add_parser("check-user", help="Check user status (Run it without any "
                                                                          "parameters to list all the users)")
    user_info_parser.add_argument("--user_name", type=str, default="",
                                  help="The name of the user(if not provided then lists all the users)")

    # Delete User
    delete_user_parser = iam_method_subparser.add_parser("delete-user", help="Delete existing user")
    delete_user_parser.add_argument("--user_name", type=str,
                                    help="The name of the user" + Fore.RED + " [REQUIRED]" +
                                         Style.RESET_ALL, required=True)
    delete_user_parser.add_argument("--email", type=str,
                                    help="Specify email ID to send email notification (Multiple comma-separated "
                                         "email IDs are acceptable)",
                                    default=argparse.SUPPRESS)

    # Create Role Commands
    create_role_parser = iam_method_subparser.add_parser("create-role", help="Create new role")
    create_role_parser.add_argument("--role_name", type=str,
                                    help="The name of the role to create." + Fore.RED + " [REQUIRED]" +
                                         Style.RESET_ALL, required=True)
    create_role_parser.add_argument("--role_document", type=argparse.FileType('r'),
                                    help="The trust relationship policy document that grants an entity permission to "
                                         "assume the role." + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                                    required=True)
    create_role_parser.add_argument("--Description", "--description", type=str,
                                    help="A description of the role.", default=argparse.SUPPRESS)
    create_role_parser.add_argument("--MaxSessionDuration", "--max_session_time", type=str,
                                    help="A description of the role.", default=argparse.SUPPRESS)
    create_role_parser.add_argument("--PermissionsBoundary", "--permission_boundary", type=str,
                                    help="The ARN of the policy that is used to set the permissions boundary "
                                         "for the user.", default=argparse.SUPPRESS)
    create_role_parser.add_argument("--Tags", "--tags", type=list,
                                    help="A list of tags that you want to attach to the new user. Each tag consists of "
                                         "a key name and an associated value.", default=argparse.SUPPRESS)
    create_role_parser.add_argument("--email", type=str,
                                    help="Specify email ID to send email notification (Multiple comma-separated "
                                         "email IDs are acceptable)",
                                    default=argparse.SUPPRESS)

    # List Role Commands
    list_roles_parser = iam_method_subparser.add_parser("list-roles", help="Lists Roles attached to user")
    list_roles_parser.add_argument("--PathPrefix", "--path_prefix", type=str,
                                   help="The path prefix for filtering the results.", default=argparse.SUPPRESS)
    list_roles_parser.add_argument("--Marker", "--marker", type=str,
                                   help="Use this parameter only when paginating results and only after you receive a "
                                        "response indicating that the results are truncated. Set it to the value of "
                                        "the Marker element in the response that you received to indicate where the "
                                        "next call should start.", default=argparse.SUPPRESS)
    list_roles_parser.add_argument("--MaxItems", "--max_items", type=int,
                                   help="Use this only when paginating results to indicate the maximum number of items "
                                        "you want in the response. If additional items exist beyond the maximum you "
                                        "specify, the IsTruncated response element is true .",
                                   default=argparse.SUPPRESS)

    # Delete Role Commands
    delete_role_parser = iam_method_subparser.add_parser("delete-role", help="Delete existing role. "
                                                                             "[The role must not have any policies "
                                                                             "attached]")
    delete_role_parser.add_argument("--role_name", type=str,
                                    help="The name of the role to Delete." + Fore.RED + " [REQUIRED]" +
                                         Style.RESET_ALL, required=True)
    delete_role_parser.add_argument("--email", type=str,
                                    help="Specify email ID to send email notification (Multiple comma-separated "
                                         "email IDs are acceptable)",
                                    default=argparse.SUPPRESS)

    # Get role details
    get_role_parser = iam_method_subparser.add_parser("role-info", help="Get Role Information")
    get_role_parser.add_argument("--role_name", type=str, help="The name of the role" + Fore.RED + " [REQUIRED]" +
                                                               Style.RESET_ALL, required=True)
    get_role_parser.add_argument("--email", type=str,
                                    help="Specify email ID to send email notification (Multiple comma-separated "
                                         "email IDs are acceptable)",
                                    default=argparse.SUPPRESS)

    # Create Policy Validate
    create_policy_parser = iam_method_subparser.add_parser("create-policy", help="Create new policy")
    create_policy_parser.add_argument("--policy_name", type=str,
                                      help="The name of the role to create." + Fore.RED + " [REQUIRED]" +
                                           Style.RESET_ALL, required=True)
    create_policy_parser.add_argument("--policy_document", type=argparse.FileType("r"),
                                      help="The JSON policy document that you want to use as the content for the new "
                                           "policy." + Fore.RED + " [REQUIRED]" +
                                           Style.RESET_ALL, required=True)
    create_policy_parser.add_argument("--Path", "--path", type=str,
                                      help="The path for the policy", default=argparse.SUPPRESS)
    create_policy_parser.add_argument("--Description", "--description", type=str,
                                      help="A description of the role.", default=argparse.SUPPRESS)
    create_policy_parser.add_argument("--Tags", "--tags", type=list,
                                      help="A list of tags that you want to attach to the new IAM customer managed"
                                           " policy. Each tag consists of a key name and an associated value.",
                                      default=argparse.SUPPRESS)
    create_policy_parser.add_argument("--email", type=str,
                                    help="Specify email ID to send email notification (Multiple comma-separated "
                                         "email IDs are acceptable)",
                                    default=argparse.SUPPRESS)

    # List Policy Info
    list_policy_info_parser = iam_method_subparser.add_parser("policy-info", help="Get policy information")
    list_policy_info_parser.add_argument("--policy_name", type=str,
                                         help="The name of the policy" + Fore.RED + " [REQUIRED]" +
                                              Style.RESET_ALL, required=True)
    list_policy_info_parser.add_argument("--email", type=str,
                                    help="Specify email ID to send email notification (Multiple comma-separated "
                                         "email IDs are acceptable)",
                                    default=argparse.SUPPRESS)

    # List all Policies
    list_all_policies_parser = iam_method_subparser.add_parser("list-policies", help="List all policies")

    # List Policies that are attached to particular role
    list_all_policies_parser = iam_method_subparser.add_parser("list-role-policies", help="List all policies attached "
                                                                                          "to role")
    list_all_policies_parser.add_argument("--role_name", type=str, help="The name of the role." + Fore.RED +
                                                                        " [REQUIRED]" + Style.RESET_ALL, required=True)

    # Delete Policy
    del_policy_info_parser = iam_method_subparser.add_parser("delete-policy",
                                                             help="Delete existing policy")
    del_policy_info_parser.add_argument("--policy_arn", type=str,
                                        help="The name of the policy" + Fore.RED + " [REQUIRED]" +
                                             Style.RESET_ALL, required=True)
    del_policy_info_parser.add_argument("--email", type=str,
                                    help="Specify email ID to send email notification (Multiple comma-separated "
                                         "email IDs are acceptable)",
                                    default=argparse.SUPPRESS)

    # attach policy to role
    attch_pol_role_parser = iam_method_subparser.add_parser("attach-role-policy",
                                                            help="Attach policy to role")
    attch_pol_role_parser.add_argument("--policy_arn", type=str,
                                       help="The name of the policy" + Fore.RED + " [REQUIRED]" +
                                            Style.RESET_ALL, required=True)
    attch_pol_role_parser.add_argument("--role_name", type=str,
                                       help="The name of the role to create." + Fore.RED + " [REQUIRED]" +
                                            Style.RESET_ALL, required=True)
    attch_pol_role_parser.add_argument("--email", type=str,
                                    help="Specify email ID to send email notification (Multiple comma-separated "
                                         "email IDs are acceptable)",
                                    default=argparse.SUPPRESS)

    # detach policy to role
    detach_pol_role_parser = iam_method_subparser.add_parser("detach-role-policy",
                                                             help="Detach policy from role")
    detach_pol_role_parser.add_argument("--policy_arn", type=str,
                                        help="The name of the policy" + Fore.RED + " [REQUIRED]" +
                                             Style.RESET_ALL, required=True)
    detach_pol_role_parser.add_argument("--role_name", type=str,
                                        help="The name of the role to create." + Fore.RED + " [REQUIRED]" +
                                             Style.RESET_ALL, required=True)
    detach_pol_role_parser.add_argument("--email", type=str,
                                    help="Specify email ID to send email notification (Multiple comma-separated "
                                         "email IDs are acceptable)",
                                    default=argparse.SUPPRESS)

    # attach policy to user
    attch_user_pol_parser = iam_method_subparser.add_parser("attach-user-policy",
                                                            help="Attach policy to user")
    attch_user_pol_parser.add_argument("--policy_arn", type=str,
                                       help="Policy ARN" + Fore.RED + " [REQUIRED]" +
                                            Style.RESET_ALL, required=True)
    attch_user_pol_parser.add_argument("--user_name", type=str,
                                       help="The name of the user." + Fore.RED + " [REQUIRED]" +
                                            Style.RESET_ALL, required=True)
    attch_user_pol_parser.add_argument("--email", type=str,
                                    help="Specify email ID to send email notification (Multiple comma-separated "
                                         "email IDs are acceptable)",
                                    default=argparse.SUPPRESS)

    # detach policy from user
    detach_user_pol_parser = iam_method_subparser.add_parser("detach-user-policy",
                                                             help="Detach policy from user")
    detach_user_pol_parser.add_argument("--policy_arn", type=str,
                                        help="The name of the policy" + Fore.RED + " [REQUIRED]" +
                                             Style.RESET_ALL, required=True)
    detach_user_pol_parser.add_argument("--user_name", type=str,
                                        help="The name of the user." + Fore.RED + " [REQUIRED]" +
                                             Style.RESET_ALL, required=True)
    detach_user_pol_parser.add_argument("--email", type=str,
                                    help="Specify email ID to send email notification (Multiple comma-separated "
                                         "email IDs are acceptable)",
                                    default=argparse.SUPPRESS)

    # Create Instance Profile
    create_instance_prof_parser = iam_method_subparser.add_parser("create-instance-profile",
                                                                  help="Create new instance profile")
    create_instance_prof_parser.add_argument("--instance_profile_name", type=str,
                                             help="Instance profile name" + Fore.RED + " [REQUIRED]" +
                                                  Style.RESET_ALL, required=True)
    create_instance_prof_parser.add_argument("--email", type=str,
                                        help="Specify email ID to send email notification (Multiple comma-separated "
                                             "email IDs are acceptable)",
                                        default=argparse.SUPPRESS)

    # Add Role to instant profile
    add_role_instant_prof_parser = iam_method_subparser.add_parser("add-role-instance-profile",
                                                                   help="Add role to instance profile")
    add_role_instant_prof_parser.add_argument("--instance_profile_name", type=str,
                                              help="Instance profile name" + Fore.RED + " [REQUIRED]" +
                                                   Style.RESET_ALL, required=True)

    add_role_instant_prof_parser.add_argument("--role_name", type=str,
                                              help="Role name." + Fore.RED + " [REQUIRED]" +
                                                   Style.RESET_ALL, required=True)

    add_role_instant_prof_parser.add_argument("--email", type=str,
                                    help="Specify email ID to send email notification (Multiple comma-separated "
                                         "email IDs are acceptable)",
                                    default=argparse.SUPPRESS)

    # List Instance profile attached to the role
    list_inst_prof_role_parser = iam_method_subparser.add_parser("list-role-instance-profiles",
                                                                 help="Lists Instance profiles attached to role")
    list_inst_prof_role_parser.add_argument("--role_name", type=str,
                                            help="Role name." + Fore.RED + " [REQUIRED]" +
                                                 Style.RESET_ALL, required=True)

    # Remove Role From instant profile
    remove_role_instant_prof_parser = iam_method_subparser.add_parser("remove-role-instance-profile",
                                                                      help="Remove role from instance profile")
    remove_role_instant_prof_parser.add_argument("--instance_profile_name", type=str,
                                                 help="Instance profile name." + Fore.RED + " [REQUIRED]" +
                                                      Style.RESET_ALL, required=True)

    remove_role_instant_prof_parser.add_argument("--role_name", type=str,
                                                 help="Role name." + Fore.RED + " [REQUIRED]" +
                                                      Style.RESET_ALL, required=True)
    remove_role_instant_prof_parser.add_argument("--email", type=str,
                                    help="Specify email ID to send email notification (Multiple comma-separated "
                                         "email IDs are acceptable)",
                                    default=argparse.SUPPRESS)

    # Delete Instance Profile
    delete_instant_prof = iam_method_subparser.add_parser("delete-instance-profile",
                                                          help="Delete instance profile")
    delete_instant_prof.add_argument("--instance_profile_name", type=str,
                                     help="Instance Profile Name." + Fore.RED + " [REQUIRED]" +
                                          Style.RESET_ALL, required=True)
    delete_instant_prof.add_argument("--email", type=str,
                                    help="Specify email ID to send email notification (Multiple comma-separated "
                                         "email IDs are acceptable)",
                                    default=argparse.SUPPRESS)

    args = parser.parse_args()
    if not args.iam_method:
        parser.print_help()
        return
    parse_args_to_execute(args)


@send_email("IAM", "iam_method")
def parse_args_to_execute(args, config_data=None):
    if args.iam_method and config_data:
        iam_obj = IAM(config_data, command_line=True)
        args_dict = vars(args)
        if args.iam_method == "create-user":
            del args_dict['iam_method']
            return iam_obj.create_validate_user(**args_dict)
        elif args.iam_method == "check-user":
            del args_dict['iam_method']
            iam_obj.list_validate_user(**args_dict)
        elif args.iam_method == "delete-user":
            del args_dict['iam_method']
            return iam_obj.delete_user_validate(**args_dict)
        elif args.iam_method == "create-role":
            del args_dict['iam_method']
            role_doc_dict = json.load(args_dict['role_document'])
            args_dict['role_document'] = role_doc_dict
            return iam_obj.create_role_validate(**args_dict)
        elif args.iam_method == "list-roles":
            del args_dict['iam_method']
            iam_obj.list_roles(**args_dict)
        elif args.iam_method == "role-info":
            del args_dict['iam_method']
            return iam_obj.check_role_info(**args_dict)
        elif args.iam_method == "delete-role":
            del args_dict['iam_method']
            return iam_obj.delete_role_validate(**args_dict)
        elif args.iam_method == "create-policy":
            del args_dict['iam_method']
            policy_doc_dict = json.load(args_dict['policy_document'])
            args_dict['policy_document'] = policy_doc_dict
            return iam_obj.create_policy_validate(**args_dict)
        elif args.iam_method == "delete-policy":
            del args_dict['iam_method']
            return iam_obj.delete_policy_validate(**args_dict)
        elif args.iam_method == "policy-info":
            del args_dict['iam_method']
            return iam_obj.list_policy(**args_dict)
        elif args.iam_method == "list-policies":
            del args_dict['iam_method']
            iam_obj.list_policy(list_all=True)
        elif args.iam_method == "list-role-policies":
            del args_dict['iam_method']
            iam_obj.list_role_policies(**args_dict)
        elif args.iam_method == "attach-role-policy":
            del args_dict['iam_method']
            return iam_obj.attach_policy_role_validate(**args_dict)
        elif args.iam_method == "detach-role-policy":
            del args_dict['iam_method']
            return iam_obj.detach_role_policy_validate(**args_dict)
        elif args.iam_method == "attach-user-policy":
            del args_dict['iam_method']
            return iam_obj.attach_user_policy_validate(**args_dict)
        elif args.iam_method == "detach-user-policy":
            del args_dict['iam_method']
            return iam_obj.detach_user_policy_validate(**args_dict)
        elif args.iam_method == "create-instance-profile":
            del args_dict['iam_method']
            return iam_obj.create_instance_profile_validate(**args_dict)
        elif args.iam_method == "add-role-instance-profile":
            del args_dict['iam_method']
            return iam_obj.add_role_to_instance_profile_validate(**args_dict)
        elif args.iam_method == "list-role-instance-profiles":
            del args_dict['iam_method']
            iam_obj.list_role_instance_profiles(**args_dict)
        elif args.iam_method == "remove-role-instance-profile":
            del args_dict['iam_method']
            return iam_obj.remove_role_instance_profile_validate(**args_dict)
        elif args.iam_method == "delete-instance-profile":
            del args_dict['iam_method']
            return iam_obj.delete_instance_profile_validate(**args_dict)


if __name__ == '__main__':
    main()
