RESPONSE_OK = 200
NO_CONTENT = 204
TOKEN_PATH = '/tmp/token'
RANDOM_PATH = '/tmp/random'
KEY_PATH = '/tmp/key'
SESSION_PATH = '/usr/create_session_config.json'
EMAIL_PATH = '/usr/email_config.json'
