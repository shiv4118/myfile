#!/usr/bin/env python3
import argparse
import logging
import sys
import datetime
import os
import logging.handlers

import boto3
from botocore.exceptions import ClientError
from colorama import Fore, Style

from email_notifications import send_email
from constants import *


class SNS:
    def __init__(self, config, command_line=False):
        self.sns_client = boto3.client(
            'sns', **config
        )
        self.config = config
        self.command_line = command_line
        if command_line:
            home_dir = os.path.expanduser("~")
            # logging.basicConfig(level=logging.INFO, format='%(message)s')
            # sys.tracebacklimit = 0
            cur_date = datetime.datetime.now().strftime("%d_%b_%Y")
            log_dir_path = os.path.join(home_dir, ".a4cloudstack_logs")
            final_log_path = log_dir_path + "/log_" + cur_date
            if not os.path.exists(final_log_path):
                os.makedirs(final_log_path, mode=0o777, exist_ok=True)
            logging.getLogger().setLevel(logging.NOTSET)
            console = logging.StreamHandler(sys.stdout)
            console.setLevel(logging.INFO)
            formater = logging.Formatter('%(message)s')
            console.setFormatter(formater)
            logging.getLogger().addHandler(console)

            # Add file rotating handler, with level DEBUG
            rotatingHandler = logging.handlers.RotatingFileHandler(filename=final_log_path + "/" + 'sns.log',
                                                                   maxBytes=100000, backupCount=5)
            rotatingHandler.setLevel(logging.INFO)
            formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
            rotatingHandler.setFormatter(formatter)
            logging.getLogger().addHandler(rotatingHandler)
            sys.tracebacklimit = 0

    def sns_create_topic(self, topic_name: str, **kwargs):
        """
        Creates a new topic
        :param topic_name: Name of the topic
        :return: Https Response
        """
        try:
            response = self.sns_client.create_topic(Name=topic_name, **kwargs)
            return response
        except ClientError as err:
            print(Fore.RED)
            logging.error(f"Create topic failed with err: {err}")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def sns_create_topic_validation(self, topic_name: str):
        """
        Checks if topic already exists before creating new topic.
        :param topic_name: Name of the topic
        """
        if self.get_validate_topic_name(topic_name, cons_log=False):
            logging.info(Fore.YELLOW + f"Topic {topic_name} already exists" + Style.RESET_ALL)
        else:
            response = self.sns_create_topic(topic_name)
            assert response, f"Failed to get the response of the create topic. Output: {response}"
            assert response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
                f"Failed to verify response code. Expected: '{RESPONSE_OK}' but found "
                f"'{response['ResponseMetadata']['HTTPStatusCode']}'"
            )
            topic_arn = response["TopicArn"]
            logging.info(Fore.GREEN + f"Topic with arn:'{topic_arn} created successfully'" + Style.RESET_ALL)
            return response

    def sns_list_topics(self):
        """
        Retrieve list of topic_arns present in a region.
        :return: Https Response
        """
        try:
            return self.sns_client.list_topics()
        except ClientError as err:
            print(Fore.RED)
            logging.error(f"Create topic failed with err: {err}")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def sns_list_topics_validation(self, console_log: bool = False):
        """
        Validating list_topics response
        :return: Topic_arn's list
        """
        response = self.sns_list_topics()
        assert response, f"Failed to get the response of the topic list. Output: {response}"
        assert response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Failed to verify response code. Expected: '{RESPONSE_OK}' but found "
            f"'{response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        topics_list = response["Topics"]
        if topics_list is True and console_log is False:
            logging.info(f"List Of Topic available\n{topics_list}")
        if topics_list and console_log:
            logging.info(f"List Of Topics available - \n")
            for topic in topics_list:
                print(topic['TopicArn'])
        return topics_list

    def get_validate_topic_name(self, topic_name: str, cons_log: bool = False):
        """
        Validation method to validate topic is present on AWS
        :param topic_name: Name of the topic
        :return: True or False
        """
        list_topics = self.sns_list_topics_validation(cons_log)
        topic_present = False
        for topic in list_topics:
            if topic_name == topic['TopicArn'].split(':')[5]:
                topic_present = True
                if cons_log:
                    logging.info(Fore.GREEN + f"Topic '{topic_name}' is present on AWS" + Style.RESET_ALL)
                break
        else:
            if cons_log:
                logging.info(Fore.RED + f"Topic {topic_name} not present" + Style.RESET_ALL)
        return topic_present

    def sns_delete_topic(self, topic_arn: str, **kwargs):
        """
        Deletion of the topic.
        :param topic_arn: topic ARN value.
        :return: delete topic response
        """
        try:
            return self.sns_client.delete_topic(TopicArn=topic_arn, **kwargs)
        except ClientError as err:
            print(Fore.RED)
            logging.error(f"Create topic failed with err: {err}")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def sns_delete_topic_validation(self, topic_arn: str, **kwargs):
        """
        Validating the delete_topic response
        """
        topic_name = topic_arn.split(':')[5]
        if self.get_validate_topic_name(topic_name, cons_log=False):
            response = self.sns_delete_topic(topic_arn, **kwargs)
            assert response, f"Failed to get the response of delete topic. Output: {response}"
            assert response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
                f"Failed to verify response code. Expected: '{RESPONSE_OK}' but found "
                f"'{response['ResponseMetadata']['HTTPStatusCode']}'"
            )
            sns_delete_topic_validation = self.get_validate_topic_name(topic_name, cons_log=False)
            if sns_delete_topic_validation:
                logging.info(Fore.RED + f"Topic '{topic_arn} deletion failed'" + Style.RESET_ALL)
            else:
                logging.info(Fore.GREEN + f"Topic '{topic_arn} deleted successfully." + Style.RESET_ALL)
        else:
            logging.info(Fore.YELLOW + f"Topic '{topic_arn}  does not exist" + Style.RESET_ALL)

    def sns_create_subscription(self, topic_arn: str, protocol: str, endpoint: str, **kwargs):
        """
        Create subscription
        :param topic_arn: topic ARN value
        :param protocol: Protocol type.
        :param endpoint: Endpoint value
        :return: Https Response
        """
        try:
            response = self.sns_client.subscribe(TopicArn=topic_arn, Protocol=protocol, Endpoint=endpoint, **kwargs)
            return response
        except ClientError as err:
            print(Fore.RED)
            logging.error(f"Create topic failed with err: {err}")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def sns_subscription_validation(self, topic_arn: str, protocol: str, endpoint: str, **kwargs):
        """
        Checks the topic existence before creating subscription.
        :param topic_arn: topic ARN value
        :param protocol: Protocol type.
        :param endpoint: Endpoint value
        """
        topic_name = topic_arn.split(':')[5]
        if self.get_validate_topic_name(topic_name, cons_log=False):
            response = self.sns_create_subscription(topic_arn, protocol, endpoint, **kwargs)
            assert response, f"Failed to get the response of create subscription. Output: {response}"
            assert response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
                f"Failed to verify response code. Expected: '{RESPONSE_OK}' but found "
                f"'{response['ResponseMetadata']['HTTPStatusCode']}'"
            )
            subscription_arn = response["SubscriptionArn"]
            logging.info(Fore.GREEN + f"Subscription created successfully for {topic_arn}"
                                      f"confirm the subscription with {endpoint}'" + Style.RESET_ALL)
            return response
        else:
            logging.info(Fore.YELLOW + f"Topic {topic_arn} does not exist'" + Style.RESET_ALL)

    def sns_list_subscription_by_topic(self, topic_arn: str, **kwargs):
        """
         Returns a list of the subscriptions to a specific topic
        :param topic_arn: topic ARN value
        :return: Subscription details for topics
        """
        try:
            response = self.sns_client.list_subscriptions_by_topic(TopicArn=topic_arn, **kwargs)
            if response["Subscriptions"]:
                logging.info(Fore.GREEN + f"Subscription fetched successfully for topic {topic_arn}." +
                             Style.RESET_ALL + "\nDetails:")
                subscription_list = response["Subscriptions"]
                for sub in subscription_list:
                    logging.info(sub)
        except ClientError as err:
            print(Fore.RED)
            logging.error(f"Unable to list subscriptions for topic. Error -: {err}")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def sns_delete_subscription(self, sub_arn: str):
        """
        Deletes Existing subscription
        :param sub_arn: The ARN of the subscription to be deleted.
        :return: True
        """
        try:
            self.sns_client.unsubscribe(SubscriptionArn=sub_arn)
            return True
        except ClientError as err:
            print(Fore.RED)
            logging.error(f"Subscription deletion failed with error: {err}")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def sns_delete_subscription_validation(self, sub_arn: str):
        """
        Validates Delete subscription
        :param sub_arn: The ARN of the subscription to be deleted.
        """
        if self.sns_delete_subscription(sub_arn):
            logging.info(Fore.GREEN + f"Subscription {sub_arn} Deleted successfully. " + Style.RESET_ALL)
            return f"Subscription {sub_arn} Deleted successfully. "
        else:
            logging.info(Fore.YELLOW + f"Unable to delete Subscription {sub_arn}'" + Style.RESET_ALL)

    def sns_publish_messages(self, topic_arn: str, subject: str, message: str, **kwargs):
        """
        Publish message to topic
        :param topic_arn: topic ARN value
        :param message: Message body
        :param subject: Message Subject
        :return: dict
        """
        try:
            response = self.sns_client.publish(TopicArn=topic_arn, Subject=subject, Message=message, **kwargs)
            return response
        except ClientError as err:
            print(Fore.RED)
            logging.error(f"Message publishing failed with error: {err}")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def sns_publish_message_validation(self, topic_arn: str, subject: str, message: str, **kwargs):
        """
        Validates message publishing to topic
        :param topic_arn: topic ARN value
        :param message: Message body
        :param subject: Message Subject
        """
        response = self.sns_publish_messages(topic_arn, subject, message, **kwargs)
        if response["MessageId"]:
            logging.info(Fore.GREEN + f"Message published successfully " + Style.RESET_ALL)
            return f"Message published successfully "
        else:
            logging.info(Fore.YELLOW + f"Unable to publish message. response - {response}'" + Style.RESET_ALL)


def main():
    parser = argparse.ArgumentParser()
    sns_method_subparser = parser.add_subparsers(dest='sns_method')

    # Create Topic
    create_topic_parser = sns_method_subparser.add_parser("create-topic", help="Create new topic")
    create_topic_parser.add_argument("--topic_name", type=str,
                                     help="The name of the topic to create." + Fore.RED + " [REQUIRED]" +
                                          Style.RESET_ALL, required=True)
    create_topic_parser.add_argument(
        "--email", type=str,
        help="Specify email ID to send email notification (Multiple comma-separated email IDs are acceptable)",
        default=argparse.SUPPRESS)

    # Check Topic
    get_topic_parser = sns_method_subparser.add_parser("check-topic", help="Check topic status")
    get_topic_parser.add_argument("--topic_name", type=str,
                                  help="name of the topic" + Fore.RED + " [REQUIRED]" +
                                       Style.RESET_ALL, required=True)
    get_topic_parser.add_argument(
        "--email", type=str,
        help="Specify email ID to send email notification (Multiple comma-separated email IDs are acceptable)",
        default=argparse.SUPPRESS)

    # List Topic
    topic_list_parser = sns_method_subparser.add_parser("list-topic", help="List topics")

    # Delete Topic
    delete_topic_parser = sns_method_subparser.add_parser("delete-topic", help="Delete existing topic")
    delete_topic_parser.add_argument("--topic_arn", type=str,
                                     help="topic ARN value" + Fore.RED + " [REQUIRED]" +
                                          Style.RESET_ALL, required=True)
    delete_topic_parser.add_argument(
        "--email", type=str,
        help="Specify email ID to send email notification (Multiple comma-separated email IDs are acceptable)",
        default=argparse.SUPPRESS)

    # Create Subscription
    create_sub_parser = sns_method_subparser.add_parser("create-subscription", help="Create new subscription")
    create_sub_parser.add_argument("--topic_arn", type=str, help="topic ARN value" + Fore.RED + " [REQUIRED]" +
                                                                 Style.RESET_ALL, required=True)
    create_sub_parser.add_argument("--protocol", type=str, help="Protocol type." + Fore.RED + " [REQUIRED]" +
                                                                Style.RESET_ALL, required=True)
    create_sub_parser.add_argument("--endpoint", type=str, help="Endpoint value" + Fore.RED + " [REQUIRED]" +
                                                                Style.RESET_ALL, required=True)
    create_sub_parser.add_argument(
        "--email", type=str,
        help="Specify email ID to send email notification (Multiple comma-separated email IDs are acceptable)",
        default=argparse.SUPPRESS)

    # List Subscription
    list_sub_parser = sns_method_subparser.add_parser("list-subscription", help="lists subscription information to "
                                                                                "a specific topic")
    list_sub_parser.add_argument("--topic_arn", type=str, help="topic ARN value" + Fore.RED + " [REQUIRED]" +
                                                               Style.RESET_ALL, required=True)
    list_sub_parser.add_argument(
        "--email", type=str,
        help="Specify email ID to send email notification (Multiple comma-separated email IDs are acceptable)",
        default=argparse.SUPPRESS)

    # Deletes Subscription
    delete_sub_parser = sns_method_subparser.add_parser("delete-subscription", help="Deletes new subscription")
    delete_sub_parser.add_argument("--sub_arn", type=str, help="Subscription ARN value" + Fore.RED + " [REQUIRED]" +
                                                               Style.RESET_ALL, required=True)
    delete_sub_parser.add_argument(
        "--email", type=str,
        help="Specify email ID to send email notification (Multiple comma-separated email IDs are acceptable)",
        default=argparse.SUPPRESS)

    # Publish Message
    pub_msg_parser = sns_method_subparser.add_parser("publish", help="Publish message to topic")
    pub_msg_parser.add_argument("--topic_arn", type=str, help="topic ARN value" + Fore.RED + " [REQUIRED]" +
                                                              Style.RESET_ALL, required=True)
    pub_msg_parser.add_argument("--subject", type=str, help="message subject" + Fore.RED + " [REQUIRED]" +
                                                            Style.RESET_ALL, required=True)
    pub_msg_parser.add_argument("--message", type=str, help="message body" + Fore.RED + " [REQUIRED]" +
                                                            Style.RESET_ALL, required=True)
    pub_msg_parser.add_argument(
        "--email", type=str,
        help="Specify email ID to send email notification (Multiple comma-separated email IDs are acceptable)",
        default=argparse.SUPPRESS)

    args = parser.parse_args()
    if not args.sns_method:
        parser.print_help()
        return
    parse_args_to_execute(args)


@send_email("SNS", "sns_method")
def parse_args_to_execute(args, config_data={}):
    if args.sns_method:
        sns_obj = SNS(config_data, command_line=True)
        args_dict = vars(args)
        if args.sns_method == "create-topic":
            del args_dict['sns_method']
            return sns_obj.sns_create_topic_validation(**args_dict)
        elif args.sns_method == "check-topic":
            del args_dict['sns_method']
            sns_obj.get_validate_topic_name(**args_dict, cons_log=False)
        elif args.sns_method == "list-topic":
            del args_dict['sns_method']
            sns_obj.sns_list_topics_validation(console_log=True)
        elif args.sns_method == "delete-topic":
            del args_dict['sns_method']
            return sns_obj.sns_delete_topic_validation(**args_dict)
        elif args.sns_method == "create-subscription":
            del args_dict['sns_method']
            return sns_obj.sns_subscription_validation(**args_dict)
        elif args.sns_method == "list-subscription":
            del args_dict['sns_method']
            sns_obj.sns_list_subscription_by_topic(**args_dict)
        elif args.sns_method == "delete-subscription":
            del args_dict['sns_method']
            return sns_obj.sns_delete_subscription_validation(**args_dict)
        elif args.sns_method == "publish":
            del args_dict['sns_method']
            return sns_obj.sns_publish_message_validation(**args_dict)


if __name__ == '__main__':
    main()
