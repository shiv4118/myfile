#!/usr/bin/env python3
import argparse

from cli import create_new_aws_session, get_current_session_status


def main():
    parser = argparse.ArgumentParser()
    session_method_subparser = parser.add_subparsers(dest='session_method')

    # At time of temp. token
    session_token_parser = session_method_subparser.add_parser("token", help="Get temporary credentials")
    session_token_parser.add_argument("--DurationSeconds", type=int,
                                      help="The duration, in seconds, that the credentials should remain valid. "
                                           "[default 3600]", default=3600)

    # To check current session status
    _status_parser = session_method_subparser.add_parser("status",
                                                         help="To check current session timeout.")

    # At time of initial installation setup
    _installation_parser = session_method_subparser.add_parser("install",
                                                               help="Used for initial installation setup")

    args = parser.parse_args()
    if args.session_method:
        args_dict = vars(args)
        if args.session_method == "install":
            create_new_aws_session(install=True)
        elif args.session_method == "token":
            del args_dict['session_method']
            create_new_aws_session(token=True, duration_sec=args_dict.get('DurationSeconds', 3600))
        elif args.session_method == "status":
            get_current_session_status()
    else:
        create_new_aws_session()


if __name__ == '__main__':
    main()
