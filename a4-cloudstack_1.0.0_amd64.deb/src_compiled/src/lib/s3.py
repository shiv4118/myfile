#!/usr/bin/env python3
import argparse
import json
import logging
import os
import sys
import time
import datetime
import logging.handlers

import boto3
import requests
from botocore.exceptions import ClientError
from colorama import Fore, Style

from email_notifications import send_email
from constants import *


class S3:

    def __init__(self, config, command_line=False):

        self.s3_client = boto3.client(
            's3', **config
        )
        self.s3_resource = boto3.resource(
            's3', **config
        )
        self.config = config
        self.command_line = command_line
        if command_line:
            home_dir = os.path.expanduser("~")
            # logging.basicConfig(level=logging.INFO, format='%(message)s')
            # sys.tracebacklimit = 0
            cur_date = datetime.datetime.now().strftime("%d_%b_%Y")
            log_dir_path = os.path.join(home_dir, ".a4cloudstack_logs")
            final_log_path = log_dir_path + "/log_" + cur_date
            if not os.path.exists(final_log_path):
                os.makedirs(final_log_path, mode=0o777, exist_ok=True)
            logging.getLogger().setLevel(logging.NOTSET)
            console = logging.StreamHandler(sys.stdout)
            console.setLevel(logging.INFO)
            formater = logging.Formatter('%(message)s')
            console.setFormatter(formater)
            logging.getLogger().addHandler(console)

            # Add file rotating handler, with level DEBUG
            rotatingHandler = logging.handlers.RotatingFileHandler(filename=final_log_path + "/" + 's3.log',
                                                                   maxBytes=100000, backupCount=5)
            rotatingHandler.setLevel(logging.INFO)
            formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
            rotatingHandler.setFormatter(formatter)
            logging.getLogger().addHandler(rotatingHandler)
            sys.tracebacklimit = 0

    def create_validate_s3_bucket(self, bucket_name: str, **kwargs):
        """
        Validation method to validate create bucket response
        :param bucket_name: Name of the bucket
        :param kwargs: ACL/GrantFullControl/GrantRead/GrantReadACP/GrantWrite/GrantWriteACP/ObjectLockEnabledForBucket
        """
        s3_bucket_create = self.create_s3_bucket(bucket_name, **kwargs)
        assert s3_bucket_create, f"Failed to get response of create bucket. Output: {s3_bucket_create}"
        assert s3_bucket_create['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Failed to verify response code. Expected: '{RESPONSE_OK}' but found "
            f"'{s3_bucket_create['ResponseMetadata']['HTTPStatusCode']}'"
        )
        self.get_validate_s3_bucket(bucket_name, console_log=False)
        logging.info(Fore.GREEN + f"Bucket '{bucket_name}' created successfully" + Style.RESET_ALL)
        return s3_bucket_create

    def create_s3_bucket(self, bucket_name: str, region='', **kwargs):
        """
        Library method to create a new s3 bucket.
        :param bucket_name: Name of the s3 bucket.
        :param region: Region name of where s3 bucket is creating
        :param kwargs: ACL/GrantFullControl/GrantRead/GrantReadACP/GrantWrite/GrantWriteACP/ObjectLockEnabledForBucket
        :return: Response of create s3 bucket
        """
        if not region:
            region = self.config['region_name']
        try:
            location = {'LocationConstraint': region}
            create_bucket = self.s3_client.create_bucket(
                Bucket=bucket_name, CreateBucketConfiguration=location, **kwargs
            )
            return create_bucket
        except ClientError as err:
            print(Fore.RED)
            if err.response['Error']['Code'] == "BucketAlreadyOwnedByYou":
                logging.error(f"Bucket '{bucket_name}' is already owned by the user")
            elif err.response['Error']['Code'] == "BucketAlreadyExists":
                logging.error(f"Bucket '{bucket_name}' already exist")
            else:
                logging.error(err)
            logging.error(f"Create '{bucket_name}' bucket failed listing with err: {err.response['Error']['Code']}")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def get_validate_s3_bucket(self, bucket_name: str, console_log=True):
        """
        Validation method to validate s3 bucket is present on AWS
        :param bucket_name: Name of the bucket
        :param console_log: Display logs on console
        """
        get_s3_bucket = self.get_s3_bucket()
        assert get_s3_bucket, f"Failed to get response of the list of s3 buckets. Output: {get_s3_bucket}"
        assert get_s3_bucket['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Failed to verify response code. Expected: '{RESPONSE_OK}' but found "
            f"'{get_s3_bucket['ResponseMetadata']['HTTPStatusCode']}'"
        )
        assert get_s3_bucket['Buckets'], f"Buckets are not present on AWS"
        bucket_present = False
        for bucket in get_s3_bucket['Buckets']:
            if bucket_name == bucket['Name']:
                bucket_present = True
                break

        assert bucket_present, f"Failed to get bucket '{bucket_name}' from bucket list on AWS"
        if console_log:
            logging.info(Fore.GREEN + f"Bucket '{bucket_name}' is present on AWS" + Style.RESET_ALL)
            return f"Bucket '{bucket_name}' is present on AWS"

    def get_s3_bucket(self):
        """
        Library method to check bucket is present or not
        :return: List of buckets
        """
        try:
            s3_bucket_list = self.s3_client.list_buckets()
            if self.command_line:
                for bucket_name in s3_bucket_list['Buckets']:
                    print(bucket_name['Name'])
            return s3_bucket_list
        except ClientError as err:
            print(Fore.RED)
            logging.error(err)
            logging.error(f"Failed to check bucket is present on AWS with error: {err.response['Error']['Code']}")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def validate_put_object_in_s3_bucket(self, bucket_name: str, key: str, **kwargs):
        """
        Validation method to validate put object request
        :param bucket_name: Name of the bucket
        :param key: Key of the object
        """
        put_object = self.put_object_in_s3_bucket(bucket_name, key, **kwargs)
        assert put_object, (
            f"Failed to get response of put object '{key}' in the bucket '{bucket_name}'. Output: {put_object}"
        )
        assert put_object['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Failed to verify response code. Expected: '{RESPONSE_OK}' but found "
            f"'{put_object['ResponseMetadata']['HTTPStatusCode']}'"
        )
        self.get_validate_object_from_s3_bucket(bucket_name, key)
        logging.info(Fore.GREEN + f"Object '{key}' put successfully in the bucket '{bucket_name}'" + Style.RESET_ALL)
        return f"Object put successfully in the bucket '{bucket_name}'"

    def put_object_in_s3_bucket(self, bucket_name: str, key: str, **kwargs):
        """
        Library method to put the object in the s3 bucket
        :param bucket_name: Name of the bucket
        :param key: Key of the object
        :return: response of the put object request
        """
        try:
            put_object_in_s3 = self.s3_client.put_object(Bucket=bucket_name, Key=key, **kwargs)
            return put_object_in_s3
        except ClientError as err:
            print(Fore.RED)
            logging.error(err)
            logging.error(
                f"Failed to put object '{key}' in the bucket '{bucket_name}' with error: "
                f"{err.response['Error']['Code']}"
            )
            print(Style.RESET_ALL)

    def get_validate_object_from_s3_bucket(self, bucket_name: str, key: str, **kwargs):
        """
        Validation method to validate get object from the s3 bucket
        :param bucket_name: Name of the bucket
        :param key: Key name
        :param kwargs: IfMatch/IfModifiedSince/IfNoneMatch/IfUnmodifiedSince/Key/Range/ResponseCacheControl/
        ResponseContentDisposition/ResponseContentEncoding/ResponseContentLanguage/ResponseContentType/ResponseExpires/
        VersionId/SSECustomerAlgorithm/SSECustomerKey/RequestPayer/PartNumber/ExpectedBucketOwner
        """
        get_object = self.get_object_from_s3_bucket(bucket_name, key, **kwargs)
        assert get_object, f"Failed to get response of the get object request. Output: {get_object}"
        assert get_object['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Failed to verify response code. Expected: '{RESPONSE_OK}' but found "
            f"'{get_object['ResponseMetadata']['HTTPStatusCode']}'"
        )
        logging.info(
            Fore.GREEN + f"Object '{key}' retrieved successfully from the bucket '{bucket_name}'" + Style.RESET_ALL)

    def get_object_from_s3_bucket(self, bucket_name: str, key: str, **kwargs):
        """
        Library method to get object from the s3 bucket
        :param bucket_name: Name of the bucket
        :param key: Name of the get object
        :param kwargs: IfMatch/IfModifiedSince/IfNoneMatch/IfUnmodifiedSince/Key/Range/ResponseCacheControl/
        ResponseContentDisposition/ResponseContentEncoding/ResponseContentLanguage/ResponseContentType/ResponseExpires/
        VersionId/SSECustomerAlgorithm/SSECustomerKey/RequestPayer/PartNumber/ExpectedBucketOwner
        :return: Response of the get object
        """
        try:
            get_object = self.s3_client.get_object(Bucket=bucket_name, Key=key, **kwargs)
            return get_object
        except ClientError as err:
            print(Fore.RED)
            if err.response['Error']['Code'] == "NoSuchKey":
                logging.error(f"Object '{key}' is not present in the bucket '{bucket_name}'")
            else:
                logging.error(err)
            logging.error(f"get object failed with err: {err.response['Error']['Code']}")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def validate_upload_file_in_s3_bucket(self, file_path: str, bucket_name: str, key: str, **kwargs):
        """
        validation method to validate upload file to s3 bucket
        :param file_path: File which needs to be update in the network.
        :param bucket_name: Name of the bucket
        :param key: Name of the object
        :param kwargs: ExtraArgs/Callback/Config
        """
        self.upload_file_in_s3_bucket(file_path, bucket_name, key, **kwargs)
        logging.info(
            Fore.GREEN + f"file successfully uploaded in the object '{key}' in the bucket '{bucket_name}'" + Style.RESET_ALL)
        return f"file successfully uploaded in the object in the bucket '{bucket_name}'"

    def upload_file_in_s3_bucket(self, file_path: str, bucket_name: str, key: str, **kwargs):
        """
        Library method to upload file to s3 bucket
        :param file_path: File which needs to be update in the network.
        :param bucket_name: Name of the bucket
        :param key: Name of the object
        :param kwargs: ExtraArgs/Callback/Config
        """
        try:
            self.s3_client.upload_file(Filename=file_path, Bucket=bucket_name, Key=key, **kwargs)
        except ClientError as err:
            print(Fore.RED)
            logging.error(err)
            logging.error(f"Failed to upload in the object '{key}' in the bucket '{bucket_name}'")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def validate_data_of_file_from_s3_bucket(self, bucket_name: str, object_key: str, actual_data: str):
        """
        Validation method to validate the data from the object.
        :param bucket_name: Name of the bucket
        :param object_key: Name of the object
        :param actual_data: Actual data of the file
        :return:
        """
        data_from_file = self.read_data_of_file_from_s3_bucket(bucket_name, object_key)
        assert data_from_file, f"Failed to read data of the file '{object_key}'. Output: {data_from_file}"
        data = data_from_file.decode('utf-8')
        assert data == actual_data, (
            f"Failed to assert data. Expected data: {actual_data} but found: {data} "
        )

    def read_data_of_file_from_s3_bucket(self, bucket_name: str, object_key: str):
        """
        Method to read the data from the file
        :param bucket_name: Name of the bucket
        :param object_key: Key of the file
        :return: Data of the file
        """
        try:
            data_from_file = self.s3_resource.Object(bucket_name, object_key)
            if self.command_line:
                print(data_from_file.get()['Body'].read().decode('UTF-8'))
            return data_from_file.get()['Body'].read()
        except ClientError as err:
            print(Fore.RED)
            logging.error(err)
            logging.error(f"Failed to read a data from object '{object_key}")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def validate_attach_policy_to_s3_bucket(self, bucket_name: str, policy: str, **kwargs):
        """
        Validation method to validate the response of the attach policy to the s3 bucket
        :param bucket_name: Name of the bucket
        :param policy: Policy of the bucket
        :param kwargs: ConfirmRemoveSelfBucketAccess/ExpectedBucketOwner
        """
        attach_policy = self.attach_policy_to_s3_bucket(bucket_name, policy, **kwargs)
        assert attach_policy, f"Failed to get response of put bucket policy. Output: {attach_policy}"
        assert attach_policy['ResponseMetadata']['HTTPStatusCode'] == NO_CONTENT, (
            f"Failed to verify response code. Expected: '{NO_CONTENT}' but found "
            f"'{attach_policy['ResponseMetadata']['HTTPStatusCode']}'"
        )
        logging.info(Fore.GREEN + f"Policy attached to the bucket '{bucket_name}'" + Style.RESET_ALL)
        return f"Your Policy attached to the bucket '{bucket_name}'"

    def attach_policy_to_s3_bucket(self, bucket_name: str, policy: str, **kwargs):
        """
        Library method to attach policy to s3 bucket
        :param bucket_name: Name of the bucket
        :param policy: policy of the bucket
        :param kwargs: ConfirmRemoveSelfBucketAccess/ExpectedBucketOwner
        :return: Returns the response of the attach policy to the s3 bucket
        """
        try:
            attach_policy = self.s3_client.put_bucket_policy(Bucket=bucket_name, Policy=policy, **kwargs)
            return attach_policy
        except ClientError as err:
            print(Fore.RED)
            logging.error(err)
            logging.error(
                f"Failed to attach policy to the bucket '{bucket_name}' with error: {err.response['Error']['Code']}"
            )
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def validate_delete_policy_of_s3_bucket(self, bucket_name: str, **kwargs):
        """
        Validation method to validate delete policy of the bucket
        :param bucket_name: Name of the bucket
        :param kwargs: ExpectedBucketOwner
        """
        delete_policy = self.delete_policy_of_s3_bucket(bucket_name, **kwargs)
        assert delete_policy, f"Failed to get response of delete bucket policy. Output: {delete_policy}"
        assert delete_policy['ResponseMetadata']['HTTPStatusCode'] == NO_CONTENT, (
            f"Failed to verify response code. Expected: '{NO_CONTENT}' but found "
            f"'{delete_policy['ResponseMetadata']['HTTPStatusCode']}'"
        )
        logging.info(Fore.GREEN + f"Policy deleted from the bucket '{bucket_name}'" + Style.RESET_ALL)
        return f"Policy deleted from the bucket '{bucket_name}'"

    def delete_policy_of_s3_bucket(self, bucket_name: str, **kwargs):
        """
        Library method to delete policy of the bucket
        :param bucket_name: Name of the bucket
        :param kwargs: ExpectedBucketOwner
        :return: Response of the delete policy of the s3 bucket
        """
        try:
            delete_policy = self.s3_client.delete_bucket_policy(Bucket=bucket_name, **kwargs)
            return delete_policy
        except ClientError as err:
            print(Fore.RED)
            logging.error(err)
            logging.error(
                f"Failed to delete policy to the bucket '{bucket_name}' with error: {err.response['Error']['code']}"
            )
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def validate_create_multiple_upload(self, bucket_name: str, object_key: str, **kwargs):
        """
        Validation method to validate response of the create_multipart_upload
        :param bucket_name: Name of the bucket
        :param object_key: Name of the object
        :param kwargs: ACL/CacheControl/ContentDisposition/ContentEncoding/ContentLanguage/ContentType/Expires/
        GrantFullControl/GrantRead/GrantReadACP/GrantWriteACP/Metadata/ServerSideEncryption/StorageClass/
        WebsiteRedirectLocation/SSECustomerAlgorithm/SSECustomerKey/SSEKMSKeyId/SSEKMSEncryptionContext/RequestPayer/
        Tagging/ObjectLockMode/ObjectLockRetainUntilDate/ObjectLockLegalHoldStatus/ExpectedBucketOwner
        :return: upload Id of the create multipart upload request
        """
        multipart_upload = self.create_multipart_upload(bucket_name, object_key, **kwargs)
        assert multipart_upload, f"Failed to get response of the create multipart upload. Output: {multipart_upload}"
        assert multipart_upload['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Failed to verify response code. Expected: '{RESPONSE_OK}' but found "
            f"'{multipart_upload['ResponseMetadata']['HTTPStatusCode']}'"
        )
        logging.info(f"Successfully executed multipart upload for the object '{object_key}'")
        return multipart_upload['UploadId']

    def create_multipart_upload(self, bucket_name: str, object_key: str, **kwargs):
        """
        Library method to create a multipart upload
        :param bucket_name: Name of the bucket
        :param object_key: Name of the object
        :param kwargs: ACL/CacheControl/ContentDisposition/ContentEncoding/ContentLanguage/ContentType/Expires/
        GrantFullControl/GrantRead/GrantReadACP/GrantWriteACP/Metadata/ServerSideEncryption/StorageClass/
        WebsiteRedirectLocation/SSECustomerAlgorithm/SSECustomerKey/SSEKMSKeyId/SSEKMSEncryptionContext/RequestPayer/
        Tagging/ObjectLockMode/ObjectLockRetainUntilDate/ObjectLockLegalHoldStatus/ExpectedBucketOwner
        :return: Response of the create multipart upload request
        """
        try:
            multipart_upload = self.s3_client.create_multipart_upload(Bucket=bucket_name, Key=object_key, **kwargs)
            return multipart_upload
        except ClientError as err:
            logging.error(err)
            logging.error(
                f"Failed to create multipart upload with error: {err.response['Error']['code']}"
            )

    def validate_upload_part_of_multipart_upload(
            self, bucket_name: str, object_key: str, part_number: int, upload_id: str, **kwargs
    ):
        """
        Validation method to validate the response of the multipart upload.
        :param bucket_name: Name of the bucket
        :param object_key: Name of the object
        :param part_number: Part number
        :param upload_id: upload if of the object
        :param kwargs: Body/ContentLength/ContentMD5/PartNumber/SSECustomerAlgorithm/SSECustomerKey/
        RequestPayer/ExpectedBucketOwner
        :return: Etag value of the response
        """
        upload_part = self.upload_part_of_multipart_upload(bucket_name, object_key, part_number, upload_id, **kwargs)
        assert upload_part, f"Failed to get response of upload part. Output: {upload_part}"
        assert upload_part['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Failed to verify response code. Expected: '{RESPONSE_OK}' but found "
            f"'{upload_part['ResponseMetadata']['HTTPStatusCode']}'"
        )
        logging.info(
            f"Successfully executed upload part of the part number '{part_number}' of the object '{object_key}'"
        )
        return upload_part['ETag'], part_number

    def upload_part_of_multipart_upload(
            self, bucket_name: str, object_key: str, part_number: int, upload_id: str, **kwargs
    ):
        """
        Test method to upload parts of the object
        :param bucket_name: Name of the bucket
        :param object_key: Name of the object
        :param part_number: Part number
        :param upload_id: upload if of the object
        :param kwargs: Body/ContentLength/ContentMD5/PartNumber/SSECustomerAlgorithm/SSECustomerKey/
        RequestPayer/ExpectedBucketOwner
        :return: Response of the upload part request
        """
        try:
            upload_part = self.s3_client.upload_part(
                Bucket=bucket_name, Key=object_key, PartNumber=part_number, UploadId=upload_id, **kwargs
            )
            return upload_part
        except ClientError as err:
            if err.response['Error']['Code'] == "NoSuchUpload":
                logging.error(
                    "Specified multipart upload does not exists or The upload ID might be invalid, or "
                    "the multipart upload might have been aborted or completed."
                )
            else:
                logging.error(err)
            logging.error(
                f"Failed to perform upload part of the part number '{part_number}' of the object '{object_key}' "
                f"with error: {err.response['Error']['code']}"
            )

    def validate_complete_multipart_upload(self, bucket_name: str, key: str, upload_id: str, **kwargs):
        """
        Validation method to validate complete multipart upload
        :param bucket_name: Name of the bucket
        :param key: name of the key
        :param upload_id: upload id of the object
        :param kwargs: MultipartUpload/RequestPayer/ExpectedBucketOwner
        """
        complete_multipart_upload = self.complete_multipart_upload(bucket_name, key, upload_id, **kwargs)
        assert complete_multipart_upload, f"Failed to complete multipart upload. Output: {complete_multipart_upload}"
        assert complete_multipart_upload['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Failed to verify response code. Expected: '{RESPONSE_OK}' but found "
            f"'{complete_multipart_upload['ResponseMetadata']['HTTPStatusCode']}'"
        )
        logging.info(f"Successfully completed multipart upload of the object '{key}'")

    def complete_multipart_upload(self, bucket_name: str, object_key: str, upload_id: str, **kwargs):
        """
        Library method to complete multipart upload
        :param bucket_name: Name of the bucket
        :param object_key: Name of the key
        :param upload_id: Upload id of the object
        :param kwargs: MultipartUpload/RequestPayer/ExpectedBucketOwner
        :return: Response of the complete multipart upload
        """
        try:
            complete_multipart_upload = self.s3_client.complete_multipart_upload(
                Bucket=bucket_name, Key=object_key, UploadId=upload_id, **kwargs
            )
            return complete_multipart_upload
        except ClientError as err:
            if err.response['Error']['Code'] == "EntityTooSmall":
                logging.error(
                    "Your proposed upload is smaller than the minimum allowed object size. Each part must be at least 5"
                    " MB in size, except the last part."
                )
            elif err.response['Error']['Code'] == "InvalidPart":
                logging.error(
                    "One or more of the specified parts could not be found. The part might not have been uploaded, or "
                    "the specified entity tag might not have matched the part's entity tag."
                )
            elif err.response['Error']['Code'] == "InvalidPartOrder":
                logging.error(
                    "The list of parts was not in ascending order. The parts list must be specified in order by part "
                    "number."
                )
            elif err.response['Error']['Code'] == "NoSuchUpload":
                logging.error(
                    "The specified multipart upload does not exist. The upload ID might be invalid, or the multipart "
                    "upload might have been aborted or completed."
                )
            else:
                logging.error(err)
            logging.error(
                f"Failed to complete multipart upload of the object '{object_key}' in the bucket '{bucket_name}'"
            )

    def validate_generate_presigned_url_post(
            self, bucket_name: str, object_key: str, fields: dict = None, conditions: list = None,
            expiration: int = 3600
    ):
        """
        Validation method to validate the response of the generate bucket.
        :param bucket_name: Name of the bucket
        :param object_key: Name of the object
        :param fields: Elements that may be included are acl, Cache-Control, Content-Type, Content-Disposition,
        Content-Encoding, Expires, success_action_redirect, redirect, success_action_status, and x-amz-meta-.
        :param conditions: A list of conditions to include in the policy.
        :param expiration: Time for which link is valid
        :return: Returns the response of the generate presigned url
        """
        generate_url = self.generate_presigned_url_post(bucket_name, object_key, fields, conditions, expiration)
        assert generate_url, (
            f"Failed to get the response of the generate presigned url for object '{object_key}'. "
            f"Output: {generate_url}"
        )
        assert generate_url['fields']['key'] == object_key, (
            f"Failed, Mismatch object key. Expected: '{object_key}' but found '{generate_url['fields']['key']}'"
        )
        if self.command_line:
            logging.info(
                Fore.GREEN + f"Successfully generated the presigned url.\nURL - {generate_url['url']}" + Style.RESET_ALL)
        else:
            logging.info(
                Fore.GREEN + f"Successfully generated the presigned url post for the object '{generate_url}'" + Style.RESET_ALL)
        return generate_url

    def generate_presigned_url_post(
            self, bucket_name: str, object_key: str, fields: dict = None, conditions: list = None, expiration: int =
            3600
    ):
        """
        Library method to generate a presigned url to post the object
        :param bucket_name: Name of the bucket
        :param object_key: Name of the object
        :param fields: Elements that may be included are acl, Cache-Control, Content-Type, Content-Disposition,
        Content-Encoding, Expires, success_action_redirect, redirect, success_action_status, and x-amz-meta-.
        :param conditions: A list of conditions to include in the policy.
        :param expiration: Time for which link is valid
        :return: Returns the response of the generate presigned url post
        """
        try:
            response = self.s3_client.generate_presigned_post(
                bucket_name, object_key, Fields=fields, Conditions=conditions, ExpiresIn=expiration
            )
            # The response contains the presigned URL and required fields
            return response
        except ClientError as err:
            print(Fore.RED)
            logging.error(err)
            logging.error(f"Failed to generate a presigned url post for the object '{object_key}'")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def validate_presigned_url_post(self, file_path: str, object_key: str, generate_url: dict):
        """
        Validation method to validate the response of the presigned url post
        :param file_path: File path
        :param object_key: Key of the object
        :param generate_url: presigned url of the object
        """
        presigned_url_post = self.presigned_url_post(file_path, object_key, generate_url)
        assert presigned_url_post, (
            f"Failed to get response of presigned url post of object '{object_key}'. Output = {presigned_url_post}"
        )
        assert presigned_url_post.status_code == NO_CONTENT, (
            f"Failed to verify response code. Expected: '{NO_CONTENT}' but found '{presigned_url_post.status_code}'"
        )
        logging.info(Fore.GREEN + f"Successfully post the object '{object_key}' by the presigned url" + Style.RESET_ALL)

    def presigned_url_post(self, file_path: str, object_key: str, generate_url: dict):
        """
        Library method to post the object using presigned url
        :param file_path: File path
        :param object_key: Key of the object
        :param generate_url: presigned url of the object
        :return: Returns the response of the presigned url
        """
        with open(file_path) as f:
            files = {'file': (object_key, f)}
            http_response = requests.post(generate_url['url'], data=generate_url['fields'], files=files)
        # If successful, returns HTTP status code 204
        return http_response

    def validate_delete_object_from_s3_bucket(self, bucket_name: str, key: str, **kwargs):
        """
        Validation method to delete the object from s3 bucket
        :param bucket_name: Name of the bucket
        :param key: Key of the object
        :param kwargs: MFA/VersionId/RequestPayer/BypassGovernanceRetention/ExpectedBucketOwner
        """
        delete_object = self.delete_object_from_s3_bucket(bucket_name, key, **kwargs)
        assert delete_object, (
            f"Failed to get response of delete object '{key}' from s3 bucket '{bucket_name}'. Output: {delete_object}"
        )
        assert delete_object['ResponseMetadata']['HTTPStatusCode'] == NO_CONTENT, (
            f"Failed to verify response code. Expected: '{NO_CONTENT}' but found "
            f"'{delete_object['ResponseMetadata']['HTTPStatusCode']}'"
        )
        logging.info(
            Fore.GREEN + f"Object '{key}' successfully deleted from the bucket '{bucket_name}'" + Style.RESET_ALL)
        return f"Object '{key}' successfully deleted from the bucket '{bucket_name}'"

    def delete_object_from_s3_bucket(self, bucket_name: str, key: str, **kwargs):
        """
        Library method to delete the object from s3 bucket
        :param bucket_name: Name of the bucket
        :param key: Key of the object
        :param kwargs: MFA/VersionId/RequestPayer/BypassGovernanceRetention/ExpectedBucketOwner
        """
        try:
            delete_object = self.s3_client.delete_object(Bucket=bucket_name, Key=key, **kwargs)
            return delete_object
        except ClientError as err:
            print(Fore.RED)
            logging.info(err)
            logging.error(
                f"Failed to delete object '{key}' from the bucket '{bucket_name}' with error: "
                f"{err.response['Error']['Code']}"
            )
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def delete_validate_s3_bucket(self, bucket_name: str, **kwargs):
        """
        Validation method to validate response of delete s3 bucket request
        :param bucket_name: Name of the bucket
        :param kwargs: ExpectedBucketOwner
        """
        delete_s3_bucket = self.delete_s3_bucket(bucket_name, **kwargs)
        assert delete_s3_bucket, f"Failed to get response of delete '{bucket_name}' bucket. Output: {delete_s3_bucket}"
        assert delete_s3_bucket['ResponseMetadata']['HTTPStatusCode'] == NO_CONTENT, (
            f"Failed to verify response code. Expected: '{NO_CONTENT}' but found "
            f"'{delete_s3_bucket['ResponseMetadata']['HTTPStatusCode']}'"
        )
        logging.info(Fore.GREEN + f"Bucket '{bucket_name}' deleted successfully" + Style.RESET_ALL)
        return f"Bucket '{bucket_name}' deleted successfully"

    def delete_s3_bucket(self, bucket_name: str, **kwargs):
        """
        Library method to delete the s3 bucket
        :param bucket_name: Name of the bucket
        :param kwargs: ExpectedBucketOwner
        :return: Response of delete s3 bucket.
        """
        try:
            delete_bucket = self.s3_client.delete_bucket(Bucket=bucket_name, **kwargs)
            return delete_bucket
        except ClientError as err:
            print(Fore.RED)
            logging.error(err)
            logging.error(f"Failed to delete '{bucket_name}' bucket with error: {err.response['Error']['Code']}")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def update_versioning_s3_bucket(self, bucket_name: str, status: str):
        """
        The function is used to enable/suspend versioning to s3 bucket
        :param bucket_name: Name of the bucket
        :param status: versioning status
        :return:response
        """
        try:
            config = {"Status": status}
            response = self.s3_client.put_bucket_versioning(Bucket=bucket_name, VersioningConfiguration=config)
            return response
        except ClientError as err:
            print(Fore.RED)
            logging.error(err)
            logging.error(f"Failed to change bucket versioning status to {status}")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def validate_update_versioning_s3_bucket(self, bucket_name: str, status: str):
        """
        The function is used to validate versioning to s3 bucket
        :param bucket_name: Name of the bucket
        :param status: versioning status
        """
        response_code = self.update_versioning_s3_bucket(bucket_name, status)
        # Adding sleep of 5 sec to get the status reflected after operation performed
        time.sleep(5)
        versioning_status = self.get_versioning_s3_bucket(bucket_name)
        assert response_code['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Failed to verify response code. Expected: '{RESPONSE_OK}' but found "
            f"'{response_code['ResponseMetadata']['HTTPStatusCode']}'"
        )
        assert versioning_status['Status'].lower() == status.lower(), (
            f"Failed to validate versioning status Expected: {status} but found {versioning_status['Status']}"
        )
        logging.info(
            Fore.GREEN + f"Bucket versioning for bucket {bucket_name} updated successfully to {status}" + Style.RESET_ALL)
        return f"Bucket versioning for bucket {bucket_name} updated successfully to {status}"

    def get_versioning_s3_bucket(self, bucket_name: str):
        """
        The function is used to get the versioning status of the bucket
        :param bucket_name:Name of the bucket
        :return: versioning_status
        """
        try:
            versioning_status = self.s3_client.get_bucket_versioning(Bucket=bucket_name)
            return versioning_status
        except ClientError as err:
            print(Fore.RED)
            logging.error(err)
            logging.error(f"Failed to get versioning for the bucket {bucket_name}")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def validate_get_versioning_s3_bucket(self, bucket_name: str):
        """
        The function is used to validate versioning of the bucket
        :param bucket_name:Name of the bucket
        """
        versioning_status = self.get_versioning_s3_bucket(bucket_name)

        assert versioning_status['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Failed to verify response code. Expected: '{RESPONSE_OK}' but found "
            f"'{versioning_status['ResponseMetadata']['HTTPStatusCode']}'"
        )
        logging.info(Fore.GREEN + f"Bucket versioning status for bucket {bucket_name} is status - "
                                  f"{versioning_status['Status']}" + Style.RESET_ALL)
        return f"Bucket versioning status for bucket {bucket_name} is status - {versioning_status['Status']}"

    def get_lifecycle_s3_bucket(self, bucket_name: str):
        """
        The function is used to get lifecycle of s3 bucket
        :param bucket_name: Name of the bucket
        :return: lifecycle status
        """
        try:
            lifecycle_status = self.s3_client.get_bucket_lifecycle(Bucket=bucket_name)
            return lifecycle_status
        except ClientError as err:
            print(Fore.RED)
            logging.error(err)
            logging.error(f"Failed to get lifecycle for the bucket {bucket_name}")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def validate_get_lifecycle_s3_bucket(self, bucket_name: str):
        """
        The function is used to validate lifecycle status of the bucket
        :param bucket_name:Name of the bucket
        :return:lifecycle status
        """
        lifecycle_status = self.get_lifecycle_s3_bucket(bucket_name)
        if lifecycle_status:
            assert lifecycle_status['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
                f"Failed to verify response code. Expected: '{RESPONSE_OK}' but found "
                f"'{lifecycle_status['ResponseMetadata']['HTTPStatusCode']}'"
            )
            logging.info(Fore.GREEN +
                         f"Lifecycle status for bucket {bucket_name} is status = {lifecycle_status['Rules'][0]['Status']}" + Style.RESET_ALL)
        else:
            logging.info(Fore.YELLOW +
                         f"Lifecycle status for bucket {bucket_name} is None as the lifecycle rule is deleted for the bucket" + Style.RESET_ALL)
        return lifecycle_status

    def put_lifecycle_s3_bucket(self, bucket_name: str, config_rules: dict):
        """
        The function is used to put the lifecycle to s3 bucket
        :param bucket_name: Name of the bucket
        :param config_rules: Configuration
        :return: response
        """
        try:
            response = self.s3_client.put_bucket_lifecycle(Bucket=bucket_name, LifecycleConfiguration=config_rules)
            return response
        except ClientError as err:
            print(Fore.RED)
            logging.error(err)
            logging.error(f"Failed to put bucket lifecycle")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def validate_put_lifecycle_s3_bucket(self, bucket_name: str, config_rules: dict):
        """
        The function is used to validate lifecycle of the s3 bucket
        :param bucket_name: Name of the bucket
        :param config_rules:Lifecycle configuration rule
        """
        response_code = self.put_lifecycle_s3_bucket(bucket_name, config_rules)
        # Adding sleep of 5 sec to get the status reflected after operation performed
        time.sleep(5)
        lifecycle_status = self.get_lifecycle_s3_bucket(bucket_name)
        assert response_code['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Failed to verify response code. Expected: '{RESPONSE_OK}' but found "
            f"'{response_code['ResponseMetadata']['HTTPStatusCode']}'"
        )
        assert lifecycle_status, f"Life cycle status not update for bucket. Lifecycle status: {lifecycle_status}"
        logging.info(Fore.GREEN +
                     f"Bucket lifecycle status for bucket {bucket_name} updated successfully to {lifecycle_status['Rules'][0]['Status']}" + Style.RESET_ALL)

    def delete_lifecycle_s3_bucket(self, bucket_name: str):
        """
        The function is used to delete lifecycle of s3 bucket
        :param bucket_name:Name of the bucket
        :return:response
        """
        try:
            response = self.s3_client.delete_bucket_lifecycle(Bucket=bucket_name)
            return response
        except ClientError as err:
            print(Fore.RED)
            logging.error(err)
            logging.error(f"Failed to delete bucket lifecycle ")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def validate_delete_lifecycle_s3_bucket(self, bucket_name: str):
        """
        The function is used to validate deletion of lifecycle in s3 bucket
        :param bucket_name:Name of the bucket
        """
        response_code = self.delete_lifecycle_s3_bucket(bucket_name)
        assert response_code, f"Failed to get response of delete lifecycle'{bucket_name}' bucket. Output: {response_code}"
        assert response_code['ResponseMetadata']['HTTPStatusCode'] == NO_CONTENT, (
            f"Failed to verify response code. Expected: '{NO_CONTENT}' but found "
            f"'{response_code['ResponseMetadata']['HTTPStatusCode']}'"
        )
        logging.info(Fore.GREEN +
                     f"Bucket lifecycle for bucket {bucket_name} has been deleted successfully" + Style.RESET_ALL)

    def validate_get_s3_bucket_list(self):
        """
        The function is used to validate s3 bucket list
        """
        response = self.get_s3_bucket()
        assert response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Failed to verify response code. Expected: '{RESPONSE_OK}' but found "
            f"'{response['ResponseMetadata']['HTTPStatusCode']}'"
        )
        bucket_list: list = response['Buckets']
        info_msg1 = f"Bucket list for s3 is = {bucket_list}"
        info_msg2 = "Bucket list is empty as no buckets present for bucket"
        logging.info(info_msg1) if bucket_list else logging.info(info_msg2)

    def get_s3_bucket_location(self, bucket_name: str):
        """
        The function is used to get the location of the s3 bucket
        :param bucket_name: Name of the bucket
        :return: response,response of location
        """
        try:
            response = self.s3_client.get_bucket_location(Bucket=bucket_name)
            return response, response['LocationConstraint']
        except ClientError as err:
            print(Fore.RED)
            logging.error(err)
            logging.error(f"Failed to get location for the s3 bucket")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def validate_get_s3_bucket_location(self, bucket_name: str):
        """
        The function is used to validate get location of the s3 bucket
        :param bucket_name: Name of the bucket.
        """
        response_code, response_location = self.get_s3_bucket_location(bucket_name)
        assert response_location, f"Failed to get response of location '{bucket_name}' bucket. Output: {response_location}"
        assert response_code['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Failed to verify response code. Expected: '{RESPONSE_OK}' but found "
            f"'{response_code['ResponseMetadata']['HTTPStatusCode']}'"
        )
        logging.info(Fore.GREEN +
                     f"Bucket file location for bucket - {bucket_name} is {response_location}" + Style.RESET_ALL)
        return f"Bucket file location for bucket - {bucket_name} is {response_location}"

    def download_file_s3_bucket(self, bucket_name: str, bucket_file_name: str, downloaded_file_name: str, **kwargs):
        """
        The function is used to download file from the s3 bucket
        :param bucket_name:Name of the bucket
        :param kwargs :ExtraArgs, Callback, Config
        :param bucket_file_name: Name of the file to be downloaded
        :param downloaded_file_name: Name of the file to be saved
        """
        try:
            self.s3_resource.meta.client.download_file(bucket_name, bucket_file_name, downloaded_file_name, **kwargs)
        except ClientError as err:
            print(Fore.RED)
            logging.error(err)
            logging.error(f"Failed to download file {bucket_file_name} from the s3 bucket = {bucket_name}")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def validate_download_file_s3_bucket(self, bucket_name: str, bucket_file_name: str, downloaded_file_name: str,
                                         **kwargs):
        """
        The function is used to validate download file from s3 bucket
        :param bucket_name:Name of the bucket
        :param bucket_file_name: Name of the file to be downloaded
        :param downloaded_file_name: Name of the file to be saved
        """
        self.download_file_s3_bucket(bucket_name, bucket_file_name, downloaded_file_name, **kwargs)
        if not os.path.exists(downloaded_file_name):
            raise Exception(f"The file {bucket_file_name} is not downloaded at the specified location")
        elif not self.command_line:
            # Delete downloaded file
            os.remove(downloaded_file_name)
        logging.info(Fore.GREEN +
                     f"Bucket file downloaded with file name - {downloaded_file_name} for bucket  - {bucket_name}" + Style.RESET_ALL)
        return f"Bucket file downloaded with file name - {downloaded_file_name} for bucket  - {bucket_name}"

    def put_public_access_s3_bucket(self, bucket_name: str, public_access_configuration: dict, **kwargs):
        """
        The function is used to put public access to s3 bucket
        :param bucket_name: Name of the bucket
        :param public_access_configuration: public access configuration
        :param kwargs:ExpectedBucketOwner
        :return: response
        """
        try:
            response = self.s3_client.put_public_access_block(
                Bucket=bucket_name,
                PublicAccessBlockConfiguration=public_access_configuration, **kwargs
            )
            return response
        except ClientError as err:
            print(Fore.RED)
            logging.error(err)
            logging.error(f"Failed to put public access to bucket = {bucket_name}")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def validate_put_public_access_s3_bucket(self, bucket_name: str, public_access_configuration: dict, **kwargs):
        """
        The function is used to validate put public access code
        :param bucket_name: Name of the bucket
        :param public_access_configuration: public access configuration
        :param kwargs ExpectedBucketOwner
        """
        response_code = self.put_public_access_s3_bucket(bucket_name, public_access_configuration, **kwargs)
        assert response_code['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Failed to verify response code. Expected: '{RESPONSE_OK}' but found "
            f"'{response_code['ResponseMetadata']['HTTPStatusCode']}'"
        )
        assert response_code, f"Public access not updated for bucket = {bucket_name}"
        # Adding sleep of 5 sec to get the status reflected after operation performed
        time.sleep(5)
        public_access_response = self.validate_get_public_access_s3_bucket(bucket_name)
        assert public_access_response, f"Failed to put public access to bucket = {bucket_name}"
        logging.info(Fore.GREEN +
                     f"public access response updated successfully for bucket = {bucket_name}" + Style.RESET_ALL)
        return f"public access response updated successfully for bucket = {bucket_name}"

    def delete_public_access_s3_bucket(self, bucket_name: str, **kwargs):
        """
        The function is used to delete public access of s3 bucket
        :param bucket_name:Name of the bucket
        :param kwargs:ExpectedBucketOwner
        :return:response
        """
        try:
            response = self.s3_client.delete_public_access_block(Bucket=bucket_name, **kwargs)
            return response
        except ClientError as err:
            print(Fore.RED)
            logging.error(err)
            logging.error(f"Failed to delete bucket public access block ")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def validate_delete_public_access_s3_bucket(self, bucket_name: str, **kwargs):
        """
        The function is used to validate deletion of public access in s3 bucket
        :param bucket_name:Name of the bucket
        :param kwargs :ExpectedBucketOwner
        """
        response_code = self.delete_public_access_s3_bucket(bucket_name, **kwargs)
        assert response_code, f"Failed to get response of delete public access'{bucket_name}' bucket. Output: {response_code}"
        assert response_code['ResponseMetadata']['HTTPStatusCode'] == NO_CONTENT, (
            f"Failed to verify response code. Expected: '{NO_CONTENT}' but found "
            f"'{response_code['ResponseMetadata']['HTTPStatusCode']}'"
        )
        logging.info(Fore.GREEN +
                     f"Bucket public access block for bucket = {bucket_name} has been deleted successfully"
                     + Style.RESET_ALL)
        return f"Bucket public access block for bucket = {bucket_name} has been deleted successfully"

    def get_public_access_s3_bucket(self, bucket_name: str, **kwargs):
        """
        The function is used to get public access of s3 bucket
        :param bucket_name: Name of the bucket
        :param kwargs: ExpectedBucketOwner
        :return: public access response
        """
        try:
            public_access_response = self.s3_client.get_public_access_block(Bucket=bucket_name, **kwargs)
            return public_access_response
        except ClientError as err:
            print(Fore.RED)
            logging.error(err)
            logging.error(f"Failed to get public access response for the bucket {bucket_name}")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def validate_get_public_access_s3_bucket(self, bucket_name: str, **kwargs):
        """
        The function is used to validate  public access of the bucket
        :param bucket_name:Name of the bucket
        :param kwargs :ExpectedBucketOwner
        :return:public_access_response
        """
        public_access_response = self.get_public_access_s3_bucket(bucket_name, **kwargs)
        if public_access_response:
            assert public_access_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
                f"Failed to verify response code. Expected: '{RESPONSE_OK}' but found "
                f"'{public_access_response['ResponseMetadata']['HTTPStatusCode']}'"
            )
            logging.info(Fore.GREEN +
                         f"public access response for bucket {bucket_name} is "
                         f"{public_access_response['PublicAccessBlockConfiguration']}" + Style.RESET_ALL)
        else:
            logging.info(Fore.YELLOW +
                         f"public access response for bucket {bucket_name} is None ,"
                         "as the public access response rule is deleted for the bucket" +
                         Style.RESET_ALL)
        return public_access_response

    def put_tagging_s3_bucket(self, bucket_name: str, tagging: dict, **kwargs):
        """
        The function is used to put the tagging to s3 bucket
        :param bucket_name: Name of the bucket
        :param tagging: tagging Configuration
        :param kwargs :ExpectedBucketOwner
        :return: response
        """
        try:
            response = self.s3_client.put_bucket_tagging(Bucket=bucket_name, Tagging=tagging, **kwargs)
            return response
        except ClientError as err:
            print(Fore.RED)
            logging.error(err)
            logging.error(f"Failed to put bucket tagging for bucket ={bucket_name}")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def validate_put_tagging_s3_bucket(self, bucket_name: str, tagging: dict, **kwargs):
        """
        The function is used to validate tagging of the s3 bucket
        :param bucket_name: Name of the bucket
        :param kwargs :ExpectedBucketOwner
        :param tagging:tagging configuration
        """
        response_code = self.put_tagging_s3_bucket(bucket_name, tagging, **kwargs)
        # Adding sleep of 5 sec to get the status reflected after operation performed
        time.sleep(5)
        assert response_code['ResponseMetadata']['HTTPStatusCode'] == NO_CONTENT, (
            f"Failed to verify response code. Expected: '{NO_CONTENT}' but found "
            f"'{response_code['ResponseMetadata']['HTTPStatusCode']}'"
        )
        assert response_code, f"Tagging not updated for bucket. Tagging status: {response_code}"
        # Adding sleep of 5 sec to get the status reflected after operation performed
        time.sleep(5)
        tagging_response = self.validate_get_tagging_s3_bucket(bucket_name)
        assert tagging_response, f"Failed to put tagging to bucket = {bucket_name}"
        logging.info(Fore.GREEN +
                     f"Bucket Tagging status for bucket {bucket_name} updated successfully"
                     + Style.RESET_ALL)
        return f"Bucket Tagging status for bucket {bucket_name} updated successfully"

    def delete_tagging_s3_bucket(self, bucket_name: str, **kwargs):
        """
        The function is used to delete tagging of s3 bucket
        :param bucket_name:Name of the bucket
        :param kwargs :ExpectedBucketOwner
        :return:response
        """
        try:
            response = self.s3_client.delete_bucket_tagging(Bucket=bucket_name, **kwargs)
            return response
        except ClientError as err:
            print(Fore.RED)
            logging.error(err)
            logging.error(f"Failed to delete bucket tagging for bucket ={bucket_name} ")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def validate_delete_tagging_s3_bucket(self, bucket_name: str, **kwargs):
        """
        The function is used to validate deletion of tagging in s3 bucket
        :param kwargs :ExpectedBucketOwner
        :param bucket_name:Name of the bucket
        """
        response_code = self.delete_tagging_s3_bucket(bucket_name, **kwargs)
        assert response_code, f"Failed to get response of delete tagging'{bucket_name}' bucket. Output: {response_code}"
        assert response_code['ResponseMetadata']['HTTPStatusCode'] == NO_CONTENT, (
            f"Failed to verify response code. Expected: '{NO_CONTENT}' but found "
            f"'{response_code['ResponseMetadata']['HTTPStatusCode']}'"
        )
        logging.info(Fore.GREEN +
                     f"Bucket tagging for bucket {bucket_name} has been deleted successfully" + Style.RESET_ALL)
        return f"Bucket tagging for bucket {bucket_name} has been deleted successfully"

    def get_tagging_s3_bucket(self, bucket_name: str, **kwargs):
        """
        The function is used to get tagging of s3 bucket
        :param bucket_name: Name of the bucket
        :param kwargs: ExpectedBucketOwner
        :return: tagging_response
        """
        try:
            tagging_response = self.s3_client.get_bucket_tagging(Bucket=bucket_name, **kwargs)
            return tagging_response
        except ClientError as err:
            print(Fore.RED)
            logging.error(err)
            logging.error(f"Failed to get tagging response for the bucket {bucket_name}")
            print(Style.RESET_ALL)
            if self.command_line:
                exit()

    def validate_get_tagging_s3_bucket(self, bucket_name: str, **kwargs):
        """
        The function is used to validate tagging response of the bucket
        :param bucket_name:Name of the bucket
        :param kwargs :ExpectedBucketOwner
        :return:tagging_response
        """
        tagging_response = self.get_tagging_s3_bucket(bucket_name, **kwargs)
        if tagging_response:
            assert tagging_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
                f"Failed to verify response code. Expected: '{RESPONSE_OK}' but found "
                f"'{tagging_response['ResponseMetadata']['HTTPStatusCode']}'"
            )
            logging.info(Fore.GREEN +
                         f"Tagging response for bucket {bucket_name} is {tagging_response['TagSet']}" + Style.RESET_ALL)
        else:
            logging.info(Fore.YELLOW +
                         f"Tagging response for bucket {bucket_name} is None ,"
                         "as the Tagging response rule is deleted for the bucket" + Style.RESET_ALL)
        return tagging_response


def main():
    # Common Parsers
    parent_parser = argparse.ArgumentParser(add_help=False)
    parent_parser.add_argument("--bucket_name", type=str,
                               help="Name of the bucket" + Fore.RED + " [REQUIRED]" + Style.RESET_ALL,
                               default=argparse.SUPPRESS, required=True)
    parser = argparse.ArgumentParser()
    s3_method_subparser = parser.add_subparsers(dest='s3_method')

    # Create Bucket Commands
    create_bucket_parser = s3_method_subparser.add_parser("create-bucket", parents=[parent_parser],
                                                          help="Create new bucket")
    create_bucket_parser.add_argument("--ACL", "--acl", type=str,
                                      help="The canned ACL to apply to the bucket.", default=argparse.SUPPRESS)
    create_bucket_parser.add_argument("--GrantFullControl", "--grant_full_control", type=str,
                                      help="Allows grantee the read, write, read ACP, and write ACP permissions on "
                                           "the bucket.", default=argparse.SUPPRESS)
    create_bucket_parser.add_argument("--GrantRead", "--grant__read", type=str,
                                      help="Allows grantee to list the objects in the bucket.",
                                      default=argparse.SUPPRESS)
    create_bucket_parser.add_argument("--GrantReadACP", "--grant_read_acp", type=str,
                                      help="Allows grantee to read the bucket ACL.", default=argparse.SUPPRESS)
    create_bucket_parser.add_argument("--GrantWrite", "--grant_write", type=str,
                                      help="Allows grantee to create new objects in the bucket.",
                                      default=argparse.SUPPRESS)
    create_bucket_parser.add_argument("--GrantWriteACP", "--grant_write_acp", type=str,
                                      help="Allows grantee to write the ACL for the applicable bucket.",
                                      default=argparse.SUPPRESS)
    create_bucket_parser.add_argument("--ObjectLockEnabledForBucket", "--objectlock_enabled_for_bucket", type=str,
                                      help="Specifies whether you want S3 Object Lock to be enabled for the new bucket.",
                                      default=argparse.SUPPRESS)
    create_bucket_parser.add_argument("--email", type=str,
                                      help="Specify email ID to send email notification (Multiple comma-separated "
                                           "email IDs are acceptable)",
                                      default=argparse.SUPPRESS)

    # Validate bucket
    bucket_info_parser = s3_method_subparser.add_parser("check-bucket", parents=[parent_parser],
                                                        help="Check bucket status")
    bucket_info_parser.add_argument("--email", type=str,
                                      help="Specify email ID to send email notification (Multiple comma-separated "
                                           "email IDs are acceptable)",
                                      default=argparse.SUPPRESS)

    # List bucket
    bucket_info_parser = s3_method_subparser.add_parser("list-buckets", help="List Buckets")

    # delete bucket
    delete_bucket_parser = s3_method_subparser.add_parser("delete-bucket", parents=[parent_parser],
                                                          help="Delete existing bucket")
    delete_bucket_parser.add_argument("--email", type=str,
                                    help="Specify email ID to send email notification (Multiple comma-separated "
                                         "email IDs are acceptable)",
                                    default=argparse.SUPPRESS)

    # Get put object in S3 bucket
    get_put_obj_parser = s3_method_subparser.add_parser("get-object", parents=[parent_parser],
                                                        help="Get object from the s3 bucket")
    get_put_obj_parser.add_argument("--key", type=str, help="Key of the object" + Fore.RED + " [REQUIRED]"
                                                            + Style.RESET_ALL, required=True)

    # Put object in S3 bucket
    put_obj_parser = s3_method_subparser.add_parser("put-object", parents=[parent_parser],
                                                    help="Put the object in the s3 bucket")
    put_obj_parser.add_argument("--key", type=str, help="Key of the object" + Fore.RED + " [REQUIRED]"
                                                        + Style.RESET_ALL, required=True)
    put_obj_parser.add_argument("--email", type=str,
                                    help="Specify email ID to send email notification (Multiple comma-separated "
                                         "email IDs are acceptable)",
                                    default=argparse.SUPPRESS)

    # delete object from S3 bucket
    del_obj_parser = s3_method_subparser.add_parser("delete-object", parents=[parent_parser],
                                                    help="Delete the object from s3 bucket")
    del_obj_parser.add_argument("--key", type=str, help="Key of the object" + Fore.RED + " [REQUIRED]"
                                                        + Style.RESET_ALL, required=True)
    del_obj_parser.add_argument("--email", type=str,
                                    help="Specify email ID to send email notification (Multiple comma-separated "
                                         "email IDs are acceptable)",
                                    default=argparse.SUPPRESS)

    # validate data file in S3 bucket
    validate_file_parser = s3_method_subparser.add_parser("read-file", parents=[parent_parser],
                                                          help="Validate file object data in s3 bucket")
    validate_file_parser.add_argument("--object_key", type=str, help="Key of the object" + Fore.RED + " [REQUIRED]"
                                                                     + Style.RESET_ALL, required=True)
    validate_file_parser.add_argument("--email", type=str,
                                    help="Specify email ID to send email notification (Multiple comma-separated "
                                         "email IDs are acceptable)",
                                    default=argparse.SUPPRESS)

    # upload file in S3 bucket
    upload_file_parser = s3_method_subparser.add_parser("upload-file", parents=[parent_parser],
                                                        help="Upload file to s3 bucket")
    upload_file_parser.add_argument("--file_path", type=str, help="File Path" + Fore.RED + " [REQUIRED]"
                                                                  + Style.RESET_ALL, required=True)
    upload_file_parser.add_argument("--key", type=str, help="Key of the object" + Fore.RED + " [REQUIRED]"
                                                            + Style.RESET_ALL, required=True)
    upload_file_parser.add_argument("--email", type=str,
                                    help="Specify email ID to send email notification (Multiple comma-separated "
                                         "email IDs are acceptable)",
                                    default=argparse.SUPPRESS)

    # put bucket policy to S3 bucket
    attach_buc_policy_parser = s3_method_subparser.add_parser("put-bucket-policy", parents=[parent_parser],
                                                              help="Attach policy to s3 bucket")
    attach_buc_policy_parser.add_argument("--policy", type=argparse.FileType('r'),
                                          help="Path to JSON file containing policy information" + Fore.RED
                                               + " [REQUIRED]" + Style.RESET_ALL, required=True)
    attach_buc_policy_parser.add_argument("--email", type=str,
                                    help="Specify email ID to send email notification (Multiple comma-separated "
                                         "email IDs are acceptable)",
                                    default=argparse.SUPPRESS)

    # delete bucket policy from S3 bucket
    del_buc_policy_parser = s3_method_subparser.add_parser("delete-bucket-policy", parents=[parent_parser],
                                                           help="Remove policy from s3 bucket")
    del_buc_policy_parser.add_argument("--email", type=str,
                                    help="Specify email ID to send email notification (Multiple comma-separated "
                                         "email IDs are acceptable)",
                                    default=argparse.SUPPRESS)

    # Generate pre-assigned URL post
    gen_url_post_parser = s3_method_subparser.add_parser("gen-url-post", parents=[parent_parser],
                                                         help="Generate pre-assigned URL post")
    gen_url_post_parser.add_argument("--object_key", type=str, help="Key of the object" + Fore.RED + " [REQUIRED]"
                                                                    + Style.RESET_ALL, required=True)
    gen_url_post_parser.add_argument("--fields", type=str,
                                     help="Elements that may be included are acl, Cache-Control,"
                                          "Content-Type, Content-Disposition, Content-Encoding, Expires,"
                                          "success_action_redirect, redirect, success_action_status, x-amz-meta-",
                                     default=None)
    gen_url_post_parser.add_argument("--conditions", type=list,
                                     help="A list of conditions to include in the policy", default=None)
    gen_url_post_parser.add_argument("--expiration", type=int,
                                     help="Time for which link is valid [default 3600]", default=3600)

    # Get Versioning in s3 bucket
    get_bucket_parser = s3_method_subparser.add_parser("get-bucket-version", parents=[parent_parser],
                                                       help="Get the versioning status of the bucket")
    get_bucket_parser.add_argument("--email", type=str,
                                    help="Specify email ID to send email notification (Multiple comma-separated "
                                         "email IDs are acceptable)",
                                    default=argparse.SUPPRESS)

    # Update Versioning in s3 bucket
    upload_ver_parser = s3_method_subparser.add_parser("update-bucket-version", parents=[parent_parser],
                                                       help="Enable/Suspend versioning to s3 bucket")
    upload_ver_parser.add_argument("--status", type=str, help="versioning status [Enabled/Suspended]" + Fore.RED +
                                                              " [REQUIRED]" + Style.RESET_ALL, required=True)
    upload_ver_parser.add_argument("--email", type=str,
                                    help="Specify email ID to send email notification (Multiple comma-separated "
                                         "email IDs are acceptable)",
                                    default=argparse.SUPPRESS)

    # Get Lifecycle of s3 bucket
    get_lfcyle_parser = s3_method_subparser.add_parser("get-lifecycle", parents=[parent_parser],
                                                       help="Get lifecycle of s3 bucket")
    get_lfcyle_parser.add_argument("--email", type=str,
                                    help="Specify email ID to send email notification (Multiple comma-separated "
                                         "email IDs are acceptable)",
                                    default=argparse.SUPPRESS)

    # Put Lifecycle of s3 bucket
    put_lfcycle_parser = s3_method_subparser.add_parser("put-lifecycle", parents=[parent_parser],
                                                        help="Put the lifecycle to s3 bucket")
    put_lfcycle_parser.add_argument("--config_rules", type=argparse.FileType('r'), help="Path to Configuration file"
                                                                                        + Fore.RED + " [REQUIRED]" +
                                                                                        Style.RESET_ALL, required=True)
    put_lfcycle_parser.add_argument("--email", type=str,
                                    help="Specify email ID to send email notification (Multiple comma-separated "
                                         "email IDs are acceptable)",
                                    default=argparse.SUPPRESS)

    # Delete Lifecycle of s3 bucket
    del_lfcycle_parser = s3_method_subparser.add_parser("delete-lifecycle", parents=[parent_parser],
                                                        help="Delete lifecycle of s3 bucket")

    # get s3 bucket location
    s3_loc_parser = s3_method_subparser.add_parser("get-location", parents=[parent_parser],
                                                   help="Get the location of the s3 bucket")
    s3_loc_parser.add_argument("--email", type=str,
                                    help="Specify email ID to send email notification (Multiple comma-separated "
                                         "email IDs are acceptable)",
                                    default=argparse.SUPPRESS)

    # download file from s3 bucket location
    down_file_parser = s3_method_subparser.add_parser("download-file", parents=[parent_parser],
                                                      help="Download file from the s3 bucket")
    down_file_parser.add_argument("--bucket_file_name", type=str, help="Name of the file to be downloaded" + Fore.RED +
                                                                       " [REQUIRED]" + Style.RESET_ALL, required=True)
    down_file_parser.add_argument("--downloaded_file_name", type=str, help="Name of the file to be saved" + Fore.RED +
                                                                           " [REQUIRED]" + Style.RESET_ALL,
                                  required=True)
    down_file_parser.add_argument("--email", type=str,
                                    help="Specify email ID to send email notification (Multiple comma-separated "
                                         "email IDs are acceptable)",
                                    default=argparse.SUPPRESS)

    # Put public access to S3 bucket
    put_public_access_parser = s3_method_subparser.add_parser("put-public-access", parents=[parent_parser],
                                                              help="put public access to s3 bucket")
    put_public_access_parser.add_argument("--public_access_configuration", type=argparse.FileType('r'),
                                          help="Public access configuration" + Fore.RED +
                                               " [REQUIRED]" + Style.RESET_ALL, required=True)
    put_public_access_parser.add_argument("--email", type=str,
                                    help="Specify email ID to send email notification (Multiple comma-separated "
                                         "email IDs are acceptable)",
                                    default=argparse.SUPPRESS)

    # remove public access to S3 bucket
    rem_public_access_parser = s3_method_subparser.add_parser("remove-public-access", parents=[parent_parser],
                                                              help="Remove public access from s3 bucket")

    # Get tagging from S3 bucket
    get_tagging_parser = s3_method_subparser.add_parser("get-tagging", parents=[parent_parser],
                                                        help="Get tagging from s3 bucket")
    get_tagging_parser.add_argument("--email", type=str,
                                    help="Specify email ID to send email notification (Multiple comma-separated "
                                         "email IDs are acceptable)",
                                    default=argparse.SUPPRESS)

    # Put tagging to S3 bucket
    put_tagging_parser = s3_method_subparser.add_parser("put-tagging", parents=[parent_parser],
                                                        help="Put the tagging to s3 bucket")
    put_tagging_parser.add_argument("--tagging", type=argparse.FileType('r'), help="Path to file containing tagging "
                                                                                   "Configuration" + Fore.RED +
                                                                                   " [REQUIRED]" + Style.RESET_ALL,
                                    required=True)
    put_tagging_parser.add_argument("--email", type=str,
                                    help="Specify email ID to send email notification (Multiple comma-separated "
                                         "email IDs are acceptable)",
                                    default=argparse.SUPPRESS)

    # Delete tagging from S3 bucket
    delete_tagging_parser = s3_method_subparser.add_parser("delete-tagging", parents=[parent_parser],
                                                           help="Delete tagging to s3 bucket")
    delete_tagging_parser.add_argument("--email", type=str,
                                    help="Specify email ID to send email notification (Multiple comma-separated "
                                         "email IDs are acceptable)",
                                    default=argparse.SUPPRESS)
    args = parser.parse_args()
    if not args.s3_method:
        parser.print_help()
        return
    parse_args_to_execute(args)


@send_email("S3", "s3_method")
def parse_args_to_execute(args, config_data=None):
    if args.s3_method and config_data:
        s3_obj = S3(config_data, command_line=True)
        args_dict = vars(args)
        if args.s3_method == "create-bucket":
            del args_dict['s3_method']
            return s3_obj.create_validate_s3_bucket(**args_dict)
        elif args.s3_method == "check-bucket":
            del args_dict['s3_method']
            return s3_obj.get_validate_s3_bucket(**args_dict)
        elif args.s3_method == "list-buckets":
            del args_dict['s3_method']
            s3_obj.get_s3_bucket()
        elif args.s3_method == "delete-bucket":
            del args_dict['s3_method']
            return s3_obj.delete_validate_s3_bucket(**args_dict)
        elif args.s3_method == "get-object":
            del args_dict['s3_method']
            s3_obj.get_validate_object_from_s3_bucket(**args_dict)
        elif args.s3_method == "put-object":
            del args_dict['s3_method']
            return s3_obj.validate_put_object_in_s3_bucket(**args_dict)
        elif args.s3_method == "delete-object":
            del args_dict['s3_method']
            return s3_obj.validate_delete_object_from_s3_bucket(**args_dict)
        elif args.s3_method == "read-file":
            del args_dict['s3_method']
            return s3_obj.read_data_of_file_from_s3_bucket(**args_dict)
        elif args.s3_method == "upload-file":
            del args_dict['s3_method']
            return s3_obj.validate_upload_file_in_s3_bucket(**args_dict)
        elif args.s3_method == "put-bucket-policy":
            del args_dict['s3_method']
            args_dict['policy'] = json.load(args_dict['policy'])
            args_dict['policy'] = json.dumps(args_dict['policy'])
            return s3_obj.validate_attach_policy_to_s3_bucket(**args_dict)
        elif args.s3_method == "delete-bucket-policy":
            del args_dict['s3_method']
            return s3_obj.validate_delete_policy_of_s3_bucket(**args_dict)
        elif args.s3_method == "gen-url-post":
            del args_dict['s3_method']
            if args_dict['fields'] is not None:
                args_dict['fields'] = json.loads(args_dict['fields'])
            if args_dict['conditions'] is not None:
                args_dict['conditions'] = args_dict['conditions'].split(",")
            s3_obj.validate_generate_presigned_url_post(**args_dict)
        elif args.s3_method == "get-bucket-version":
            del args_dict['s3_method']
            return s3_obj.validate_get_versioning_s3_bucket(**args_dict)
        elif args.s3_method == "update-bucket-version":
            del args_dict['s3_method']
            return s3_obj.validate_update_versioning_s3_bucket(**args_dict)
        elif args.s3_method == "get-lifecycle":
            del args_dict['s3_method']
            return s3_obj.validate_get_lifecycle_s3_bucket(**args_dict)
        elif args.s3_method == "put-lifecycle":
            del args_dict['s3_method']
            args_dict['config_rules'] = json.load(args_dict['config_rules'])
            return s3_obj.validate_put_lifecycle_s3_bucket(**args_dict)
        elif args.s3_method == "delete-lifecycle":
            del args_dict['s3_method']
            s3_obj.validate_delete_lifecycle_s3_bucket(**args_dict)
        elif args.s3_method == "get-location":
            del args_dict['s3_method']
            return s3_obj.validate_get_s3_bucket_location(**args_dict)
        elif args.s3_method == "download-file":
            del args_dict['s3_method']
            return s3_obj.validate_download_file_s3_bucket(**args_dict)
        elif args.s3_method == "put-public-access":
            del args_dict['s3_method']
            args_dict['public_access_configuration'] = json.load(args_dict['public_access_configuration'])
            return s3_obj.validate_put_public_access_s3_bucket(**args_dict)
        elif args.s3_method == "remove-public-access":
            del args_dict['s3_method']
            return s3_obj.validate_delete_public_access_s3_bucket(**args_dict)
        elif args.s3_method == "get-tagging":
            del args_dict['s3_method']
            return s3_obj.validate_get_tagging_s3_bucket(**args_dict)
        elif args.s3_method == "put-tagging":
            del args_dict['s3_method']
            args_dict['tagging'] = json.load(args_dict['tagging'])
            return s3_obj.validate_put_tagging_s3_bucket(**args_dict)
        elif args.s3_method == "delete-tagging":
            del args_dict['s3_method']
            return s3_obj.validate_delete_tagging_s3_bucket(**args_dict)


if __name__ == '__main__':
    main()
