import logging

import boto3
from botocore.exceptions import ClientError

from constants import *


class Lambda:
    def __init__(self, config):
        self.client = boto3.client(
            "lambda", **config
        )

    def invoke_lambda_function(self, function_name: str, **kwargs):
        """
        Method to invoke lambda function
        :param function_name: Lambda function name
        :param kwargs: InvocationType/LogType/ClientContext/Payload/Qualifier
        :return lambda_response
        """
        try:
            lambda_response = self.client.invoke(FunctionName=function_name, **kwargs)
            return lambda_response
        except ClientError as err:
            logging.info(
                f"Lambda function {function_name} execution failed with error: {err.response['Error']['Code']}"
            )

    def invoke_validate_lambda(self, function_name: str, **kwargs):
        """
        Method to invoke lambda function
        :param function_name: Lambda function name
        :param kwargs: InvocationType/LogType/ClientContext/Payload/Qualifier
        :return lambda_response
        """
        success_codes = [200, 202, 204]
        logging.info(f"Execution lambda function {function_name}")
        lambda_response = self.invoke_lambda_function(function_name, **kwargs)
        assert lambda_response['ResponseMetadata']['HTTPStatusCode'] == RESPONSE_OK, (
            f"Error in lambda function execution. Output {lambda_response}"
        )
        assert lambda_response["StatusCode"] in success_codes, (
            f"Error in lambda function execution. Output {lambda_response}"
        )
        logging.info(
            f"Lambda function executed successfully. Output payload: {lambda_response['Payload']._raw_stream.data}"
        )
        return lambda_response
